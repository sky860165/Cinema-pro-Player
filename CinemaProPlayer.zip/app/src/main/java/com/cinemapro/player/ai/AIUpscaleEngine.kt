package com.cinemapro.player.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import android.media.ImageReader
import android.opengl.GLES20
import android.util.Log
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import org.tensorflow.lite.nnapi.NnApiDelegate
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.pow

/**
 * Cinema Pro AI Upscale Engine
 * Supports: AI 4K, AI 8K, Super Resolution, Sharpen, Denoise, HDR Simulation
 */
@UnstableApi
class AIUpscaleEngine(private val context: Context) {

    companion object {
        private const val TAG = "AIUpscaleEngine"
        private const val MODEL_4X = "esrgan_4x.tflite"
        private const val MODEL_8X = "esrgan_8x.tflite"
        private const val MODEL_SR = "real_esrgan_sr.tflite"
        private const val MODEL_SHARPEN = "unsharp_mask.tflite"
        private const val MODEL_DENOISE = "denoise_cnn.tflite"
        private const val INPUT_SIZE_4X = 256
        private const val INPUT_SIZE_8X = 128
        private const val INPUT_SIZE_SR = 256
    }

    private var interpreter4x: Interpreter? = null
    private var interpreter8x: Interpreter? = null
    private var interpreterSR: Interpreter? = null
    private var interpreterSharpen: Interpreter? = null
    private var interpreterDenoise: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private var nnApiDelegate: NnApiDelegate? = null
    private val compatList = CompatibilityList()

    // FIX: no .tflite model files ship in app/src/main/assets, so
    // interpreter4x/8x/SR below are ALWAYS null in practice — every
    // AI 4K / AI 8K / Super Resolution call was silently falling through
    // to fallbackUpscale(), a plain Bitmap.createScaledBitmap() stretch
    // with zero enhancement, even though the UI labeled it "AI".
    // GLUpscaler is a real, lightweight GPU shader path (bicubic +
    // edge-aware sharpen, no ML model weights) that runs this fallback
    // as an actual upscaler instead of a bare stretch. If real .tflite
    // models are added to assets later, the TFLite path above still
    // takes priority automatically — this only fires when it's missing.
    private val glUpscaler by lazy { GLUpscaler() }

    private val useGpu = compatList.isDelegateSupportedOnThisDevice
    private val useNNAPI = android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P

    init {
        initializeInterpreters()
    }

    private fun initializeInterpreters() {
        try {
            val options = Interpreter.Options().apply {
                setNumThreads(4)
                useXNNPACK = true

                // Use GPU if available
                if (useGpu) {
                    gpuDelegate = GpuDelegate(compatList.bestOptionsForThisDevice)
                    addDelegate(gpuDelegate)
                    Log.d(TAG, "Using GPU delegate for AI processing")
                } else if (useNNAPI) {
                    nnApiDelegate = NnApiDelegate()
                    addDelegate(nnApiDelegate)
                    Log.d(TAG, "Using NNAPI delegate for AI processing")
                }
            }

            // Load models
            interpreter4x = loadModel(MODEL_4X)?.let { Interpreter(it, options) }
            interpreter8x = loadModel(MODEL_8X)?.let { Interpreter(it, options) }
            interpreterSR = loadModel(MODEL_SR)?.let { Interpreter(it, options) }
            interpreterSharpen = loadModel(MODEL_SHARPEN)?.let { Interpreter(it, options) }
            interpreterDenoise = loadModel(MODEL_DENOISE)?.let { Interpreter(it, options) }

            Log.d(TAG, "AI Upscale Engine initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing AI models: ${e.message}")
        }
    }

    private fun loadModel(modelName: String): MappedByteBuffer? {
        return try {
            val assetFileDescriptor = context.assets.openFd(modelName)
            val fileInputStream = assetFileDescriptor.createInputStream()
            val fileChannel = fileInputStream.channel
            val mappedBuffer = fileChannel.map(
                FileChannel.MapMode.READ_ONLY,
                assetFileDescriptor.startOffset,
                assetFileDescriptor.declaredLength
            )
            assetFileDescriptor.close()
            mappedBuffer
        } catch (e: Exception) {
            Log.w(TAG, "Model $modelName not found, using fallback")
            null
        }
    }

    /**
     * Main upscale function - processes video frame
     */
    suspend fun upscaleFrame(
        inputBitmap: Bitmap,
        targetMode: com.cinemapro.player.data.model.UpscaleMode,
        targetWidth: Int = 3840,
        targetHeight: Int = 2160
    ): Bitmap? = withContext(Dispatchers.Default) {
        return@withContext when (targetMode) {
            com.cinemapro.player.data.model.UpscaleMode.AI_4K -> upscaleTo4K(inputBitmap, targetWidth, targetHeight)
            com.cinemapro.player.data.model.UpscaleMode.AI_8K -> upscaleTo8K(inputBitmap, targetWidth, targetHeight)
            com.cinemapro.player.data.model.UpscaleMode.SUPER_RESOLUTION -> superResolution(inputBitmap)
            com.cinemapro.player.data.model.UpscaleMode.SHARPEN -> sharpenFrame(inputBitmap)
            com.cinemapro.player.data.model.UpscaleMode.DENOISE -> denoiseFrame(inputBitmap)
            com.cinemapro.player.data.model.UpscaleMode.HDR_SIMULATION -> simulateHDR(inputBitmap)
            else -> inputBitmap
        }
    }

    /**
     * AI Upscale to 4K using ESRGAN 4x model
     */
    private fun upscaleTo4K(input: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap? {
        return try {
            interpreter4x?.let { interpreter ->
                // Process in tiles for large images
                val tiles = splitIntoTiles(input, INPUT_SIZE_4X)
                val processedTiles = tiles.mapNotNull { tile ->
                    val inputBuffer = bitmapToFloatBuffer(tile, INPUT_SIZE_4X, INPUT_SIZE_4X)
                    val outputBuffer = ByteBuffer.allocateDirect(INPUT_SIZE_4X * 4 * INPUT_SIZE_4X * 4 * 3 * 4)
                        .order(ByteOrder.nativeOrder())

                    interpreter.run(inputBuffer, outputBuffer)
                    floatBufferToBitmap(outputBuffer, INPUT_SIZE_4X * 4, INPUT_SIZE_4X * 4)
                }
                combineTiles(processedTiles, input.width * 4, input.height * 4)
                    ?.let { scaleBitmap(it, targetWidth, targetHeight) }
            } ?: fallbackUpscale(input, targetWidth, targetHeight, strength = 1.0f)
            // FIX: interpreter4x is always null in practice (no .tflite
            // ships in assets — see class doc), so this ?.let { } was
            // previously falling through to a plain `null` return with NO
            // fallback at all when the model was simply absent (as
            // opposed to throwing an exception, which the catch below DID
            // handle). AI 4K would silently produce no image in that case.
        } catch (e: Exception) {
            Log.e(TAG, "4K upscale error: ${e.message}")
            fallbackUpscale(input, targetWidth, targetHeight, strength = 1.0f)
        }
    }

    /**
     * AI Upscale to 8K using ESRGAN 8x model
     */
    private fun upscaleTo8K(input: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap? {
        return try {
            interpreter8x?.let { interpreter ->
                val tiles = splitIntoTiles(input, INPUT_SIZE_8X)
                val processedTiles = tiles.mapNotNull { tile ->
                    val inputBuffer = bitmapToFloatBuffer(tile, INPUT_SIZE_8X, INPUT_SIZE_8X)
                    val outputBuffer = ByteBuffer.allocateDirect(INPUT_SIZE_8X * 8 * INPUT_SIZE_8X * 8 * 3 * 4)
                        .order(ByteOrder.nativeOrder())

                    interpreter.run(inputBuffer, outputBuffer)
                    floatBufferToBitmap(outputBuffer, INPUT_SIZE_8X * 8, INPUT_SIZE_8X * 8)
                }
                combineTiles(processedTiles, input.width * 8, input.height * 8)
                    ?.let { scaleBitmap(it, targetWidth, targetHeight) }
            } ?: fallbackUpscale(input, targetWidth, targetHeight, strength = 1.4f)
            // Same missing-model gap as upscaleTo4K above, fixed the same
            // way. 8K uses a stronger fallback strength (1.4x) since
            // scaling further loses relatively more detail to recover.
        } catch (e: Exception) {
            Log.e(TAG, "8K upscale error: ${e.message}")
            fallbackUpscale(input, targetWidth, targetHeight, strength = 1.4f)
        }
    }

    /**
     * Super Resolution using Real-ESRGAN
     */
    private fun superResolution(input: Bitmap): Bitmap? {
        return try {
            interpreterSR?.let { interpreter ->
                val inputBuffer = bitmapToFloatBuffer(input, INPUT_SIZE_SR, INPUT_SIZE_SR)
                val outputBuffer = ByteBuffer.allocateDirect(INPUT_SIZE_SR * 4 * INPUT_SIZE_SR * 4 * 3 * 4)
                    .order(ByteOrder.nativeOrder())

                interpreter.run(inputBuffer, outputBuffer)
                floatBufferToBitmap(outputBuffer, INPUT_SIZE_SR * 4, INPUT_SIZE_SR * 4)
            } ?: fallbackUpscale(input, input.width * 2, input.height * 2, strength = 1.15f)
        } catch (e: Exception) {
            Log.e(TAG, "Super resolution error: ${e.message}")
            fallbackUpscale(input, input.width * 2, input.height * 2, strength = 1.15f)
        }
    }

    /**
     * Sharpen frame using Unsharp Mask
     */
    private fun sharpenFrame(input: Bitmap): Bitmap {
        return try {
            interpreterSharpen?.let { interpreter ->
                val inputBuffer = bitmapToFloatBuffer(input, input.width, input.height)
                val outputBuffer = ByteBuffer.allocateDirect(input.width * input.height * 3 * 4)
                    .order(ByteOrder.nativeOrder())

                interpreter.run(inputBuffer, outputBuffer)
                floatBufferToBitmap(outputBuffer, input.width, input.height) ?: input
            } ?: applyUnsharpMask(input)
        } catch (e: Exception) {
            applyUnsharpMask(input)
        }
    }

    /**
     * Denoise frame using CNN
     */
    private fun denoiseFrame(input: Bitmap): Bitmap {
        return try {
            interpreterDenoise?.let { interpreter ->
                val inputBuffer = bitmapToFloatBuffer(input, input.width, input.height)
                val outputBuffer = ByteBuffer.allocateDirect(input.width * input.height * 3 * 4)
                    .order(ByteOrder.nativeOrder())

                interpreter.run(inputBuffer, outputBuffer)
                floatBufferToBitmap(outputBuffer, input.width, input.height) ?: input
            } ?: applyGaussianBlur(input, 0.5f)
        } catch (e: Exception) {
            applyGaussianBlur(input, 0.5f)
        }
    }

    /**
     * HDR Simulation - enhance dynamic range
     */
    private fun simulateHDR(input: Bitmap): Bitmap {
        val width = input.width
        val height = input.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        input.getPixels(pixels, 0, width, 0, 0, width, height)

        for (i in pixels.indices) {
            val pixel = pixels[i]
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF

            // HDR tone mapping - enhance contrast and colors
            val newR = ((r / 255.0).pow(0.8) * 255).toInt().coerceIn(0, 255)
            val newG = ((g / 255.0).pow(0.8) * 255).toInt().coerceIn(0, 255)
            val newB = ((b / 255.0).pow(0.8) * 255).toInt().coerceIn(0, 255)

            // Slight saturation boost
            val avg = (newR + newG + newB) / 3
            val saturationBoost = 1.2f
            val finalR = (avg + (newR - avg) * saturationBoost).toInt().coerceIn(0, 255)
            val finalG = (avg + (newG - avg) * saturationBoost).toInt().coerceIn(0, 255)
            val finalB = (avg + (newB - avg) * saturationBoost).toInt().coerceIn(0, 255)

            pixels[i] = (0xFF shl 24) or (finalR shl 16) or (finalG shl 8) or finalB
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }

    // ===================== HELPER METHODS =====================

    private fun bitmapToFloatBuffer(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): ByteBuffer {
        val scaledBitmap = if (bitmap.width != targetWidth || bitmap.height != targetHeight) {
            Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
        } else {
            bitmap
        }

        val buffer = ByteBuffer.allocateDirect(targetWidth * targetHeight * 3 * 4)
            .order(ByteOrder.nativeOrder())

        val pixels = IntArray(targetWidth * targetHeight)
        scaledBitmap.getPixels(pixels, 0, targetWidth, 0, 0, targetWidth, targetHeight)

        for (pixel in pixels) {
            val r = ((pixel shr 16) and 0xFF) / 255.0f
            val g = ((pixel shr 8) and 0xFF) / 255.0f
            val b = (pixel and 0xFF) / 255.0f
            buffer.putFloat(r)
            buffer.putFloat(g)
            buffer.putFloat(b)
        }

        buffer.rewind()
        return buffer
    }

    private fun floatBufferToBitmap(buffer: ByteBuffer, width: Int, height: Int): Bitmap? {
        return try {
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val pixels = IntArray(width * height)
            buffer.rewind()

            for (i in pixels.indices) {
                val r = (buffer.float * 255).toInt().coerceIn(0, 255)
                val g = (buffer.float * 255).toInt().coerceIn(0, 255)
                val b = (buffer.float * 255).toInt().coerceIn(0, 255)
                pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }

            bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            bitmap
        } catch (e: Exception) {
            null
        }
    }

    private fun splitIntoTiles(bitmap: Bitmap, tileSize: Int): List<Bitmap> {
        val tiles = mutableListOf<Bitmap>()
        val width = bitmap.width
        val height = bitmap.height

        for (y in 0 until height step tileSize) {
            for (x in 0 until width step tileSize) {
                val tileWidth = minOf(tileSize, width - x)
                val tileHeight = minOf(tileSize, height - y)
                val tile = Bitmap.createBitmap(bitmap, x, y, tileWidth, tileHeight)
                tiles.add(tile)
            }
        }
        return tiles
    }

    private fun combineTiles(tiles: List<Bitmap>, totalWidth: Int, totalHeight: Int): Bitmap? {
        if (tiles.isEmpty()) return null

        val result = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(result)
        var x = 0
        var y = 0
        val tileWidth = tiles[0].width
        val tileHeight = tiles[0].height

        for (tile in tiles) {
            canvas.drawBitmap(tile, x.toFloat(), y.toFloat(), null)
            x += tileWidth
            if (x >= totalWidth) {
                x = 0
                y += tileHeight
            }
        }
        return result
    }

    private fun scaleBitmap(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    /**
     * Used when no .tflite model is available (the normal case today,
     * since none ship in assets). Runs the upgraded GPU shader upscaler —
     * bicubic + two-radius luma-aware detail reconstruction + local
     * contrast — instead of a bare linear stretch.
     *
     * strength: 1.0 = standard (used for 4K/Super Resolution), 1.4 = a
     * noticeably stronger detail pass (used for 8K) since scaling further
     * loses more relative detail and needs more reconstruction to still
     * read as "clearer" rather than just "bigger".
     */
    private fun fallbackUpscale(input: Bitmap, targetWidth: Int, targetHeight: Int, strength: Float = 1.0f): Bitmap {
        val gpuResult = try {
            glUpscaler.upscale(
                input, targetWidth, targetHeight,
                // FIX ("video ko sharp bna do"): the shader now denoises
                // before sharpening (see GLUpscaler comments), so this
                // sharpen push works on a cleaner signal and can go
                // higher without amplifying grain/noise the way it would
                // have pre-denoise. strength: 1.0 = 4K/SuperRes, 1.4 = 8K.
                sharpenAmount = (0.55f * strength).coerceIn(0f, 1f),
                detailAmount = (0.5f * strength).coerceIn(0f, 1f)
            )
        } catch (e: Exception) {
            Log.w(TAG, "GLUpscaler failed, plain stretch: ${e.message}")
            null
        }
        return gpuResult ?: Bitmap.createScaledBitmap(input, targetWidth, targetHeight, true)
    }

    private fun applyUnsharpMask(input: Bitmap): Bitmap {
        val width = input.width
        val height = input.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        input.getPixels(pixels, 0, width, 0, 0, width, height)
        val result = IntArray(width * height)

        // Simple unsharp mask
        val amount = 1.5f
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val idx = y * width + x
                val center = pixels[idx]
                val left = pixels[idx - 1]
                val right = pixels[idx + 1]
                val top = pixels[idx - width]
                val bottom = pixels[idx + width]

                for (c in 0..2) {
                    val shift = c * 8
                    val centerVal = (center shr shift) and 0xFF
                    val avg = (((left shr shift) and 0xFF) +
                            ((right shr shift) and 0xFF) +
                            ((top shr shift) and 0xFF) +
                            ((bottom shr shift) and 0xFF)) / 4
                    val sharpened = (centerVal + (centerVal - avg) * amount).toInt().coerceIn(0, 255)
                    result[idx] = result[idx] or (sharpened shl shift)
                }
                result[idx] = result[idx] or (0xFF shl 24)
            }
        }

        output.setPixels(result, 0, width, 0, 0, width, height)
        return output
    }

    private fun applyGaussianBlur(input: Bitmap, radius: Float): Bitmap {
        // Simplified Gaussian blur
        return input
    }

    fun release() {
        interpreter4x?.close()
        interpreter8x?.close()
        interpreterSR?.close()
        interpreterSharpen?.close()
        interpreterDenoise?.close()
        gpuDelegate?.close()
        nnApiDelegate?.close()
        try { glUpscaler.release() } catch (e: Exception) { Log.w(TAG, "glUpscaler release: ${e.message}") }
        Log.d(TAG, "AI Upscale Engine released")
    }
}
