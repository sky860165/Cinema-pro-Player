package com.cinemapro.player.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemapro.player.data.model.VideoAdjustments
import com.cinemapro.player.data.model.toVideoAdjustments
import com.cinemapro.player.ui.theme.*
import kotlin.math.roundToInt

/**
 * One slider row for a picture-control parameter — same visual language
 * as BassControlSlider/the volume-enhancement slider in EqualizerPanel,
 * just generalized so every VideoAdjustments field (contrast, sharpness,
 * clarity, noise reduction, 3D depth, etc.) can reuse it instead of
 * hand-rolling nine near-identical Slider blocks.
 *
 * range defaults to -1f..1f (centered controls like brightness/contrast/
 * saturation/gamma/warmth). Pass 0f..1f for one-directional controls like
 * sharpness/clarity/noiseReduction/depth3D.
 */
@Composable
fun VideoAdjustSlider(
    label: String,
    icon: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = -1f..1f,
    accentColor: Color = CinemaGold
) {
    Column(modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("$icon $label", color = CinemaGray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            val percentValue = if (range.start < 0f) {
                (value * 100).roundToInt().let { if (it > 0) "+$it" else "$it" }
            } else {
                "${(value * 100).roundToInt()}"
            }
            Text("$percentValue%", color = accentColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = CinemaSurfaceLight
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Quick-preset chip row for VideoAdjustments — same button look as
 * EqualizerPresetButton but for picture presets (Cinema/Vivid/Soft/etc.)
 */
@Composable
fun VideoAdjustPresetButton(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) CinemaGold else CinemaSurfaceLight,
            contentColor = if (isSelected) Color.Black else Color.White
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(name, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/**
 * Full "Picture Adjust" bottom panel — mirrors EqualizerPanel's structure
 * (drag-handle header, presets grid, then individual sliders) so it feels
 * like the same app rather than a bolted-on screen.
 *
 * onAdjustmentsChanged fires on every slider move; the caller (screen)
 * is responsible for turning the resulting VideoAdjustments into real
 * ExoPlayer.setVideoEffects() calls (see CinemaProPlayerScreen's
 * buildVideoEffects()).
 */
@Composable
fun VideoAdjustPanel(
    adjustments: VideoAdjustments,
    onAdjustmentsChanged: (VideoAdjustments) -> Unit,
    onDismiss: () -> Unit,
    customPresets: List<com.cinemapro.player.data.model.VideoAdjustPresetEntity> = emptyList(),
    onSaveCustomPreset: () -> Unit = {},
    onLoadCustomPreset: (com.cinemapro.player.data.model.VideoAdjustPresetEntity) -> Unit = {},
    onDeleteCustomPreset: (com.cinemapro.player.data.model.VideoAdjustPresetEntity) -> Unit = {}
) {
    // FIX ("video adjust krte waqt video clear dikhe jisse video adjust
    // kr sku"): this used to be background(CinemaBlack.copy(0.98f)) on a
    // fillMaxSize() Box — nearly opaque black covering the ENTIRE screen,
    // so the video was invisible right when you need to see it most (to
    // judge contrast/brightness/colour changes live). Now it's anchored
    // to the bottom half only, with a lighter/translucent background, so
    // the video keeps playing and stays visible in the top half of the
    // screen while you drag the sliders underneath it.
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.62f)
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(CinemaBlack.copy(alpha = 0.88f))
    ) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Column {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(40.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(CinemaGray.copy(alpha = 0.5f))
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .pointerInput(Unit) {
                            var accDy = 0f
                            detectDragGestures(
                                onDragStart = { accDy = 0f },
                                onDragEnd = { if (accDy > 50f) onDismiss(); accDy = 0f },
                                onDrag = { change, dragAmount -> change.consume(); accDy += dragAmount.y }
                            )
                        },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🎬 PICTURE ADJUST", color = CinemaGold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onAdjustmentsChanged(VideoAdjustments.DEFAULT) }) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "Reset", tint = CinemaGray)
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }
            }
        }
        item {
            Text(
                "PICTURE PRESETS",
                color = CinemaGray, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
            val presets = listOf(
                "Default" to VideoAdjustments.DEFAULT,
                "Cinema" to VideoAdjustments.CINEMA,
                "Vivid" to VideoAdjustments.VIVID,
                "Soft Natural" to VideoAdjustments.SOFT_NATURAL,
                "Clarity Max" to VideoAdjustments.CLARITY_MAX,
                "🔥 Extreme Thriller" to VideoAdjustments.EXTREME_THRILLER
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.height(90.dp).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                gridItems(presets) { (name, preset) ->
                    VideoAdjustPresetButton(
                        name = name,
                        isSelected = adjustments == preset,
                        onClick = { onAdjustmentsChanged(preset) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // ── CUSTOM (PERSONAL) PICTURE PRESETS ──────────
        // "meri personal settings save ho custom video adjust save krne
        // k liye" — same idea as the equalizer's custom-preset save/load/
        // delete flow, just for the 9 Picture Adjust sliders. Tap a ⭐
        // card to load it, long-press to delete it.
        if (customPresets.isNotEmpty()) {
            item {
                Text(
                    "MY SAVED PRESETS",
                    color = CinemaGray, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .height((((customPresets.size + 2) / 3) * 52).dp)
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    gridItems(customPresets) { preset ->
                        val isSelected = adjustments == preset.toVideoAdjustments()
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .pointerInput(preset.id) {
                                    detectTapGestures(
                                        onTap = { onLoadCustomPreset(preset) },
                                        onLongPress = { onDeleteCustomPreset(preset) }
                                    )
                                }
                                .background(if (isSelected) CinemaGold else CinemaSurfaceLight)
                                .padding(vertical = 10.dp, horizontal = 6.dp)
                        ) {
                            Text(
                                "⭐ ${preset.name}",
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                Text(
                    "Long-press a ⭐ preset to delete it.",
                    color = CinemaGray, fontSize = 11.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
        }
        item {
            Button(
                onClick = onSaveCustomPreset,
                colors = ButtonDefaults.buttonColors(containerColor = CinemaGreen),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Save, contentDescription = null, tint = Color.Black)
                Spacer(Modifier.width(8.dp))
                Text("Save Custom Preset", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }

        item {
            Text(
                "COLOR & LIGHT",
                color = CinemaGray, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        item {
            VideoAdjustSlider(
                label = "BRIGHTNESS", icon = "☀️",
                value = adjustments.brightness,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(brightness = it)) },
                accentColor = CinemaGold
            )
        }
        item {
            VideoAdjustSlider(
                label = "CONTRAST", icon = "◐",
                value = adjustments.contrast,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(contrast = it)) },
                accentColor = CinemaBlue
            )
        }
        item {
            VideoAdjustSlider(
                label = "COLOUR / SATURATION", icon = "🎨",
                value = adjustments.saturation,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(saturation = it)) },
                accentColor = CinemaPurple
            )
        }
        item {
            VideoAdjustSlider(
                label = "GAMMA (SHADOWS/HIGHLIGHTS)", icon = "🌗",
                value = adjustments.gamma,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(gamma = it)) },
                accentColor = CinemaGray
            )
        }
        item {
            VideoAdjustSlider(
                label = "WARMTH (COOL ↔ WARM)", icon = "🔥",
                value = adjustments.warmth,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(warmth = it)) },
                accentColor = Color(0xFFFF7043)
            )
        }

        item {
            Text(
                "CLARITY & DETAIL",
                color = CinemaGray, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        item {
            VideoAdjustSlider(
                label = "SHARPNESS", icon = "🔪",
                value = adjustments.sharpness,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(sharpness = it)) },
                range = 0f..1f,
                accentColor = CinemaGreen
            )
        }
        item {
            VideoAdjustSlider(
                label = "CLARITY (DETAIL POP)", icon = "💎",
                value = adjustments.clarity,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(clarity = it)) },
                range = 0f..1f,
                accentColor = CinemaBlue
            )
        }
        item {
            VideoAdjustSlider(
                label = "NOISE REDUCTION", icon = "🧹",
                value = adjustments.noiseReduction,
                onValueChange = { onAdjustmentsChanged(adjustments.copy(noiseReduction = it)) },
                range = 0f..1f,
                accentColor = CinemaGray
            )
        }

        item {
            Text(
                "3D DEPTH",
                color = CinemaGray, fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                VideoAdjustSlider(
                    label = "3D DEPTH POP", icon = "🕶️",
                    value = adjustments.depth3D,
                    onValueChange = { onAdjustmentsChanged(adjustments.copy(depth3D = it)) },
                    range = 0f..1f,
                    accentColor = CinemaPurple,
                    modifier = Modifier.padding(horizontal = 0.dp)
                )
                Text(
                    "Adds a subtle pseudo-3D pop to normal 2D video using edge-depth shading — separate from the full 3D modes (SBS/TAB/Anaglyph/VR) in the 3D menu, which need actual stereo source video.",
                    color = CinemaGray, fontSize = 11.sp
                )
            }
        }
    }
    }
    }
}
