package com.cinemapro.player.ui.screens

import android.Manifest
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemapro.player.data.database.CinemaProDatabase
import com.cinemapro.player.data.model.*
import com.cinemapro.player.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class VideoFolder(
    val name: String,
    val path: String,
    val videos: List<VideoItem>
)

// ── Google TV / D-pad focus support ──────────────────
// This screen's cards/rows only had a `clickable` — no visible focus
// state at all. Touch doesn't need one (your finger IS the pointer), but
// a D-pad has no pointer: without some visible highlight tracking which
// item currently has focus, a person navigating this grid with a Google
// TV remote has no way to tell which video pressing "OK" would actually
// open. `clickable` already responds to DPAD_CENTER/Enter once an item
// has focus (Compose Foundation handles that natively) — the only piece
// actually missing was making that focus visible.
@Composable
private fun Modifier.tvFocusable(shape: Shape = RoundedCornerShape(12.dp)): Modifier {
    var isFocused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (isFocused) 1.05f else 1f, label = "tv_focus_scale")
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .onFocusChanged { isFocused = it.isFocused }
        .focusable()
        .then(if (isFocused) Modifier.border(3.dp, CinemaGold, shape) else Modifier)
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun VideoGalleryScreen(
    onVideoSelected: (VideoItem) -> Unit
) {
    val context = LocalContext.current

    val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        listOf(Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.POST_NOTIFICATIONS)
    } else {
        listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    val permissionState = rememberMultiplePermissionsState(permissions)

    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var folders by remember { mutableStateOf<List<VideoFolder>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) }  // 0=All, 1=Folders
    var isGridView by remember { mutableStateOf(true) }
    var isLoading by remember { mutableStateOf(true) }
    var globalEqEnabled by remember {
        mutableStateOf(com.cinemapro.player.service.GlobalEqualizerService.isEnabled(context))
    }

    fun toggleGlobalEq(enabled: Boolean) {
        globalEqEnabled = enabled
        if (enabled) {
            com.cinemapro.player.service.GlobalEqualizerService.start(context)
        } else {
            com.cinemapro.player.service.GlobalEqualizerService.stop(context)
        }
    }

    // ── Global Equalizer (main-screen button) ────────────────────────
    // One button on the home screen opens the FULL Equalizer panel — same
    // one used inside the player — but wired straight to
    // GlobalEqualizerService instead of a local dspEngine, since there's
    // no video playing here. Every change is persisted AND pushed live to
    // the service (which stays running in the background so it keeps
    // applying to other apps, per GlobalEqualizerService's own session-
    // broadcast limitations — see its class doc).
    val scope = rememberCoroutineScope()
    var showGlobalEqualizer by remember { mutableStateOf(false) }
    var geqPreset by remember { mutableStateOf(com.cinemapro.player.service.GlobalEqualizerService.getStoredPreset(context)) }
    var geqBands by remember { mutableStateOf(geqPreset.bands.copyOf()) }
    var geqConfig by remember { mutableStateOf(com.cinemapro.player.service.GlobalEqualizerService.getStoredConfig(context)) }
    var geqApplyJob by remember { mutableStateOf<Job?>(null) }

    fun pushGlobalEq(preset: EqualizerPreset = geqPreset, config: CinemaAudioConfig = geqConfig) {
        com.cinemapro.player.service.GlobalEqualizerService.pushUpdate(context, preset, config)
        globalEqEnabled = true
    }

    fun pushGlobalEqDebounced(bands: FloatArray) {
        geqApplyJob?.cancel()
        geqApplyJob = scope.launch {
            delay(50)
            pushGlobalEq(preset = EqualizerPreset("custom", "Custom", bands))
        }
    }

    var geqSavedTheatrePresetNames by remember {
        mutableStateOf(com.cinemapro.player.data.TheatrePresetStore.listNames(context))
    }
    var geqShowSaveTheatrePresetDialog by remember { mutableStateOf(false) }
    var geqTheatrePresetNameInput by remember { mutableStateOf("") }
    var geqShowCustomSaveDialog by remember { mutableStateOf(false) }
    var geqCustomPresetName by remember { mutableStateOf("") }
    val geqDb = remember { CinemaProDatabase.getInstance(context) }
    val geqCustomPresets by geqDb.equalizerPresetDao().getCustomPresets()
        .map { list -> list.map { it.toPreset() } }
        .collectAsState(initial = emptyList())

    // Load videos when permission granted
    LaunchedEffect(permissionState.allPermissionsGranted) {
        if (permissionState.allPermissionsGranted) {
            isLoading = true
            val loaded = loadVideosFromDevice(context)
            videos = loaded
            folders = loaded.groupBy { it.folderPath }
                .map { (path, vids) ->
                    VideoFolder(
                        name = path.substringAfterLast("/").ifEmpty { "Internal Storage" },
                        path = path,
                        videos = vids
                    )
                }.sortedByDescending { it.videos.size }
            isLoading = false
        }
    }

    val filteredVideos = remember(videos, searchQuery) {
        if (searchQuery.isEmpty()) videos
        else videos.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Box(modifier = Modifier.fillMaxSize()) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CinemaBlack)
    ) {
        // Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(CinemaSurface, CinemaBlack))
                )
                .padding(top = 48.dp, bottom = 16.dp, start = 16.dp, end = 16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "🎬 CINEMA PRO",
                            color = CinemaGold,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            "${videos.size} videos",
                            color = CinemaGray,
                            fontSize = 13.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            showGlobalEqualizer = true
                            // Opening the panel is the "attach + run in
                            // background" action itself — push whatever is
                            // currently stored so the service starts right
                            // away, even before the user changes anything.
                            pushGlobalEq()
                        }) {
                            Icon(
                                Icons.Default.GraphicEq,
                                contentDescription = "Global Equalizer",
                                tint = if (globalEqEnabled) CinemaGold else CinemaGray
                            )
                        }
                        IconButton(onClick = { isGridView = !isGridView }) {
                            Icon(
                                if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                                contentDescription = "Toggle View",
                                tint = Color.White
                            )
                        }
                    }
                }

                if (globalEqEnabled) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CinemaSurface)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.GraphicEq, null, tint = CinemaGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Global EQ running in background",
                            color = CinemaGold,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { toggleGlobalEq(false) }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Text("Turn off", color = CinemaGray, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search videos...", color = CinemaGray) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = CinemaGold) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, null, tint = CinemaGray)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CinemaSurface,
                        unfocusedContainerColor = CinemaSurface,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CinemaGold,
                        unfocusedBorderColor = CinemaSurfaceLight
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Tabs
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("All Videos", "Folders").forEachIndexed { index, tab ->
                        FilterChip(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            label = { Text(tab, fontSize = 13.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CinemaGold,
                                selectedLabelColor = Color.Black,
                                containerColor = CinemaSurface,
                                labelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Content
        if (!permissionState.allPermissionsGranted) {
            // Permission request
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Default.VideoLibrary, null, tint = CinemaGold, modifier = Modifier.size(80.dp))
                    Spacer(modifier = Modifier.height(24.dp))
                    Text("Access Your Videos", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Cinema Pro needs permission to access your video library", color = CinemaGray, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(32.dp))
                    Button(
                        onClick = { permissionState.launchMultiplePermissionRequest() },
                        colors = ButtonDefaults.buttonColors(containerColor = CinemaGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Grant Permission", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        } else if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = CinemaGold, modifier = Modifier.size(60.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Loading Videos...", color = CinemaGray)
                }
            }
        } else if (filteredVideos.isEmpty() && selectedTab == 0) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.VideocamOff, null, tint = CinemaGray, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        if (searchQuery.isEmpty()) "No videos found on device" else "No results for \"$searchQuery\"",
                        color = CinemaGray, fontSize = 16.sp
                    )
                }
            }
        } else {
            when (selectedTab) {
                0 -> {
                    if (isGridView) {
                        VideoGrid(videos = filteredVideos, onVideoSelected = onVideoSelected)
                    } else {
                        VideoList(videos = filteredVideos, onVideoSelected = onVideoSelected)
                    }
                }
                1 -> {
                    FolderView(folders = folders, onVideoSelected = onVideoSelected)
                }
            }
        }
    }

    // ── GLOBAL EQUALIZER PANEL (main-screen button) ──────────────────
    AnimatedVisibility(
        visible = showGlobalEqualizer,
        enter = slideInVertically { it }, exit = slideOutVertically { it }
    ) {
        EqualizerPanel(
            currentPreset = geqPreset, customBands = geqBands,
            surroundMode = geqConfig.surroundMode, bassLevel = geqConfig.bassLevel,
            nightMode = geqConfig.nightMode, dialogEnhance = geqConfig.dialogEnhancement,
            volumeNormalization = geqConfig.volumeNormalization, volumeEnhancement = geqConfig.volumeEnhancement,
            customPresets = geqCustomPresets,
            onDeleteCustomPreset = { preset ->
                scope.launch(Dispatchers.IO) { geqDb.equalizerPresetDao().deletePreset(preset.toEntity()) }
            },
            onPresetSelected = { preset ->
                geqPreset = preset; geqBands = preset.bands.copyOf()
                pushGlobalEq(preset = preset)
            },
            onBandChanged = { i, v ->
                val newBands = geqBands.copyOf(); newBands[i] = v; geqBands = newBands
                geqPreset = EqualizerPreset("custom", "Custom", newBands)
                pushGlobalEqDebounced(newBands)
            },
            onSurroundModeChanged = { geqConfig = geqConfig.copy(surroundMode = it); pushGlobalEq() },
            onBassChanged = { geqConfig = geqConfig.copy(bassLevel = it); pushGlobalEq() },
            onNightModeChanged = { geqConfig = geqConfig.copy(nightMode = it); pushGlobalEq() },
            onDialogEnhanceChanged = { geqConfig = geqConfig.copy(dialogEnhancement = it); pushGlobalEq() },
            onVolumeNormalizationChanged = { geqConfig = geqConfig.copy(volumeNormalization = it); pushGlobalEq() },
            onVolumeEnhancementChanged = { geqConfig = geqConfig.copy(volumeEnhancement = it); pushGlobalEq() },
            theatreRoomSize = geqConfig.theatreRoomSize,
            onTheatreRoomSizeChanged = { geqConfig = geqConfig.copy(theatreRoomSize = it); pushGlobalEq() },
            xCurveEnabled = geqConfig.xCurveEnabled,
            onXCurveEnabledChanged = { geqConfig = geqConfig.copy(xCurveEnabled = it); pushGlobalEq() },
            xCurveIntensity = geqConfig.xCurveIntensity,
            onXCurveIntensityChanged = { geqConfig = geqConfig.copy(xCurveIntensity = it); pushGlobalEq() },
            thxReEqEnabled = geqConfig.thxReEqEnabled,
            onThxReEqChanged = { geqConfig = geqConfig.copy(thxReEqEnabled = it); pushGlobalEq() },
            lfeLevel = geqConfig.lfeLevel,
            onLfeLevelChanged = { geqConfig = geqConfig.copy(lfeLevel = it); pushGlobalEq() },
            bassCrossoverHz = geqConfig.bassCrossoverHz,
            onBassCrossoverChanged = { geqConfig = geqConfig.copy(bassCrossoverHz = it); pushGlobalEq() },
            heightChannelLevel = geqConfig.heightChannelLevel,
            onHeightChannelChanged = { geqConfig = geqConfig.copy(heightChannelLevel = it); pushGlobalEq() },
            centerChannelLevel = geqConfig.centerChannelLevel,
            onCenterChannelChanged = { geqConfig = geqConfig.copy(centerChannelLevel = it); pushGlobalEq() },
            dynamicRangeMode = geqConfig.dynamicRangeMode,
            onDynamicRangeModeChanged = { geqConfig = geqConfig.copy(dynamicRangeMode = it); pushGlobalEq() },
            theatreModeEnabled = geqConfig.theatreModeEnabled,
            onTheatreModeChanged = { enabled ->
                geqConfig = if (enabled) {
                    geqConfig.copy(
                        theatreModeEnabled = true, theatreRoomSize = TheatreRoomSize.IMAX_DOME,
                        xCurveEnabled = true, thxReEqEnabled = true,
                        surroundMode = SurroundMode.ATMOS_3D, dynamicRangeMode = DynamicRangeMode.CINEMA_FULL
                    )
                } else {
                    geqConfig.copy(
                        theatreModeEnabled = false, theatreRoomSize = TheatreRoomSize.STANDARD_MULTIPLEX,
                        xCurveEnabled = false, thxReEqEnabled = false
                    )
                }
                pushGlobalEq()
            },
            frontTrimDb = geqConfig.frontTrimDb, onFrontTrimChanged = { geqConfig = geqConfig.copy(frontTrimDb = it); pushGlobalEq() },
            centerTrimDb = geqConfig.centerTrimDb, onCenterTrimChanged = { geqConfig = geqConfig.copy(centerTrimDb = it); pushGlobalEq() },
            surroundTrimDb = geqConfig.surroundTrimDb, onSurroundTrimChanged = { geqConfig = geqConfig.copy(surroundTrimDb = it); pushGlobalEq() },
            masterBoostDb = geqConfig.masterBoostDb, onMasterBoostChanged = { geqConfig = geqConfig.copy(masterBoostDb = it); pushGlobalEq() },
            limiterEnabled = geqConfig.limiterEnabled, onLimiterEnabledChanged = { geqConfig = geqConfig.copy(limiterEnabled = it); pushGlobalEq() },
            audioCleanModeEnabled = geqConfig.audioCleanModeEnabled, onAudioCleanModeChanged = { geqConfig = geqConfig.copy(audioCleanModeEnabled = it); pushGlobalEq() },
            loudnessTarget = geqConfig.loudnessTarget, onLoudnessTargetChanged = { geqConfig = geqConfig.copy(loudnessTarget = it); pushGlobalEq() },
            abCompareBypassed = geqConfig.abCompareBypassed, onAbCompareChanged = { geqConfig = geqConfig.copy(abCompareBypassed = it); pushGlobalEq() },
            autoDynamicRange = false, onAutoDynamicRangeChanged = {},
            // Video-presentation-only controls (letterbox bars, screen
            // curvature, ambient lighting, intro/intermission) don't apply
            // here — there's no video playing on the home screen. Kept as
            // local no-ops so the shared panel still renders correctly.
            cinemaBarsMode = CinemaBarsMode.OFF, onCinemaBarsModeChanged = {},
            screenCurvatureEnabled = false, onScreenCurvatureChanged = {},
            ambientLightingEnabled = false, onAmbientLightingChanged = {},
            cinemaIntroEnabled = false, onCinemaIntroChanged = {},
            intermissionEnabled = false, onIntermissionChanged = {},
            savedTheatrePresetNames = geqSavedTheatrePresetNames,
            onSaveTheatrePreset = { geqShowSaveTheatrePresetDialog = true },
            onLoadTheatrePreset = { name ->
                com.cinemapro.player.data.TheatrePresetStore.load(context, name)?.let { cfg ->
                    geqConfig = cfg
                    pushGlobalEq(config = cfg)
                }
            },
            onDeleteTheatrePreset = { name ->
                com.cinemapro.player.data.TheatrePresetStore.delete(context, name)
                geqSavedTheatrePresetNames = com.cinemapro.player.data.TheatrePresetStore.listNames(context)
            },
            onSaveCustomPreset = { geqShowCustomSaveDialog = true },
            globalEqEnabled = globalEqEnabled,
            onGlobalEqChanged = { enabled -> toggleGlobalEq(enabled) },
            extremeBassMode = geqConfig.extremeBassMode, onExtremeBassModeChanged = { geqConfig = geqConfig.copy(extremeBassMode = it); pushGlobalEq() },
            extremeLoudnessMode = geqConfig.extremeLoudnessMode, onExtremeLoudnessModeChanged = { geqConfig = geqConfig.copy(extremeLoudnessMode = it); pushGlobalEq() },
            hapticBassSyncEnabled = geqConfig.hapticBassSyncEnabled, onHapticBassSyncChanged = { geqConfig = geqConfig.copy(hapticBassSyncEnabled = it); pushGlobalEq() },
            hapticBassSyncIntensity = geqConfig.hapticBassSyncIntensity, onHapticBassSyncIntensityChanged = { geqConfig = geqConfig.copy(hapticBassSyncIntensity = it); pushGlobalEq() },
            onDismiss = { showGlobalEqualizer = false }
        )
    }

    // Save Custom EQ Preset Dialog (shared table with the in-player Equalizer)
    if (geqShowCustomSaveDialog) {
        AlertDialog(
            onDismissRequest = { geqShowCustomSaveDialog = false },
            title = { Text("Save Custom Preset", color = Color.White) },
            text = {
                OutlinedTextField(value = geqCustomPresetName, onValueChange = { geqCustomPresetName = it },
                    label = { Text("Preset Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CinemaSurface, unfocusedContainerColor = CinemaSurface,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = CinemaGold, unfocusedBorderColor = CinemaSurfaceLight
                    ))
            },
            confirmButton = {
                Button(onClick = {
                    if (geqCustomPresetName.isNotEmpty()) {
                        val newPreset = EqualizerPreset("custom_${System.currentTimeMillis()}", geqCustomPresetName, geqBands.copyOf(), isBuiltIn = false)
                        scope.launch(Dispatchers.IO) { geqDb.equalizerPresetDao().insertPreset(newPreset.toEntity()) }
                    }
                    geqShowCustomSaveDialog = false; geqCustomPresetName = ""
                }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { geqShowCustomSaveDialog = false }) { Text("Cancel", color = CinemaGray) } },
            containerColor = CinemaSurface
        )
    }

    // Save Theatre Preset Dialog (shared store with the in-player Equalizer)
    if (geqShowSaveTheatrePresetDialog) {
        AlertDialog(
            onDismissRequest = { geqShowSaveTheatrePresetDialog = false },
            title = { Text("Save Theatre Setup", color = Color.White) },
            text = {
                OutlinedTextField(value = geqTheatrePresetNameInput, onValueChange = { geqTheatrePresetNameInput = it },
                    label = { Text("Preset Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CinemaSurface, unfocusedContainerColor = CinemaSurface,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = CinemaGold, unfocusedBorderColor = CinemaSurfaceLight
                    ))
            },
            confirmButton = {
                Button(onClick = {
                    if (geqTheatrePresetNameInput.isNotEmpty()) {
                        com.cinemapro.player.data.TheatrePresetStore.save(context, geqTheatrePresetNameInput, geqConfig)
                        geqSavedTheatrePresetNames = com.cinemapro.player.data.TheatrePresetStore.listNames(context)
                    }
                    geqShowSaveTheatrePresetDialog = false; geqTheatrePresetNameInput = ""
                }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { geqShowSaveTheatrePresetDialog = false }) { Text("Cancel", color = CinemaGray) } },
            containerColor = CinemaSurface
        )
    }
    }
}

@Composable
fun VideoGrid(videos: List<VideoItem>, onVideoSelected: (VideoItem) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(videos) { video ->
            VideoGridCard(video = video, onClick = { onVideoSelected(video) })
        }
    }
}

@Composable
fun VideoGridCard(video: VideoItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 10f)
            .tvFocusable(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CinemaSurface)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Thumbnail placeholder
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(CinemaSurfaceLight, CinemaSurface)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayCircle, null, tint = CinemaGold.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
            }

            // Bottom info overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f)))
                    )
                    .padding(8.dp)
            ) {
                Column {
                    Text(
                        video.title,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(formatDuration(video.duration), color = CinemaGold, fontSize = 11.sp)
                        Text(video.resolution, color = CinemaGray, fontSize = 11.sp)
                    }
                }
            }

            // Resolution badge
            if (video.resolution.contains("1080") || video.resolution.contains("2160") || video.resolution.contains("4K")) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            when {
                                video.resolution.contains("2160") || video.resolution.contains("4K") -> CinemaGold
                                video.resolution.contains("1080") -> CinemaBlue
                                else -> CinemaGreen
                            }
                        )
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        when {
                            video.resolution.contains("2160") || video.resolution.contains("4K") -> "4K"
                            video.resolution.contains("1080") -> "FHD"
                            else -> "HD"
                        },
                        color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun VideoList(videos: List<VideoItem>, onVideoSelected: (VideoItem) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(videos) { video ->
            VideoListRow(video = video, onClick = { onVideoSelected(video) })
        }
    }
}

@Composable
fun VideoListRow(video: VideoItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CinemaSurface)
            .tvFocusable(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Thumbnail
        Box(
            modifier = Modifier
                .size(72.dp, 48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(CinemaSurfaceLight),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayArrow, null, tint = CinemaGold, modifier = Modifier.size(28.dp))
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(video.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(formatDuration(video.duration), color = CinemaGold, fontSize = 12.sp)
                Text(video.resolution, color = CinemaGray, fontSize = 12.sp)
                Text(formatFileSize(video.fileSize), color = CinemaGray, fontSize = 12.sp)
            }
        }

        Icon(Icons.Default.PlayCircleOutline, null, tint = CinemaGold, modifier = Modifier.size(28.dp))
    }
}

@Composable
fun FolderView(folders: List<VideoFolder>, onVideoSelected: (VideoItem) -> Unit) {
    var expandedFolder by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(folders) { folder ->
            val isExpanded = expandedFolder == folder.path

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CinemaSurface)
            ) {
                // Folder header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(RoundedCornerShape(0.dp))
                        .clickable {
                            expandedFolder = if (isExpanded) null else folder.path
                        }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(Icons.Default.Folder, null, tint = CinemaGold, modifier = Modifier.size(32.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(folder.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("${folder.videos.size} videos", color = CinemaGray, fontSize = 13.sp)
                    }
                    Icon(
                        if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        null, tint = CinemaGray
                    )
                }

                // Expanded videos
                AnimatedVisibility(visible = isExpanded) {
                    Column {
                        HorizontalDivider(color = CinemaSurfaceLight)
                        folder.videos.forEach { video ->
                            VideoListRow(video = video, onClick = { onVideoSelected(video) })
                        }
                    }
                }
            }
        }
    }
}

// Load videos from MediaStore
suspend fun loadVideosFromDevice(context: Context): List<VideoItem> = withContext(Dispatchers.IO) {
    val videos = mutableListOf<VideoItem>()
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.TITLE,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.RESOLUTION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DATE_ADDED,
        MediaStore.Video.Media.DATA
    )

    try {
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val resCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.RESOLUTION)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val filePath = cursor.getString(dataCol) ?: ""
                videos.add(
                    VideoItem(
                        id = id,
                        title = cursor.getString(titleCol) ?: "Unknown",
                        uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()),
                        duration = cursor.getLong(durCol),
                        resolution = cursor.getString(resCol) ?: "Unknown",
                        fileSize = cursor.getLong(sizeCol),
                        folderPath = filePath.substringBeforeLast("/")
                    )
                )
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    videos
}

fun formatDuration(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000
    val m = s / 60
    val h = m / 60
    return if (h > 0) "%d:%02d:%02d".format(h, m % 60, s % 60)
    else "%d:%02d".format(m, s % 60)
}

fun formatFileSize(bytes: Long): String {
    return when {
        bytes >= 1_000_000_000 -> "%.1f GB".format(bytes / 1_000_000_000.0)
        bytes >= 1_000_000 -> "%.0f MB".format(bytes / 1_000_000.0)
        else -> "%.0f KB".format(bytes / 1_000.0)
    }
}
