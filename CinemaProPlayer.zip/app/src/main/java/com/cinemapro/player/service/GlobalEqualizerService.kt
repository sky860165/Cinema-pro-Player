package com.cinemapro.player.service

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.cinemapro.player.MainActivity
import com.cinemapro.player.R
import com.cinemapro.player.audio.CinemaDSPEngine
import com.cinemapro.player.data.model.EqualizerPreset
import com.cinemapro.player.data.model.SurroundMode

/**
 * Best-effort "system-wide" EQ service.
 *
 * IMPORTANT (read before assuming this is broken): Android does not let one
 * app reach into another app's private audio session. There is no public
 * API for that, root or not. This service only catches audio sessions from
 * apps that voluntarily broadcast AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION
 * when they start playback — some music players do this; most video apps,
 * including YouTube, do not. When such a broadcast is received, our EQ
 * attaches to that app's session for as long as it's open. Otherwise, the
 * EQ only affects audio played inside Cinema Pro Player itself.
 *
 * The service keeps running in the background (foreground service with a
 * persistent low-priority notification) until the user turns it off from
 * the gallery screen, the Equalizer panel, or the notification itself.
 */
class GlobalEqualizerService : Service() {

    companion object {
        private const val TAG = "GlobalEqualizerService"
        private const val CHANNEL_ID = "cinema_global_eq"
        private const val NOTIFICATION_ID = 9001
        const val ACTION_STOP = "com.cinemapro.player.action.STOP_GLOBAL_EQ"

        const val PREFS_NAME = "cinema_global_eq_prefs"
        const val KEY_ENABLED = "global_eq_enabled"
        private const val KEY_PRESET_ID = "global_eq_preset_id"
        private const val KEY_SURROUND = "global_eq_surround"
        private const val KEY_BASS = "global_eq_bass"

        fun isEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_ENABLED, false)
        }

        /** Persist the toggle + last-used settings so they survive process death and reflect across screens. */
        fun saveState(context: Context, enabled: Boolean, preset: EqualizerPreset? = null, surroundMode: SurroundMode? = null, bassLevel: Int? = null) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().apply {
                putBoolean(KEY_ENABLED, enabled)
                preset?.let { putString(KEY_PRESET_ID, it.id) }
                surroundMode?.let { putString(KEY_SURROUND, it.name) }
                bassLevel?.let { putInt(KEY_BASS, it) }
            }.apply()
        }
    }

    private lateinit var dspEngine: CinemaDSPEngine
    private lateinit var prefs: SharedPreferences
    private var receiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        dspEngine = CinemaDSPEngine(applicationContext)
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        registerSessionReceiver()
        startForeground(NOTIFICATION_ID, buildNotification())
        restoreLastSettings()
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean(KEY_ENABLED, false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun restoreLastSettings() {
        val presetId = prefs.getString(KEY_PRESET_ID, null)
        val preset = presetId?.let { id -> EqualizerPreset.ALL_PRESETS.firstOrNull { it.id == id } }
            ?: EqualizerPreset.FLAT
        val surroundName = prefs.getString(KEY_SURROUND, SurroundMode.AUTO.name)
        val surroundMode = try { SurroundMode.valueOf(surroundName ?: SurroundMode.AUTO.name) } catch (e: Exception) { SurroundMode.AUTO }
        val bassLevel = prefs.getInt(KEY_BASS, 50)

        // Effects don't attach until a real session id arrives via broadcast,
        // but we store the preset/surround/bass now so attachToExternalSession()
        // applies them immediately when that happens.
        dspEngine.setPendingConfig(preset, surroundMode, bassLevel)
    }

    private fun registerSessionReceiver() {
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val sessionId = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
                if (sessionId == 0) return
                // CRITICAL: ExoPlayer/Media3 also broadcasts
                // ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION for our OWN
                // in-app player. If this service's package name matches
                // the sender, that means it's Cinema Pro Player's own
                // playback session — which already has its own Equalizer/
                // BassBoost/Virtualizer/LoudnessEnhancer attached by
                // CinemaProPlayerScreen's dspEngine. Attaching a SECOND,
                // competing set of the same effect types (both at
                // PRIORITY 0) to that same session causes Android to hand
                // control to whichever one attached last and silently
                // deactivate/release the other — which is why audio could
                // go completely silent after this service had ever been
                // turned on. We only want effects from OTHER apps here.
                val ownPackage = context.packageName
                val senderPackage = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
                if (senderPackage == ownPackage) {
                    Log.d(TAG, "Ignoring own app's session $sessionId (handled by in-app DSP already)")
                    return
                }
                when (intent.action) {
                    AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                        Log.d(TAG, "External audio session opened: $sessionId")
                        dspEngine.attachToExternalSession(sessionId)
                    }
                    AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                        Log.d(TAG, "External audio session closed: $sessionId")
                        dspEngine.detachExternalSession(sessionId)
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Cinema Pro Equalizer",
                NotificationManager.IMPORTANCE_MIN
            ).apply { description = "Keeps the equalizer active in the background" }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, GlobalEqualizerService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Cinema Pro Equalizer Active")
            .setContentText("Applying your EQ to supported apps")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(contentIntent)
            .addAction(0, "Turn Off", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        receiver?.let { unregisterReceiver(it) }
        dspEngine.release()
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        super.onDestroy()
    }
}
