package com.cinemapro.player.service

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.media.audiofx.AudioEffect
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.cinemapro.player.MainActivity
import com.cinemapro.player.R
import com.cinemapro.player.audio.CinemaDSPEngine
import com.cinemapro.player.data.model.CinemaAudioConfig
import com.cinemapro.player.data.model.DynamicRangeMode
import com.cinemapro.player.data.model.EqualizerPreset
import com.cinemapro.player.data.model.SurroundMode
import com.cinemapro.player.data.model.TheatreRoomSize

/**
 * System-wide EQ service.
 *
 * Attaches directly to the device's OUTPUT MIX (AudioEffect session id 0),
 * which is the platform-documented way to process every app's audio
 * together — the same mechanism other system-wide EQ/bass-booster apps use,
 * and it needs no cooperation from the other app (works on YouTube, Netflix,
 * etc., not just apps that opt in). As a secondary path, this service also
 * listens for apps that voluntarily broadcast
 * AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION for their own private
 * session — but since the output mix already covers those apps too, that
 * path only matters for apps whose own session-level effects would
 * otherwise conflict with the mix-level ones (see attachToExternalSession()
 * in CinemaDSPEngine).
 *
 * The service keeps running in the background (foreground service with a
 * persistent low-priority notification) until the user turns it off from
 * the gallery screen, the Equalizer panel, or the notification itself.
 * Note: the notification itself needs POST_NOTIFICATIONS granted (Android
 * 13+) to actually be visible — the service keeps running either way.
 */
class GlobalEqualizerService : Service() {

    companion object {
        private const val TAG = "GlobalEqualizerService"
        private const val CHANNEL_ID = "cinema_global_eq"
        private const val NOTIFICATION_ID = 9001
        const val ACTION_STOP = "com.cinemapro.player.action.STOP_GLOBAL_EQ"
        // Sent by the UI after it has already written new settings to
        // prefs — tells a service instance that's already running (already
        // attached to some other app's session) to re-read and apply them
        // immediately, instead of waiting for that session to reattach.
        const val ACTION_UPDATE = "com.cinemapro.player.action.UPDATE_GLOBAL_EQ"

        const val PREFS_NAME = "cinema_global_eq_prefs"
        const val KEY_ENABLED = "global_eq_enabled"
        private const val KEY_PRESET_ID = "global_eq_preset_id"
        private const val KEY_PRESET_NAME = "global_eq_preset_name"
        private const val KEY_PRESET_BANDS = "global_eq_preset_bands"
        private const val KEY_SURROUND = "global_eq_surround"
        private const val KEY_BASS = "global_eq_bass"
        // ── Full config (everything else the main-screen Equalizer panel
        // can touch) — kept as individual typed keys, not a serialized
        // blob, so a partial write can never corrupt the whole thing. ──
        private const val KEY_VIRT_STRENGTH = "global_eq_virt_strength"
        private const val KEY_DIALOG_ENH = "global_eq_dialog_enh"
        private const val KEY_NIGHT_MODE = "global_eq_night_mode"
        private const val KEY_VOL_NORM = "global_eq_vol_norm"
        private const val KEY_VOL_ENH = "global_eq_vol_enh"
        private const val KEY_LOUDNESS_TARGET = "global_eq_loudness_target"
        private const val KEY_THEATRE_ROOM = "global_eq_theatre_room"
        private const val KEY_XCURVE_EN = "global_eq_xcurve_en"
        private const val KEY_XCURVE_INT = "global_eq_xcurve_int"
        private const val KEY_THX = "global_eq_thx"
        private const val KEY_LFE = "global_eq_lfe"
        private const val KEY_BASS_XOVER = "global_eq_bass_xover"
        private const val KEY_HEIGHT_LVL = "global_eq_height_lvl"
        private const val KEY_CENTER_LVL = "global_eq_center_lvl"
        private const val KEY_DYNAMIC_RANGE = "global_eq_dynamic_range"
        private const val KEY_FRONT_TRIM = "global_eq_front_trim"
        private const val KEY_CENTER_TRIM = "global_eq_center_trim"
        private const val KEY_SURROUND_TRIM = "global_eq_surround_trim"
        private const val KEY_THEATRE_MODE = "global_eq_theatre_mode"
        private const val KEY_AB_BYPASS = "global_eq_ab_bypass"
        private const val KEY_EXTREME_BASS = "global_eq_extreme_bass"
        private const val KEY_EXTREME_LOUD = "global_eq_extreme_loud"
        private const val KEY_HAPTIC_EN = "global_eq_haptic_en"
        private const val KEY_HAPTIC_INT = "global_eq_haptic_int"
        private const val KEY_MASTER_BOOST = "global_eq_master_boost"
        private const val KEY_LIMITER_EN = "global_eq_limiter_en"
        private const val KEY_AUDIO_CLEAN = "global_eq_audio_clean"

        fun isEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_ENABLED, false)
        }

        /** Persist the toggle + last-used settings so they survive process death and reflect across screens. */
        fun saveState(context: Context, enabled: Boolean, preset: EqualizerPreset? = null, surroundMode: SurroundMode? = null, bassLevel: Int? = null) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().apply {
                putBoolean(KEY_ENABLED, enabled)
                preset?.let { putString(KEY_PRESET_ID, it.id) }
                surroundMode?.let { putString(KEY_SURROUND, it.name) }
                bassLevel?.let { putInt(KEY_BASS, it) }
            }.apply()
        }

        /** Read back whatever preset (built-in or custom) was last saved for the Global Equalizer. */
        fun getStoredPreset(context: Context): EqualizerPreset {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val id = prefs.getString(KEY_PRESET_ID, null) ?: return EqualizerPreset.FLAT
            if (id == "custom") {
                val name = prefs.getString(KEY_PRESET_NAME, "Custom") ?: "Custom"
                val bandsStr = prefs.getString(KEY_PRESET_BANDS, null)
                val bands = bandsStr?.split(",")?.mapNotNull { it.toFloatOrNull() }?.toFloatArray()
                    ?: FloatArray(15) { 0f }
                return EqualizerPreset(id, name, bands, isBuiltIn = false)
            }
            return EqualizerPreset.ALL_PRESETS.firstOrNull { it.id == id } ?: EqualizerPreset.FLAT
        }

        /** Persist the full preset (including custom band values) the Global Equalizer should use. */
        fun savePreset(context: Context, preset: EqualizerPreset) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString(KEY_PRESET_ID, preset.id)
                putString(KEY_PRESET_NAME, preset.name)
                putString(KEY_PRESET_BANDS, preset.bands.joinToString(","))
            }.apply()
        }

        /** Read back the full theatre/DSP config last saved for the Global Equalizer. */
        fun getStoredConfig(context: Context): CinemaAudioConfig {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val default = CinemaAudioConfig()
            fun surround() = try {
                SurroundMode.valueOf(prefs.getString(KEY_SURROUND, default.surroundMode.name) ?: default.surroundMode.name)
            } catch (e: Exception) { default.surroundMode }
            fun room() = try {
                TheatreRoomSize.valueOf(prefs.getString(KEY_THEATRE_ROOM, default.theatreRoomSize.name) ?: default.theatreRoomSize.name)
            } catch (e: Exception) { default.theatreRoomSize }
            fun dynRange() = try {
                DynamicRangeMode.valueOf(prefs.getString(KEY_DYNAMIC_RANGE, default.dynamicRangeMode.name) ?: default.dynamicRangeMode.name)
            } catch (e: Exception) { default.dynamicRangeMode }
            return CinemaAudioConfig(
                surroundMode = surround(),
                bassLevel = prefs.getInt(KEY_BASS, default.bassLevel),
                virtualizerStrength = prefs.getInt(KEY_VIRT_STRENGTH, default.virtualizerStrength),
                dialogEnhancement = prefs.getBoolean(KEY_DIALOG_ENH, default.dialogEnhancement),
                nightMode = prefs.getBoolean(KEY_NIGHT_MODE, default.nightMode),
                volumeNormalization = prefs.getBoolean(KEY_VOL_NORM, default.volumeNormalization),
                volumeEnhancement = prefs.getInt(KEY_VOL_ENH, default.volumeEnhancement),
                loudnessTarget = prefs.getInt(KEY_LOUDNESS_TARGET, default.loudnessTarget),
                theatreRoomSize = room(),
                xCurveEnabled = prefs.getBoolean(KEY_XCURVE_EN, default.xCurveEnabled),
                xCurveIntensity = prefs.getInt(KEY_XCURVE_INT, default.xCurveIntensity),
                thxReEqEnabled = prefs.getBoolean(KEY_THX, default.thxReEqEnabled),
                lfeLevel = prefs.getInt(KEY_LFE, default.lfeLevel),
                bassCrossoverHz = prefs.getInt(KEY_BASS_XOVER, default.bassCrossoverHz),
                heightChannelLevel = prefs.getInt(KEY_HEIGHT_LVL, default.heightChannelLevel),
                centerChannelLevel = prefs.getInt(KEY_CENTER_LVL, default.centerChannelLevel),
                dynamicRangeMode = dynRange(),
                frontTrimDb = prefs.getInt(KEY_FRONT_TRIM, default.frontTrimDb),
                centerTrimDb = prefs.getInt(KEY_CENTER_TRIM, default.centerTrimDb),
                surroundTrimDb = prefs.getInt(KEY_SURROUND_TRIM, default.surroundTrimDb),
                theatreModeEnabled = prefs.getBoolean(KEY_THEATRE_MODE, default.theatreModeEnabled),
                abCompareBypassed = prefs.getBoolean(KEY_AB_BYPASS, default.abCompareBypassed),
                extremeBassMode = prefs.getBoolean(KEY_EXTREME_BASS, default.extremeBassMode),
                extremeLoudnessMode = prefs.getBoolean(KEY_EXTREME_LOUD, default.extremeLoudnessMode),
                hapticBassSyncEnabled = prefs.getBoolean(KEY_HAPTIC_EN, default.hapticBassSyncEnabled),
                hapticBassSyncIntensity = prefs.getInt(KEY_HAPTIC_INT, default.hapticBassSyncIntensity),
                masterBoostDb = prefs.getInt(KEY_MASTER_BOOST, default.masterBoostDb),
                limiterEnabled = prefs.getBoolean(KEY_LIMITER_EN, default.limiterEnabled),
                audioCleanModeEnabled = prefs.getBoolean(KEY_AUDIO_CLEAN, default.audioCleanModeEnabled)
            )
        }

        /** Persist the full theatre/DSP config for the Global Equalizer. */
        fun saveConfig(context: Context, config: CinemaAudioConfig) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString(KEY_SURROUND, config.surroundMode.name)
                putInt(KEY_BASS, config.bassLevel)
                putInt(KEY_VIRT_STRENGTH, config.virtualizerStrength)
                putBoolean(KEY_DIALOG_ENH, config.dialogEnhancement)
                putBoolean(KEY_NIGHT_MODE, config.nightMode)
                putBoolean(KEY_VOL_NORM, config.volumeNormalization)
                putInt(KEY_VOL_ENH, config.volumeEnhancement)
                putInt(KEY_LOUDNESS_TARGET, config.loudnessTarget)
                putString(KEY_THEATRE_ROOM, config.theatreRoomSize.name)
                putBoolean(KEY_XCURVE_EN, config.xCurveEnabled)
                putInt(KEY_XCURVE_INT, config.xCurveIntensity)
                putBoolean(KEY_THX, config.thxReEqEnabled)
                putInt(KEY_LFE, config.lfeLevel)
                putInt(KEY_BASS_XOVER, config.bassCrossoverHz)
                putInt(KEY_HEIGHT_LVL, config.heightChannelLevel)
                putInt(KEY_CENTER_LVL, config.centerChannelLevel)
                putString(KEY_DYNAMIC_RANGE, config.dynamicRangeMode.name)
                putInt(KEY_FRONT_TRIM, config.frontTrimDb)
                putInt(KEY_CENTER_TRIM, config.centerTrimDb)
                putInt(KEY_SURROUND_TRIM, config.surroundTrimDb)
                putBoolean(KEY_THEATRE_MODE, config.theatreModeEnabled)
                putBoolean(KEY_AB_BYPASS, config.abCompareBypassed)
                putBoolean(KEY_EXTREME_BASS, config.extremeBassMode)
                putBoolean(KEY_EXTREME_LOUD, config.extremeLoudnessMode)
                putBoolean(KEY_HAPTIC_EN, config.hapticBassSyncEnabled)
                putInt(KEY_HAPTIC_INT, config.hapticBassSyncIntensity)
                putInt(KEY_MASTER_BOOST, config.masterBoostDb)
                putBoolean(KEY_LIMITER_EN, config.limiterEnabled)
                putBoolean(KEY_AUDIO_CLEAN, config.audioCleanModeEnabled)
            }.apply()
        }

        /**
         * One-call entry point for the UI: persist the new preset+config,
         * then make sure the service is running (starting it if needed —
         * this is what keeps it "hamesha background me chalu" once the
         * main-screen Global Equalizer is opened) and push the change to
         * whatever external session might already be attached.
         */
        fun pushUpdate(context: Context, preset: EqualizerPreset, config: CinemaAudioConfig) {
            savePreset(context, preset)
            saveConfig(context, config)
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_ENABLED, true).apply()
            val intent = Intent(context, GlobalEqualizerService::class.java).apply { action = ACTION_UPDATE }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        /** Start (or no-op if already running) the always-on Global Equalizer service. */
        fun start(context: Context) {
            val intent = Intent(context, GlobalEqualizerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, GlobalEqualizerService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }

    private lateinit var dspEngine: CinemaDSPEngine
    private lateinit var prefs: SharedPreferences
    private var receiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        dspEngine = CinemaDSPEngine(applicationContext)
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        registerSessionReceiver()
        startForeground(NOTIFICATION_ID, buildNotification())
        // Attach to the device's whole output mix FIRST — this is what
        // actually makes the EQ affect YouTube/Netflix/etc. without them
        // cooperating, same as other system-wide EQ apps. The broadcast
        // receiver above is a secondary path for apps whose own session
        // effects would otherwise conflict with the mix-level ones.
        dspEngine.attachToGlobalMix()
        restoreLastSettings()
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.edit().putBoolean(KEY_ENABLED, false).apply()
                dspEngine.detachGlobalMix()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                // Defensive re-attach in case the output-mix effects ever
                // got released from under us (e.g. audio server restart),
                // then push the latest settings — see restoreLastSettings().
                dspEngine.attachToGlobalMix()
                restoreLastSettings()
            }
        }
        return START_STICKY
    }

    private fun restoreLastSettings() {
        val preset = getStoredPreset(applicationContext)
        val config = getStoredConfig(applicationContext)
        // updateConfig() both stores this as the pending config for the next
        // session to attach to, AND — if a session is already attached —
        // applies it immediately.
        dspEngine.updateConfig(preset, config)
    }

    private fun registerSessionReceiver() {
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val sessionId = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, 0)
                if (sessionId == 0) return
                // CRITICAL: ExoPlayer/Media3 also broadcasts
                // ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION for our OWN
                // in-app player. If this service's package name matches
                // the sender, that means it's Cinema Pro Player's own
                // playback session — which already has its own Equalizer/
                // BassBoost/Virtualizer/LoudnessEnhancer attached by
                // CinemaProPlayerScreen's dspEngine. Attaching a SECOND,
                // competing set of the same effect types (both at
                // PRIORITY 0) to that same session causes Android to hand
                // control to whichever one attached last and silently
                // deactivate/release the other — which is why audio could
                // go completely silent after this service had ever been
                // turned on. We only want effects from OTHER apps here.
                val ownPackage = context.packageName
                val senderPackage = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
                if (senderPackage == ownPackage) {
                    Log.d(TAG, "Ignoring own app's session $sessionId (handled by in-app DSP already)")
                    return
                }
                when (intent.action) {
                    AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                        Log.d(TAG, "External audio session opened: $sessionId")
                        dspEngine.attachToExternalSession(sessionId)
                    }
                    AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                        Log.d(TAG, "External audio session closed: $sessionId")
                        dspEngine.detachExternalSession(sessionId)
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Cinema Pro Equalizer",
                NotificationManager.IMPORTANCE_MIN
            ).apply { description = "Keeps the equalizer active in the background" }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, GlobalEqualizerService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Cinema Pro Equalizer Active")
            .setContentText("Applying your EQ to supported apps")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(contentIntent)
            .addAction(0, "Turn Off", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        receiver?.let { unregisterReceiver(it) }
        dspEngine.release()
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        super.onDestroy()
    }
}
