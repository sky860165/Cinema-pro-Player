package com.cinemapro.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.cinemapro.player.ui.screens.CinemaProPlayerScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class PlayerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val videoUri = intent?.getStringExtra("video_uri") ?: ""
        val videoTitle = intent?.getStringExtra("video_title") ?: ""

        setContent {
            CinemaProTheme {
                CinemaProPlayerScreen(
                    videoUri = videoUri,
                    videoTitle = videoTitle,
                    onBackPressed = { finish() }
                )
            }
        }
    }
}
