package com.cinemapro.player

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.cinemapro.player.ui.screens.CinemaProPlayerScreen
import com.cinemapro.player.ui.theme.CinemaProTheme
import kotlinx.coroutines.launch

class PlayerActivity : ComponentActivity() {

    private var onPipChangedCallback: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // NO forced orientation — player opens in portrait by default
        // User can lock/unlock rotation via the button in controls

        // IMPORTANT: videos reaching PlayerActivity come from our own
        // in-app gallery (VideoGalleryScreen), backed by MediaStore +
        // READ_MEDIA_VIDEO — these ARE stable for normal playback. But on
        // some OEM devices (MIUI in particular), even a MediaStore
        // content:// uri can fail to reopen reliably when the effects
        // pipeline does its clearMediaItems()+reload for AI 4K/3D mode,
        // throwing the same FileNotFoundException seen with external
        // "Open with" uris. So we resolve here too, the same
        // ANR-safe way as MainActivity: play immediately off the original
        // uri, resolve the safe local copy on a background thread, and
        // swap videoUri via Compose state once it's ready.
        val originalUri = intent?.data
        var resolvedUriState by androidx.compose.runtime.mutableStateOf(originalUri?.toString() ?: "")

        if (originalUri?.scheme == "content") {
            kotlinx.coroutines.MainScope().launch {
                val resolved = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.cinemapro.player.util.PlaybackUriResolver.resolve(this@PlayerActivity, originalUri)
                }
                resolvedUriState = resolved?.toString() ?: originalUri.toString()
            }
        }

        val videoTitle = intent?.getStringExtra("VIDEO_TITLE") ?: ""
        val videoId    = intent?.getLongExtra("VIDEO_ID", -1L) ?: -1L

        setContent {
            val videoUri = resolvedUriState
            CinemaProTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    CinemaProPlayerScreen(
                        videoUri    = videoUri,
                        videoTitle  = videoTitle,
                        videoId     = videoId,
                        onBackPressed = { finish() },
                        onEnterPip  = { enterPipMode() },
                        onPipChanged = { callback -> onPipChangedCallback = callback }
                    )
                }
            }
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        onPipChangedCallback?.invoke(isInPip)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PIP when home pressed during playback
        enterPipMode()
    }
}
