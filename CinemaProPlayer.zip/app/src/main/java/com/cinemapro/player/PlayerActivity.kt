package com.cinemapro.player

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.cinemapro.player.ui.screens.CinemaProPlayerScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class PlayerActivity : ComponentActivity() {

    private var onPipChangedCallback: ((Boolean) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // NO forced orientation — player opens in portrait by default
        // User can lock/unlock rotation via the button in controls

        val videoUri   = intent?.data?.toString() ?: ""
        val videoTitle = intent?.getStringExtra("VIDEO_TITLE") ?: ""
        val videoId    = intent?.getLongExtra("VIDEO_ID", -1L) ?: -1L

        setContent {
            CinemaProTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
                    CinemaProPlayerScreen(
                        videoUri    = videoUri,
                        videoTitle  = videoTitle,
                        videoId     = videoId,
                        onBackPressed = { finish() },
                        onEnterPip  = { enterPipMode() },
                        onPipChanged = { callback -> onPipChangedCallback = callback }
                    )
                }
            }
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Tell the Compose screen we're going into PIP BEFORE calling
            // enterPictureInPictureMode(). This matters because Android
            // fires the Activity's ON_PAUSE lifecycle event synchronously
            // as part of that call, while onPictureInPictureModeChanged()
            // below arrives asynchronously afterward. The Compose screen's
            // lifecycle observer used to only know "are we in PIP?" from
            // onPictureInPictureModeChanged, so on ON_PAUSE it still saw
            // isPipMode == false and paused the player — which is exactly
            // why video froze/paused the instant PIP opened. Flipping the
            // flag here, synchronously, closes that race.
            onPipChangedCallback?.invoke(true)
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPip: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPip, newConfig)
        // This is still the source of truth for LEAVING PIP (isInPip ==
        // false) and confirms entry too — safe to call again with the same
        // value we already pushed in enterPipMode().
        onPipChangedCallback?.invoke(isInPip)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PIP when home pressed during playback
        enterPipMode()
    }
}
