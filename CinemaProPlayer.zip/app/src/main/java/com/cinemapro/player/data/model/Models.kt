package com.cinemapro.player.data.model

import android.net.Uri
import androidx.room.Entity
import androidx.room.PrimaryKey

// ===================== VIDEO ITEM =====================
data class VideoItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val duration: Long = 0,
    val resolution: String = "Unknown",
    val fileSize: Long = 0,
    val dateAdded: Long = 0,
    val is3D: Boolean = false,
    val thumbnailPath: String? = null,
    val folderPath: String = "",
    val audioTracks: List<AudioTrack> = emptyList(),
    val subtitleTracks: List<SubtitleTrack> = emptyList(),
    val lastPosition: Long = 0
)

// ===================== AUDIO TRACK =====================
data class AudioTrack(
    val id: String,
    val language: String,
    val label: String,
    val mimeType: String = "audio/mp4a-latm",
    val channelCount: Int = 2,
    val sampleRate: Int = 48000,
    val bitrate: Int = 0,
    val isDefault: Boolean = false,
    val isSelected: Boolean = false
)

// ===================== SUBTITLE TRACK =====================
data class SubtitleTrack(
    val id: String,
    val language: String,
    val label: String,
    val mimeType: String = "text/vtt",
    val uri: Uri? = null,
    val isExternal: Boolean = false,
    val isSelected: Boolean = false
)

// ===================== EQUALIZER PRESET =====================
@Entity(tableName = "equalizer_presets")
data class EqualizerPresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val band0: Float = 0f,
    val band1: Float = 0f,
    val band2: Float = 0f,
    val band3: Float = 0f,
    val band4: Float = 0f,
    val band5: Float = 0f,
    val band6: Float = 0f,
    val band7: Float = 0f,
    val band8: Float = 0f,
    val band9: Float = 0f,
    val band10: Float = 0f,
    val band11: Float = 0f,
    val band12: Float = 0f,
    val band13: Float = 0f,
    val band14: Float = 0f,
    val bassBoost: Float = 0f,
    val virtualizer: Float = 0f,
    val reverb: Int = 0,
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ===================== EQUALIZER PRESET (UI Model) =====================
data class EqualizerPreset(
    val id: String,
    val name: String,
    val bands: FloatArray,
    val bassBoost: Float = 0f,
    val virtualizer: Float = 0f,
    val reverb: Int = 0,
    val isBuiltIn: Boolean = false
) {
    companion object {
        val FLAT = EqualizerPreset("flat", "Flat", FloatArray(15) { 0f }, isBuiltIn = true)
        val ROCK = EqualizerPreset("rock", "Rock", floatArrayOf(4f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 5f, 4f, 3f, 2f), bassBoost = 3f, isBuiltIn = true)
        val POP = EqualizerPreset("pop", "Pop", floatArrayOf(-1f, 2f, 4f, 5f, 4f, 2f, 0f, -1f, -2f, -2f, -1f, 0f, 1f, 2f, 3f), bassBoost = 2f, isBuiltIn = true)
        val CLASSICAL = EqualizerPreset("classical", "Classical", floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, -2f, -2f, -2f, 0f, 2f, 3f, 3f, 3f), isBuiltIn = true)
        val JAZZ = EqualizerPreset("jazz", "Jazz", floatArrayOf(0f, 0f, 0f, 2f, 3f, 3f, 3f, 2f, 1f, 1f, 2f, 3f, 4f, 4f, 3f), bassBoost = 1f, isBuiltIn = true)
        val BASS_BOOST = EqualizerPreset("bass_boost", "Bass Boost", FloatArray(15) { if (it < 5) 6f else 0f }, bassBoost = 8f, isBuiltIn = true)
        val TREBLE_BOOST = EqualizerPreset("treble_boost", "Treble Boost", FloatArray(15) { if (it > 9) 6f else 0f }, isBuiltIn = true)
        val VOCAL_BOOST = EqualizerPreset("vocal_boost", "Vocal Boost", FloatArray(15) { if (it in 5..9) 4f else 0f }, isBuiltIn = true)
        val ELECTRONIC = EqualizerPreset("electronic", "Electronic", floatArrayOf(5f, 4f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 5f, 4f, 3f), bassBoost = 5f, virtualizer = 6f, isBuiltIn = true)
        val HIP_HOP = EqualizerPreset("hip_hop", "Hip Hop", floatArrayOf(5f, 4f, 3f, 2f, 1f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 4f, 3f, 2f), bassBoost = 6f, isBuiltIn = true)
        val MOVIE = EqualizerPreset("movie", "Cinema Movie", floatArrayOf(3f, 3f, 2f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 3f, 3f, 2f, 2f, 1f), bassBoost = 4f, virtualizer = 5f, isBuiltIn = true)
        val ACTION = EqualizerPreset("action", "Action", floatArrayOf(4f, 4f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 5f, 4f, 3f), bassBoost = 7f, virtualizer = 8f, isBuiltIn = true)
        val HORROR = EqualizerPreset("horror", "Horror", floatArrayOf(2f, 3f, 4f, 3f, 2f, 1f, 0f, -1f, -2f, -1f, 0f, 1f, 2f, 3f, 2f), reverb = 3, isBuiltIn = true)
        val ROMANCE = EqualizerPreset("romance", "Romance", floatArrayOf(0f, 1f, 2f, 3f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 3f, 2f, 1f), isBuiltIn = true)
        val NIGHT = EqualizerPreset("night", "Late Night", FloatArray(15) { -3f }, bassBoost = 2f, isBuiltIn = true)
        val LOUDNESS = EqualizerPreset("loudness", "Loudness", floatArrayOf(2f, 2f, 1f, 1f, 0f, 0f, 0f, 0f, 1f, 1f, 2f, 2f, 3f, 3f, 2f), isBuiltIn = true)
        val DANCE = EqualizerPreset("dance", "Dance", floatArrayOf(4f, 5f, 4f, 2f, 0f, -1f, -2f, -2f, 0f, 2f, 4f, 5f, 5f, 4f, 3f), bassBoost = 6f, virtualizer = 7f, isBuiltIn = true)
        val ACOUSTIC = EqualizerPreset("acoustic", "Acoustic", floatArrayOf(0f, 1f, 2f, 3f, 3f, 2f, 1f, 1f, 2f, 3f, 3f, 2f, 1f, 0f, 0f), isBuiltIn = true)

        val ALL_PRESETS = listOf(
            FLAT, ROCK, POP, CLASSICAL, JAZZ, BASS_BOOST, TREBLE_BOOST,
            VOCAL_BOOST, ELECTRONIC, HIP_HOP, MOVIE, ACTION, HORROR,
            ROMANCE, NIGHT, LOUDNESS, DANCE, ACOUSTIC
        )
    }

    fun toEntity(): EqualizerPresetEntity {
        return EqualizerPresetEntity(
            id = id,
            name = name,
            band0 = bands.getOrElse(0) { 0f },
            band1 = bands.getOrElse(1) { 0f },
            band2 = bands.getOrElse(2) { 0f },
            band3 = bands.getOrElse(3) { 0f },
            band4 = bands.getOrElse(4) { 0f },
            band5 = bands.getOrElse(5) { 0f },
            band6 = bands.getOrElse(6) { 0f },
            band7 = bands.getOrElse(7) { 0f },
            band8 = bands.getOrElse(8) { 0f },
            band9 = bands.getOrElse(9) { 0f },
            band10 = bands.getOrElse(10) { 0f },
            band11 = bands.getOrElse(11) { 0f },
            band12 = bands.getOrElse(12) { 0f },
            band13 = bands.getOrElse(13) { 0f },
            band14 = bands.getOrElse(14) { 0f },
            bassBoost = bassBoost,
            virtualizer = virtualizer,
            reverb = reverb,
            isBuiltIn = isBuiltIn
        )
    }
}

fun EqualizerPresetEntity.toPreset(): EqualizerPreset {
    return EqualizerPreset(
        id = id,
        name = name,
        bands = floatArrayOf(band0, band1, band2, band3, band4, band5, band6, band7, band8, band9, band10, band11, band12, band13, band14),
        bassBoost = bassBoost,
        virtualizer = virtualizer,
        reverb = reverb,
        isBuiltIn = isBuiltIn
    )
}

// ===================== CINEMA AUDIO CONFIG =====================
data class CinemaAudioConfig(
    val surroundMode: SurroundMode = SurroundMode.AUTO,
    val bassLevel: Int = 50,
    val virtualizerStrength: Int = 50,
    val dialogEnhancement: Boolean = false,
    val nightMode: Boolean = false,
    val volumeNormalization: Boolean = true,
    val loudnessTarget: Int = -14
)

// ===================== VIDEO QUALITY =====================
enum class VideoQuality(val label: String, val width: Int, val height: Int) {
    AUTO("AUTO", 0, 0),
    SD_480P("480P", 854, 480),
    HD_720P("720P", 1280, 720),
    FHD_1080P("1080P", 1920, 1080),
    QHD_1440P("1440P", 2560, 1440),
    UHD_4K("4K", 3840, 2160),
    UHD_8K("8K", 7680, 4320)
}

// ===================== UPSCALE MODE =====================
enum class UpscaleMode(val label: String) {
    OFF("Off"),
    AI_4K("AI 4K"),
    AI_8K("AI 8K"),
    SUPER_RESOLUTION("Super Resolution"),
    SHARPEN("Sharpen"),
    DENOISE("Denoise"),
    HDR_SIMULATION("HDR Simulation")
}

// ===================== 3D VIDEO MODE =====================
enum class VideoMode3D(val label: String) {
    OFF("2D Mode"),
    SBS("Side-by-Side 3D"),
    TAB("Top-and-Bottom 3D"),
    ANAGLYPH("Anaglyph 3D"),
    VR_360("VR 360°"),
    VR_180("VR 180°"),
    STEREOSCOPIC("Stereoscopic")
}

// ===================== SURROUND MODE =====================
enum class SurroundMode(val label: String, val description: String) {
    STEREO("Stereo", "2.0 Channel"),
    VIRTUAL_5_1("5.1", "Virtual 5.1 Surround"),
    VIRTUAL_5_1_2("5.1.2", "Virtual 5.1.2 Atmos"),
    VIRTUAL_7_1("7.1", "Virtual 7.1 Surround"),
    ATMOS_3D("Atmos 3D", "Dolby Atmos 3D Audio"),
    AUTO("Auto", "Auto Detect")
}

// ===================== PLAYBACK SPEED =====================
enum class PlaybackSpeed(val value: Float, val label: String) {
    SLOW_0_5(0.5f, "0.5x"),
    SLOW_0_75(0.75f, "0.75x"),
    NORMAL(1.0f, "1.0x"),
    FAST_1_25(1.25f, "1.25x"),
    FAST_1_5(1.5f, "1.5x"),
    FAST_1_75(1.75f, "1.75x"),
    FAST_2_0(2.0f, "2.0x")
}

// ===================== APP SETTINGS =====================
@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val defaultQuality: VideoQuality = VideoQuality.AUTO,
    val defaultUpscale: UpscaleMode = UpscaleMode.OFF,
    val defaultSurroundMode: SurroundMode = SurroundMode.AUTO,
    val default3DMode: VideoMode3D = VideoMode3D.OFF,
    val rememberPosition: Boolean = true,
    val autoPlayNext: Boolean = true,
    val hardwareAcceleration: Boolean = true,
    val subtitleSize: Float = 1.0f,
    val subtitleColor: String = "#FFFFFF",
    val subtitleBackground: String = "#80000000",
    val subtitleOutline: Boolean = true,
    val gestureControls: Boolean = true,
    val doubleTapSeek: Boolean = true,
    val seekDuration: Int = 10,
    val screenTimeout: Int = 0
)

// ===================== PLAYER STATE =====================
sealed class PlayerState {
    object Idle : PlayerState()
    object Loading : PlayerState()
    data class Playing(val position: Long, val duration: Long) : PlayerState()
    data class Paused(val position: Long, val duration: Long) : PlayerState()
    data class Error(val message: String) : PlayerState()
    object Completed : PlayerState()
}
