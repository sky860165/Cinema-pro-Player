package com.cinemapro.player.data.model

import android.net.Uri
import androidx.room.Entity
import androidx.room.PrimaryKey

// ===================== VIDEO ITEM =====================
data class VideoItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val duration: Long = 0,
    val resolution: String = "Unknown",
    val fileSize: Long = 0,
    val dateAdded: Long = 0,
    val is3D: Boolean = false,
    val thumbnailPath: String? = null,
    val folderPath: String = "",
    val audioTracks: List<AudioTrack> = emptyList(),
    val subtitleTracks: List<SubtitleTrack> = emptyList(),
    val lastPosition: Long = 0
)

// ===================== AUDIO TRACK =====================
data class AudioTrack(
    val id: String,
    val language: String,
    val label: String,
    val mimeType: String = "audio/mp4a-latm",
    val channelCount: Int = 2,
    val sampleRate: Int = 48000,
    val bitrate: Int = 0,
    val isDefault: Boolean = false,
    val isSelected: Boolean = false
)

// ===================== SUBTITLE TRACK =====================
data class SubtitleTrack(
    val id: String,
    val language: String,
    val label: String,
    val mimeType: String = "text/vtt",
    val uri: Uri? = null,
    val isExternal: Boolean = false,
    val isSelected: Boolean = false
)

// ===================== EQUALIZER PRESET =====================
@Entity(tableName = "equalizer_presets")
data class EqualizerPresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val band0: Float = 0f,
    val band1: Float = 0f,
    val band2: Float = 0f,
    val band3: Float = 0f,
    val band4: Float = 0f,
    val band5: Float = 0f,
    val band6: Float = 0f,
    val band7: Float = 0f,
    val band8: Float = 0f,
    val band9: Float = 0f,
    val band10: Float = 0f,
    val band11: Float = 0f,
    val band12: Float = 0f,
    val band13: Float = 0f,
    val band14: Float = 0f,
    val bassBoost: Float = 0f,
    val virtualizer: Float = 0f,
    val reverb: Int = 0,
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ===================== EQUALIZER PRESET (UI Model) =====================
data class EqualizerPreset(
    val id: String,
    val name: String,
    val bands: FloatArray,
    val bassBoost: Float = 0f,
    val virtualizer: Float = 0f,
    val reverb: Int = 0,
    val isBuiltIn: Boolean = false,
    val isPremium: Boolean = false
) {
    companion object {
        val FLAT = EqualizerPreset("flat", "Flat", FloatArray(15) { 0f }, isBuiltIn = true)
        val ROCK = EqualizerPreset("rock", "Rock", floatArrayOf(4f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 5f, 4f, 3f, 2f), bassBoost = 3f, isBuiltIn = true)
        val POP = EqualizerPreset("pop", "Pop", floatArrayOf(-1f, 2f, 4f, 5f, 4f, 2f, 0f, -1f, -2f, -2f, -1f, 0f, 1f, 2f, 3f), bassBoost = 2f, isBuiltIn = true)
        val CLASSICAL = EqualizerPreset("classical", "Classical", floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, -2f, -2f, -2f, 0f, 2f, 3f, 3f, 3f), isBuiltIn = true)
        val JAZZ = EqualizerPreset("jazz", "Jazz", floatArrayOf(0f, 0f, 0f, 2f, 3f, 3f, 3f, 2f, 1f, 1f, 2f, 3f, 4f, 4f, 3f), bassBoost = 1f, isBuiltIn = true)
        val BASS_BOOST = EqualizerPreset("bass_boost", "Bass Boost", FloatArray(15) { if (it < 5) 6f else 0f }, bassBoost = 8f, isBuiltIn = true)
        val TREBLE_BOOST = EqualizerPreset("treble_boost", "Treble Boost", FloatArray(15) { if (it > 9) 6f else 0f }, isBuiltIn = true)
        val VOCAL_BOOST = EqualizerPreset("vocal_boost", "Vocal Boost", FloatArray(15) { if (it in 5..9) 4f else 0f }, isBuiltIn = true)
        val ELECTRONIC = EqualizerPreset("electronic", "Electronic", floatArrayOf(5f, 4f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 5f, 4f, 3f), bassBoost = 5f, virtualizer = 6f, isBuiltIn = true)
        val HIP_HOP = EqualizerPreset("hip_hop", "Hip Hop", floatArrayOf(5f, 4f, 3f, 2f, 1f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 4f, 3f, 2f), bassBoost = 6f, isBuiltIn = true)
        val MOVIE = EqualizerPreset("movie", "Cinema Movie", floatArrayOf(3f, 3f, 2f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 3f, 3f, 2f, 2f, 1f), bassBoost = 4f, virtualizer = 5f, isBuiltIn = true)
        val ACTION = EqualizerPreset("action", "Action", floatArrayOf(4f, 4f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 4f, 5f, 5f, 4f, 3f), bassBoost = 7f, virtualizer = 8f, isBuiltIn = true)
        val HORROR = EqualizerPreset("horror", "Horror", floatArrayOf(2f, 3f, 4f, 3f, 2f, 1f, 0f, -1f, -2f, -1f, 0f, 1f, 2f, 3f, 2f), reverb = 3, isBuiltIn = true)
        val ROMANCE = EqualizerPreset("romance", "Romance", floatArrayOf(0f, 1f, 2f, 3f, 3f, 2f, 1f, 0f, 0f, 1f, 2f, 3f, 3f, 2f, 1f), isBuiltIn = true)
        val NIGHT = EqualizerPreset("night", "Late Night", FloatArray(15) { -3f }, bassBoost = 2f, isBuiltIn = true)
        val LOUDNESS = EqualizerPreset("loudness", "Loudness", floatArrayOf(2f, 2f, 1f, 1f, 0f, 0f, 0f, 0f, 1f, 1f, 2f, 2f, 3f, 3f, 2f), isBuiltIn = true)
        val DANCE = EqualizerPreset("dance", "Dance", floatArrayOf(4f, 5f, 4f, 2f, 0f, -1f, -2f, -2f, 0f, 2f, 4f, 5f, 5f, 4f, 3f), bassBoost = 6f, virtualizer = 7f, isBuiltIn = true)
        val ACOUSTIC = EqualizerPreset("acoustic", "Acoustic", floatArrayOf(0f, 1f, 2f, 3f, 3f, 2f, 1f, 1f, 2f, 3f, 3f, 2f, 1f, 0f, 0f), isBuiltIn = true)

        // ===== PREMIUM: Studio / Audiophile presets =====
        val STUDIO_FLAT_PRO = EqualizerPreset(
            "studio_flat_pro", "Studio Flat Pro",
            FloatArray(15) { 0f }, bassBoost = 0f, virtualizer = 0f,
            isBuiltIn = true, isPremium = true
        )
        val AUDIOPHILE_REFERENCE = EqualizerPreset(
            "audiophile_reference", "Audiophile Reference",
            floatArrayOf(0.5f, 0.5f, 0f, 0f, -0.5f, 0f, 0.5f, 0.5f, 0f, -0.5f, 0f, 0.5f, 1f, 0.5f, 0f),
            bassBoost = 1f, virtualizer = 2f, isBuiltIn = true, isPremium = true
        )
        val MASTERING_ENGINEER = EqualizerPreset(
            "mastering_engineer", "Mastering Engineer",
            floatArrayOf(1f, 0.5f, 0f, -0.5f, -1f, -0.5f, 0f, 0.5f, 1f, 1.5f, 1f, 0.5f, 0f, -0.5f, -1f),
            bassBoost = 0f, virtualizer = 1f, isBuiltIn = true, isPremium = true
        )
        val CONCERT_HALL_STUDIO = EqualizerPreset(
            "concert_hall_studio", "Concert Hall Studio",
            floatArrayOf(1f, 1.5f, 1f, 0.5f, 0f, -0.5f, 0f, 0.5f, 1f, 1.5f, 2f, 2f, 1.5f, 1f, 0.5f),
            bassBoost = 2f, virtualizer = 5f, reverb = 5, isBuiltIn = true, isPremium = true
        )
        val VINYL_WARMTH = EqualizerPreset(
            "vinyl_warmth", "Vinyl Warmth",
            floatArrayOf(3f, 2.5f, 2f, 1.5f, 1f, 0.5f, 0f, -0.5f, -1f, -1.5f, -1f, -0.5f, 0f, 0.5f, 1f),
            bassBoost = 3f, virtualizer = 1f, isBuiltIn = true, isPremium = true
        )
        val PODCAST_STUDIO_PRO = EqualizerPreset(
            "podcast_studio_pro", "Podcast Studio Pro",
            floatArrayOf(-2f, -1f, 0f, 1f, 3f, 5f, 5f, 4f, 2f, 0f, -1f, -2f, -2f, -1f, 0f),
            bassBoost = 0f, virtualizer = 0f, isBuiltIn = true, isPremium = true
        )
        val ORCHESTRAL_HIFI = EqualizerPreset(
            "orchestral_hifi", "Orchestral Hi-Fi",
            floatArrayOf(1f, 1f, 0.5f, 0f, 0f, 0f, 0.5f, 1f, 1.5f, 2f, 2.5f, 2f, 1.5f, 1f, 1f),
            bassBoost = 1f, virtualizer = 4f, reverb = 4, isBuiltIn = true, isPremium = true
        )

        val ALL_PRESETS = listOf(
            FLAT, ROCK, POP, CLASSICAL, JAZZ, BASS_BOOST, TREBLE_BOOST,
            VOCAL_BOOST, ELECTRONIC, HIP_HOP, MOVIE, ACTION, HORROR,
            ROMANCE, NIGHT, LOUDNESS, DANCE, ACOUSTIC,
            STUDIO_FLAT_PRO, AUDIOPHILE_REFERENCE, MASTERING_ENGINEER,
            CONCERT_HALL_STUDIO, VINYL_WARMTH, PODCAST_STUDIO_PRO, ORCHESTRAL_HIFI
        )

        val PREMIUM_PRESETS = listOf(
            STUDIO_FLAT_PRO, AUDIOPHILE_REFERENCE, MASTERING_ENGINEER,
            CONCERT_HALL_STUDIO, VINYL_WARMTH, PODCAST_STUDIO_PRO, ORCHESTRAL_HIFI
        )
    }

    fun toEntity(): EqualizerPresetEntity {
        return EqualizerPresetEntity(
            id = id,
            name = name,
            band0 = bands.getOrElse(0) { 0f },
            band1 = bands.getOrElse(1) { 0f },
            band2 = bands.getOrElse(2) { 0f },
            band3 = bands.getOrElse(3) { 0f },
            band4 = bands.getOrElse(4) { 0f },
            band5 = bands.getOrElse(5) { 0f },
            band6 = bands.getOrElse(6) { 0f },
            band7 = bands.getOrElse(7) { 0f },
            band8 = bands.getOrElse(8) { 0f },
            band9 = bands.getOrElse(9) { 0f },
            band10 = bands.getOrElse(10) { 0f },
            band11 = bands.getOrElse(11) { 0f },
            band12 = bands.getOrElse(12) { 0f },
            band13 = bands.getOrElse(13) { 0f },
            band14 = bands.getOrElse(14) { 0f },
            bassBoost = bassBoost,
            virtualizer = virtualizer,
            reverb = reverb,
            isBuiltIn = isBuiltIn
        )
    }
}

fun EqualizerPresetEntity.toPreset(): EqualizerPreset {
    return EqualizerPreset(
        id = id,
        name = name,
        bands = floatArrayOf(band0, band1, band2, band3, band4, band5, band6, band7, band8, band9, band10, band11, band12, band13, band14),
        bassBoost = bassBoost,
        virtualizer = virtualizer,
        reverb = reverb,
        isBuiltIn = isBuiltIn
    )
}

// ===================== CINEMA AUDIO CONFIG =====================
data class CinemaAudioConfig(
    val surroundMode: SurroundMode = SurroundMode.AUTO,
    val bassLevel: Int = 50,
    val virtualizerStrength: Int = 50,
    val dialogEnhancement: Boolean = false,
    val nightMode: Boolean = false,
    val volumeNormalization: Boolean = true,
    val volumeEnhancement: Int = 0,
    val loudnessTarget: Int = -14,
    // ===== Theatre / IMAX experience (real cinema-hall controls) =====
    val theatreRoomSize: TheatreRoomSize = TheatreRoomSize.STANDARD_MULTIPLEX,
    val xCurveEnabled: Boolean = false,
    val xCurveIntensity: Int = 50,       // 0-100
    val thxReEqEnabled: Boolean = false,
    val lfeLevel: Int = 0,               // -10..+10 dB, subwoofer/.1 channel trim
    val bassCrossoverHz: Int = 80,       // THX-style bass-management crossover
    val heightChannelLevel: Int = 50,    // 0-100, Atmos/5.1.2 overhead speaker level
    val centerChannelLevel: Int = 50,    // 0-100, dialogue/center-channel clarity intensity
    val dynamicRangeMode: DynamicRangeMode = DynamicRangeMode.CINEMA_FULL,
    // ===== Per-channel manual mixer trims (-10..+10 dB each) =====
    val frontTrimDb: Int = 0,
    val centerTrimDb: Int = 0,
    val surroundTrimDb: Int = 0,
    // ===== Master controls =====
    val theatreModeEnabled: Boolean = false,
    val abCompareBypassed: Boolean = false,
    // ===== EXTREME / THRILL features =====
    // Extra low-shelf punch layered on top of the normal LowBassFilter
    // shelf (see CinemaDSPEngine.lowBassShelfExtraMb) — for action/impact
    // moments where the normal bass ceiling still feels too polite.
    val extremeBassMode: Boolean = false,
    // Extra LoudnessEnhancer gain on top of the normal Volume Enhancement/
    // Dynamic Range/Loudness Target chain (see applyLoudnessChain) — a
    // "make the loud scenes hit harder" master boost, still capped so it
    // can't push past LoudnessEnhancer's safe headroom.
    val extremeLoudnessMode: Boolean = false,
    // Vibration pulses synced to real-time bass energy via Visualizer —
    // see CinemaDSPEngine.HapticBassPulse. 0 = off, 1-100 = sensitivity/
    // strength of the pulse.
    val hapticBassSyncEnabled: Boolean = false,
    val hapticBassSyncIntensity: Int = 60,
    // ===== Master Boost (all-frequency EQ boost bar) =====
    // A single manual bar that lifts EVERY EQ band together, on top of
    // whatever the preset/theatre shaping already set — see
    // CinemaDSPEngine.setMasterBoost()/applyTheatreShaping() for how it's
    // applied with a soft clamp so pushing it hard doesn't crackle, and
    // eqHeadroomUsedMb()/applyLoudnessChain() for how the loudness chain
    // automatically backs off to make room for it instead of stacking.
    val masterBoostDb: Int = 0,          // -10..+20 dB, all bands together
    // Safety limiter attached alongside the other AudioEffects (see
    // CinemaDSPEngine.attachEffectsToSession) so combining Master Boost
    // with Volume Enhancement/Loudness can't push the signal into hard
    // digital clipping — catches true-peak overs with a fast limiter
    // instead of letting them crackle.
    val limiterEnabled: Boolean = true,
    // One-tap "make it clean" mode — see CinemaDSPEngine.setAudioCleanMode()
    // for exactly what it does: tames the harsh 3-6kHz sibilance region,
    // force-enables the safety limiter, and caps loudness gain to a
    // safer ceiling so playback can't push into audible crackle/distortion
    // no matter what else (Master Boost, Volume Enhancement, etc.) is set.
    val audioCleanModeEnabled: Boolean = false
)

// ===================== THEATRE ROOM SIZE =====================
// Simulates the acoustic feel of different real cinema-hall sizes —
// bigger rooms get more reverb tail, more diffusion, and a wider virtual
// stage, exactly like how a small screening room sounds "tighter" than
// an IMAX dome in real life.
enum class TheatreRoomSize(val label: String, val description: String) {
    SCREENING_ROOM("Screening Room", "Small private theatre acoustics"),
    STANDARD_MULTIPLEX("Standard Multiplex", "Regular cinema hall"),
    LARGE_CINEMA("Large Cinema", "Big single-screen auditorium"),
    DOLBY_CINEMA("Dolby Cinema", "Premium Dolby Atmos auditorium"),
    IMAX_DOME("IMAX Dome", "Full IMAX dome theatre")
}

// ===================== DYNAMIC RANGE MODE =====================
enum class DynamicRangeMode(val label: String, val description: String) {
    CINEMA_FULL("Cinema Full DR", "Full theatrical dynamic range — no compression"),
    DIALOGUE_BOOST("Dialogue Boost", "Lifts quiet dialogue above loud effects"),
    LATE_NIGHT("Late Night", "Compressed for quiet, neighbour-friendly listening"),
    MUSIC_CONCERT("Music / Concert", "Light touch, keeps transients punchy")
}

// Standard THX/cinema bass-management crossover points offered in the UI.
val BASS_CROSSOVER_OPTIONS = intArrayOf(40, 60, 80, 100, 120)


// the common theatrical/streaming reference; -20/-27 are quieter
// broadcast-style targets that need more makeup gain to feel comparable.
val LOUDNESS_TARGET_OPTIONS = intArrayOf(-14, -20, -27)

// ===================== CINEMA ASPECT-RATIO BARS =====================
// Forces true theatrical letterbox bars over the video, independent of
// the source file's own aspect ratio — the same way a real cinema
// projector masks the screen for scope vs flat presentations.
enum class CinemaBarsMode(val label: String, val ratio: Float) {
    OFF("Off", 0f),
    FLAT_1_85("Flat 1.85:1", 1.85f),
    SCOPE_2_39("Scope 2.39:1", 2.39f),
    IMAX_1_43("IMAX 1.43:1", 1.43f)
}

// ===================== CONTENT-TYPE HEURISTIC =====================
// Best-effort guess at what's playing, purely from the filename/title —
// there's no real content analysis here, just keyword matching, used to
// suggest a sensible default Dynamic Range Mode when "Auto" is enabled.
fun detectContentDynamicRangeMode(title: String): DynamicRangeMode {
    val t = title.lowercase()
    return when {
        listOf("trailer", "teaser").any { t.contains(it) } -> DynamicRangeMode.DIALOGUE_BOOST
        listOf("concert", "live", "gig", "music video", "mv").any { t.contains(it) } -> DynamicRangeMode.MUSIC_CONCERT
        listOf("podcast", "interview", "lecture", "vlog").any { t.contains(it) } -> DynamicRangeMode.DIALOGUE_BOOST
        else -> DynamicRangeMode.CINEMA_FULL
    }
}

// ===================== VIDEO QUALITY =====================
enum class VideoQuality(val label: String, val width: Int, val height: Int) {
    AUTO("AUTO", 0, 0),
    SD_480P("480P", 854, 480),
    HD_720P("720P", 1280, 720),
    FHD_1080P("1080P", 1920, 1080),
    QHD_1440P("1440P", 2560, 1440),
    UHD_4K("4K", 3840, 2160),
    UHD_8K("8K", 7680, 4320)
}

// ===================== UPSCALE MODE =====================
enum class UpscaleMode(val label: String) {
    OFF("Off"),
    AI_4K("AI 4K"),
    AI_8K("AI 8K"),
    SUPER_RESOLUTION("Super Resolution"),
    SHARPEN("Sharpen"),
    DENOISE("Denoise"),
    HDR_SIMULATION("HDR Simulation")
}

// ===================== VIDEO ADJUSTMENTS (Picture Controls) =====================
// Mirrors the audio EQ idea but for picture: every slider here maps to a
// real GPU effect applied to the live video via ExoPlayer.setVideoEffects()
// (see VideoAdjustEffect.kt + CinemaProPlayerScreen's buildVideoEffects()).
// All values default to 0f = neutral/no-change so a fresh VideoAdjustments()
// never alters the picture until the user actually moves a slider.
data class VideoAdjustments(
    val brightness: Float = 0f,       // -1f..1f, 0 = no change
    val contrast: Float = 0f,         // -1f..1f, 0 = no change
    val saturation: Float = 0f,       // -1f..1f, 0 = no change (color intensity)
    val sharpness: Float = 0f,        // 0f..1f, 0 = off (edge/detail boost)
    val clarity: Float = 0f,          // 0f..1f, 0 = off (local/mid-tone contrast punch)
    val noiseReduction: Float = 0f,   // 0f..1f, 0 = off (denoise/grain smoothing)
    val depth3D: Float = 0f,          // 0f..1f, 0 = off (pseudo-3D depth pop for 2D video)
    val gamma: Float = 0f,            // -1f..1f, 0 = no change (shadow/highlight balance)
    val warmth: Float = 0f            // -1f..1f, 0 = no change (color temperature, - cool / + warm)
) {
    val isNeutral: Boolean
        get() = brightness == 0f && contrast == 0f && saturation == 0f && sharpness == 0f &&
                clarity == 0f && noiseReduction == 0f && depth3D == 0f && gamma == 0f && warmth == 0f

    companion object {
        val DEFAULT = VideoAdjustments()
        val CINEMA = VideoAdjustments(contrast = 0.12f, saturation = 0.08f, clarity = 0.15f, warmth = 0.06f, gamma = -0.05f)
        val VIVID = VideoAdjustments(contrast = 0.2f, saturation = 0.35f, sharpness = 0.3f, clarity = 0.25f)
        val SOFT_NATURAL = VideoAdjustments(contrast = -0.05f, saturation = -0.05f, noiseReduction = 0.3f, sharpness = 0.1f)
        val CLARITY_MAX = VideoAdjustments(sharpness = 0.6f, clarity = 0.5f, contrast = 0.1f, noiseReduction = 0.2f)
        // "Goosebumps" preset — punchy contrast + rich saturation + strong
        // clarity/sharpness + a touch of warmth, tuned for action/thrill
        // scenes. Every value still goes through the same Contrast/
        // Brightness/RgbAdjustment pipeline as every other preset in
        // buildVideoEffects() — no new/unproven effect type introduced.
        val EXTREME_THRILLER = VideoAdjustments(
            contrast = 0.35f, saturation = 0.4f, sharpness = 0.55f,
            clarity = 0.45f, warmth = 0.1f, gamma = -0.1f
        )
    }

    fun toEntity(id: String, name: String): VideoAdjustPresetEntity = VideoAdjustPresetEntity(
        id = id, name = name,
        brightness = brightness, contrast = contrast, saturation = saturation,
        sharpness = sharpness, clarity = clarity, noiseReduction = noiseReduction,
        depth3D = depth3D, gamma = gamma, warmth = warmth
    )
}

// ===================== CUSTOM PICTURE-ADJUST PRESET (persisted) =====================
// User-saved "personal" Picture Adjust settings — same idea as
// EqualizerPresetEntity, just for the 9 VideoAdjustments sliders instead
// of the 15 EQ bands. Saved via VideoAdjustPresetDao.
@Entity(tableName = "video_adjust_presets")
data class VideoAdjustPresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val sharpness: Float = 0f,
    val clarity: Float = 0f,
    val noiseReduction: Float = 0f,
    val depth3D: Float = 0f,
    val gamma: Float = 0f,
    val warmth: Float = 0f,
    val createdAt: Long = System.currentTimeMillis()
)

fun VideoAdjustPresetEntity.toVideoAdjustments(): VideoAdjustments = VideoAdjustments(
    brightness = brightness, contrast = contrast, saturation = saturation,
    sharpness = sharpness, clarity = clarity, noiseReduction = noiseReduction,
    depth3D = depth3D, gamma = gamma, warmth = warmth
)


// ===================== 3D VIDEO MODE =====================
enum class VideoMode3D(val label: String) {
    OFF("2D Mode"),
    SBS("Side-by-Side 3D"),
    TAB("Top-and-Bottom 3D"),
    ANAGLYPH("Anaglyph 3D"),
    VR_360("VR 360°"),
    VR_180("VR 180°"),
    STEREOSCOPIC("Stereoscopic")
}

// ===================== SURROUND MODE =====================
enum class SurroundMode(val label: String, val description: String) {
    STEREO("Stereo", "2.0 Channel"),
    VIRTUAL_5_1("5.1", "Virtual 5.1 Surround"),
    VIRTUAL_5_1_2("5.1.2", "Virtual 5.1.2 Atmos"),
    VIRTUAL_7_1("7.1", "Virtual 7.1 Surround"),
    ATMOS_3D("Atmos 3D", "Dolby Atmos 3D Audio"),
    // Dolby Digital-style 5.1 cinema downmix — NOT a licensed AC-3/E-AC-3
    // decoder (that needs a paid Dolby SDK we don't have); this is a
    // real, independently-built DSP mode using the same industry-
    // standard ITU-R BS.775 stereo downmix math real Dolby Digital
    // receivers use for their Lo/Ro output, plus a warmer/dialog-forward
    // EQ signature and tighter room tuning than the generic 5.1 mode —
    // see CinemaDSPEngine.applySurroundEffects()/apply5_1DolbyDigital().
    DOLBY_DIGITAL_5_1("Dolby Digital 5.1", "Cinema-Standard 5.1 Downmix"),
    AUTO("Auto", "Auto Detect")
}

// ===================== PLAYBACK SPEED =====================
enum class PlaybackSpeed(val value: Float, val label: String) {
    SLOW_0_5(0.5f, "0.5x"),
    SLOW_0_75(0.75f, "0.75x"),
    NORMAL(1.0f, "1.0x"),
    FAST_1_25(1.25f, "1.25x"),
    FAST_1_5(1.5f, "1.5x"),
    FAST_1_75(1.75f, "1.75x"),
    FAST_2_0(2.0f, "2.0x")
}

// ===================== APP SETTINGS =====================
@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val defaultQuality: VideoQuality = VideoQuality.AUTO,
    val defaultUpscale: UpscaleMode = UpscaleMode.OFF,
    val defaultSurroundMode: SurroundMode = SurroundMode.AUTO,
    val default3DMode: VideoMode3D = VideoMode3D.OFF,
    val rememberPosition: Boolean = true,
    val autoPlayNext: Boolean = true,
    val hardwareAcceleration: Boolean = true,
    val subtitleSize: Float = 1.0f,
    val subtitleColor: String = "#FFFFFF",
    val subtitleBackground: String = "#80000000",
    val subtitleOutline: Boolean = true,
    val gestureControls: Boolean = true,
    val doubleTapSeek: Boolean = true,
    val seekDuration: Int = 10,
    val screenTimeout: Int = 0
)

// ===================== PLAYER STATE =====================
sealed class PlayerState {
    object Idle : PlayerState()
    object Loading : PlayerState()
    data class Playing(val position: Long, val duration: Long) : PlayerState()
    data class Paused(val position: Long, val duration: Long) : PlayerState()
    data class Error(val message: String) : PlayerState()
    object Completed : PlayerState()
}
