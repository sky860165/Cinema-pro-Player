package com.cinemapro.player.ui.screens

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.Brightness
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.cinemapro.player.audio.CinemaDSPEngine
import com.cinemapro.player.data.database.CinemaProDatabase
import com.cinemapro.player.data.database.VideoHistoryEntity
import com.cinemapro.player.data.model.*
import com.cinemapro.player.ui.components.*
import com.cinemapro.player.ui.theme.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.map
import kotlin.math.*

@OptIn(UnstableApi::class)
@Composable
fun CinemaProPlayerScreen(
    videoUri: String,
    videoTitle: String = "",
    videoId: Long = -1L,
    onBackPressed: () -> Unit,
    onEnterPip: (() -> Unit)? = null,
    onPipChanged: ((callback: (Boolean) -> Unit) -> Unit)? = null
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // ── Player core states ──────────────────────────
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var bufferedPosition by remember { mutableLongStateOf(0L) }
    var isLoading by remember { mutableStateOf(true) }
    var playerError by remember { mutableStateOf<String?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var isLooping by remember { mutableStateOf(false) }
    var isPipMode by remember { mutableStateOf(false) }
    var isOrientationLocked by remember { mutableStateOf(false) }
    var isTheatreMode by remember { mutableStateOf(false) }
    var aspectRatioMode by remember { mutableStateOf(AspectRatioMode.FIT) }
    var audioSessionIdState by remember { mutableIntStateOf(0) }
    // Bumped by selectAudioTrack() when a track switch needs DSP settings
    // reapplied but the audio session id itself didn't change (see FIX
    // note on selectAudioTrack). Kept separate from audioSessionIdState
    // so there's exactly one LaunchedEffect that ever calls
    // dspEngine.initialize() — no duplicate/racing re-init calls.
    var audioTrackSwitchTrigger by remember { mutableIntStateOf(0) }
    var dspStatus by remember { mutableStateOf(CinemaDSPEngine.EngineStatus()) }
    var showAudioFxWarning by remember { mutableStateOf(false) }
    // Counts consecutive auto-recovery attempts after a PlaybackException.
    // Capped so a genuinely broken file doesn't retry forever — after the
    // cap we fall back to showing the manual error screen, same as before.
    var autoRecoverAttempts by remember { mutableIntStateOf(0) }

    // Pinch-to-zoom scale (2-finger gesture)
    var videoScale by remember { mutableFloatStateOf(1f) }
    var showScaleHint by remember { mutableStateOf(false) }
    // FIX ("1.0x / Reset" hint not going away): LaunchedEffect(showScaleHint)
    // keyed on a plain Boolean never restarts while pinching continuously,
    // because showScaleHint just stays `true` -> `true` (same key, no
    // recomposition of the key itself) — so the very first delay(1200)
    // that started on the first pinch frame is the ONLY timer that will
    // ever fire, and if you're still pinching when it fires, it hides the
    // hint mid-gesture; if a later pinch frame sets it true again after
    // that timer already completed, nothing schedules a new hide at all.
    // Same token-bump pattern already used for the volume/brightness hints
    // fixes it: every pinch frame bumps the token, restarting the timer.
    var scaleHintToken by remember { mutableIntStateOf(0) }

    // ── Quality / AI / 3D ──────────────────────────
    var currentQuality by remember { mutableStateOf(VideoQuality.AUTO) }
    var currentUpscale by remember { mutableStateOf(UpscaleMode.OFF) }
    var current3DMode by remember { mutableStateOf(VideoMode3D.OFF) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }
    // Picture controls (contrast/colour/clarity/sharpness/noise/3D depth
    // etc.) — same idea as the audio EQ but for video. See buildVideoEffects()
    // below for how each field maps to real GPU effects on the live video.
    var videoAdjustments by remember { mutableStateOf(VideoAdjustments.DEFAULT) }
    // "meri personal settings save ho custom video adjust save krne k
    // liye" — save-dialog state for naming a custom Picture Adjust
    // preset, same pattern as showCustomSaveDialog/customPresetName
    // further below for the audio equalizer.
    var showVideoAdjustSaveDialog by remember { mutableStateOf(false) }
    var videoAdjustPresetName by remember { mutableStateOf("") }

    // ── Gesture states ──────────────────────────────
    var volumeLevel by remember { mutableFloatStateOf(getSystemVolume(context)) }
    var brightnessLevel by remember { mutableFloatStateOf(getScreenBrightness(context)) }
    var showVolumeHint by remember { mutableStateOf(false) }
    var showBrightnessHint by remember { mutableStateOf(false) }
    var volumeHintToken by remember { mutableIntStateOf(0) }
    var brightnessHintToken by remember { mutableIntStateOf(0) }
    var showSeekHint by remember { mutableStateOf(false) }
    var seekHintText by remember { mutableStateOf("") }
    var isDragging by remember { mutableStateOf(false) }
    var dragStartPosition by remember { mutableLongStateOf(0L) }
    // FIX ("timeline bar smoothly slide nahi ho raha"): the timeline
    // Slider was reusing this SAME `isDragging` flag that the video-
    // surface swipe gesture (seek/volume/brightness via dragging on the
    // video itself) also owns. Two unrelated gestures sharing one flag
    // meant dragging the seek bar could get its "I'm mid-drag, don't
    // overwrite me" state stomped by the swipe-gesture's own
    // isDragging=false resets (and vice versa), which is what made the
    // bar feel stuck/jerky instead of following your finger smoothly.
    // Giving the seek bar its own dedicated flag removes that conflict.
    var isSeekBarDragging by remember { mutableStateOf(false) }

    // ── Audio / DSP ─────────────────────────────────
    var currentPreset by remember { mutableStateOf(EqualizerPreset.FLAT) }
    var customBands by remember { mutableStateOf(FloatArray(15) { 0f }) }
    var surroundMode by remember { mutableStateOf(SurroundMode.AUTO) }
    var bassLevel by remember { mutableIntStateOf(50) }
    var nightMode by remember { mutableStateOf(false) }
    var dialogEnhance by remember { mutableStateOf(false) }
    var volumeNormalization by remember { mutableStateOf(true) }
    // FIX: setVolumeEnhancement() existed in CinemaDSPEngine but was never
    // called from anywhere in this screen — no slider/control was wired to
    // it at all, so "Volume Enhancement kaam nahi kar raha" was because it
    // was never connected, not because the underlying effect was broken.
    var volumeEnhancement by remember { mutableIntStateOf(0) }
    var showCustomSaveDialog by remember { mutableStateOf(false) }
    var customPresetName by remember { mutableStateOf("") }
    var globalEqEnabled by remember { mutableStateOf(com.cinemapro.player.service.GlobalEqualizerService.isEnabled(context)) }

    // ── Panel visibility ────────────────────────────
    var showEqualizer by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showSubtitleTracks by remember { mutableStateOf(false) }
    var showQualitySelector by remember { mutableStateOf(false) }
    var showSpeedSelector by remember { mutableStateOf(false) }
    var show3DSelector by remember { mutableStateOf(false) }
    var showUpscaleSelector by remember { mutableStateOf(false) }
    var showTheatreSelector by remember { mutableStateOf(false) }
    var showVideoAdjust by remember { mutableStateOf(false) }

    // ── Tracks ──────────────────────────────────────
    var audioTracks by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<SubtitleTrack>>(emptyList()) }
    var currentSubtitle by remember { mutableStateOf<SubtitleTrack?>(null) }

    // ── DB for resume ───────────────────────────────
    val db = remember { CinemaProDatabase.getInstance(context) }
    // FIX (root cause of "custom equalizer save nahi ho raha"): saving
    // already worked — insertPreset() was writing to Room correctly. The
    // preset picker grid below just only ever displayed the hardcoded
    // EqualizerPreset.ALL_PRESETS list and never queried the database, so
    // a newly saved preset had nowhere to show up. This collects the
    // custom presets table live so the grid can include them.
    val customPresets by db.equalizerPresetDao().getCustomPresets()
        .map { list -> list.map { it.toPreset() } }
        .collectAsState(initial = emptyList())
    val customVideoAdjustPresets by db.videoAdjustPresetDao().getAllPresets()
        .collectAsState(initial = emptyList())

    // ── DSP Engine ──────────────────────────────────
    val dspEngine = remember { CinemaDSPEngine(context) }

    // ── ExoPlayer ───────────────────────────────────
    val trackSelector = remember {
        DefaultTrackSelector(context).apply {
            setParameters(buildUponParameters()
                .setMaxVideoSize(7680, 4320)
                .setMaxVideoBitrate(100_000_000))
        }
    }

    val exoPlayer = remember {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
            .apply {
                // FIX: previously the Player.Listener (which updates
                // audioSessionIdState -> triggers dspEngine.initialize())
                // was only attached in a DisposableEffect much later in
                // composition, AFTER prepare()/playWhenReady were already
                // set here. onAudioSessionIdChanged can fire as soon as
                // the audio track starts, which on fast devices/cached
                // media raced ahead of that later listener attach — so
                // the very first (and sometimes only) session id change
                // was silently missed and the EQ/surround/bass never
                // attached to a real session. Setting a listener here,
                // before prepare(), guarantees we never miss it.
                addListener(object : Player.Listener {
                    // FIX (real root cause of "audio/EQ/Atmos not working"):
                    // this early listener — attached before prepare() specifically
                    // to not miss a fast onAudioSessionIdChanged — only logged the
                    // session id and never actually updated audioSessionIdState.
                    // A second Player.Listener further down (in a DisposableEffect)
                    // is the one that actually updates the state, but it attaches
                    // later in composition. On fast devices/cached media the
                    // session id fires here first and was silently dropped, so
                    // audioSessionIdState stayed 0, the DSP-init LaunchedEffect
                    // never ran, and CinemaDSPEngine.initialize() was never called
                    // — meaning EQ/BassBoost/Virtualizer/Atmos were never attached
                    // to any session at all, even though every effect further down
                    // the chain was implemented correctly. Updating state here too
                    // (harmless if the later listener already set the same value)
                    // closes that race for good.
                    override fun onAudioSessionIdChanged(sessionId: Int) {
                        Log.d("CinemaProPlayerScreen", "Audio session id changed: $sessionId")
                        audioSessionIdState = sessionId
                    }
                })
                setMediaItem(MediaItem.fromUri(videoUri))
                prepare()
                playWhenReady = true
            }
    }

    // ── Resume position ──────────────────────────────
    LaunchedEffect(Unit) {
        if (videoId > 0) {
            val history = withContext(Dispatchers.IO) { db.videoHistoryDao().getVideoHistory(videoId) }
            val lastPos = history?.lastPosition ?: 0L
            if (lastPos > 5000L) {
                exoPlayer.seekTo(lastPos)
            }
        }
    }

    // ── DSP init ─────────────────────────────────────
    // Single owner of dspEngine.initialize() + settings reapply. Keyed on
    // BOTH audioSessionIdState (normal session attach/change) and
    // audioTrackSwitchTrigger (track switch where the session id stayed
    // the same but effects still need to be rebuilt for the new track).
    // Keeping this as the only call site — instead of also calling it
    // from selectAudioTrack() — is what prevents the double re-init race
    // that was causing audio to cut out / "self-heal" in a loop.
    LaunchedEffect(audioSessionIdState, audioTrackSwitchTrigger) {
        if (audioSessionIdState != 0) {
            dspEngine.initialize(audioSessionIdState)
            dspEngine.applyEqualizerPreset(currentPreset)
            dspEngine.setSurroundMode(surroundMode)
            dspEngine.setBassLevel(bassLevel)
            dspEngine.setVolumeEnhancement(volumeEnhancement)
        }
    }

    // ── DSP status observation ───────────────────────
    // FIX: nothing previously read dspEngine's actual attach result — the
    // UI just assumed every effects call worked. This surfaces the real
    // state so we can tell the person plainly if audio effects genuinely
    // aren't available on their device/session, instead of them tweaking
    // sliders that silently do nothing.
    LaunchedEffect(dspEngine) {
        dspEngine.status.collect { s ->
            dspStatus = s
            showAudioFxWarning = audioSessionIdState != 0 && !s.sessionAttached
        }
    }

    // ── Progress loop ─────────────────────────────────
    // FIX ("timeline bar smoothly nahi chal raha, forward/backward pe
    // ruk raha"): this used to be LaunchedEffect(isPlaying) with a
    // `while (isPlaying)` body — so the loop fully STOPPED the instant
    // isPlaying went false, which happens not just on pause but also
    // briefly during buffering/seeking. That's exactly why the bar
    // looked "stuck" right when you seek forward/back: ExoPlayer buffers
    // for a moment, isPlaying flips false, and this loop died and
    // stopped polling currentPosition until playback resumed. Now the
    // loop runs for the whole life of the screen (key = Unit) and just
    // polls the player unconditionally, so the bar (and buffered-amount
    // fill) keeps updating through seeks/buffering/pauses too. Delay
    // dropped from 500ms to 200ms for a visibly smoother sweep. Also
    // skips updating currentPosition while the user is actively
    // dragging the seek thumb, so the poll doesn't fight the drag.
    LaunchedEffect(Unit) {
        while (true) {
            duration = exoPlayer.duration.coerceAtLeast(0)
            bufferedPosition = exoPlayer.bufferedPosition
            isLoading = exoPlayer.isLoading && !exoPlayer.isPlaying
            if (!isDragging && !isSeekBarDragging) {
                currentPosition = exoPlayer.currentPosition
            }

            // Save resume position every ~5s while actually playing
            if (isPlaying && videoId > 0 && currentPosition > 0) {
                withContext(Dispatchers.IO) {
                    db.videoHistoryDao().insertOrUpdate(
                        VideoHistoryEntity(
                            videoId = videoId,
                            title = videoTitle,
                            uri = videoUri,
                            duration = duration,
                            lastPosition = currentPosition
                        )
                    )
                }
            }
            delay(200)
        }
    }

    // ── Auto-hide controls ───────────────────────────
    LaunchedEffect(showControls, isPlaying, isDragging, isSeekBarDragging) {
        if (showControls && isPlaying && !isDragging && !isSeekBarDragging) {
            delay(4000)
            showControls = false
        }
    }

    // ── Track extraction ─────────────────────────────
    // audioGroupMap/subtitleGroupMap let the "select" actions below find
    // the real ExoPlayer Tracks.Group + in-group index for a given track
    // id, since AudioTrack/SubtitleTrack themselves only carry display info.
    var audioGroupMap by remember { mutableStateOf(mapOf<String, Pair<Tracks.Group, Int>>()) }
    var subtitleGroupMap by remember { mutableStateOf(mapOf<String, Pair<Tracks.Group, Int>>()) }

    // FIX (audio goes completely silent after switching language/track):
    // `LaunchedEffect(exoPlayer.currentTracks)` used exoPlayer.currentTracks
    // as the Compose key. That's a plain property read, evaluated once
    // when this LaunchedEffect first launches — Compose has no way to
    // know the underlying Tracks object changes later, so this block
    // never re-ran after the very first track set was available. That
    // means audioGroupMap kept holding the OLD Tracks.Group references
    // from before the switch. When selectAudioTrack() then built a
    // TrackSelectionOverride from that stale group, it was overriding a
    // group that no longer matched the renderer's current track set —
    // on many devices that produces an override the renderer can't
    // satisfy at all, so it silently drops audio output entirely instead
    // of just picking the wrong track. Rebuilding this map from a real
    // Player.Listener.onTracksChanged callback (which fires every time
    // ExoPlayer's track set actually changes, including after a track
    // switch) keeps audioGroupMap/subtitleGroupMap always current.
    DisposableEffect(exoPlayer) {
        fun rebuildTrackMaps(tracks: Tracks) {
            val audioList = mutableListOf<AudioTrack>()
            val subList = mutableListOf<SubtitleTrack>()
            val audioMap = mutableMapOf<String, Pair<Tracks.Group, Int>>()
            val subMap = mutableMapOf<String, Pair<Tracks.Group, Int>>()
            for (group in tracks.groups) {
                for (i in 0 until group.length) {
                    val fmt = group.getTrackFormat(i)
                    when {
                        fmt.sampleMimeType?.startsWith("audio") == true -> {
                            val id = "${group.mediaTrackGroup.id}_$i"
                            audioList.add(AudioTrack(id, fmt.language ?: "und",
                                fmt.label ?: "Track ${audioList.size + 1}", isSelected = group.isTrackSelected(i)))
                            audioMap[id] = group to i
                        }
                        fmt.sampleMimeType?.let { it.contains("text") || it.contains("subtitle") } == true -> {
                            val id = "${group.mediaTrackGroup.id}_$i"
                            subList.add(SubtitleTrack(id, fmt.language ?: "und",
                                fmt.label ?: "Sub ${subList.size + 1}", isSelected = group.isTrackSelected(i)))
                            subMap[id] = group to i
                        }
                    }
                }
            }
            audioTracks = audioList
            subtitleTracks = subList
            audioGroupMap = audioMap
            subtitleGroupMap = subMap
        }

        val listener = object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                rebuildTrackMaps(tracks)
            }
        }
        exoPlayer.addListener(listener)
        // Populate immediately in case tracks are already available
        // (e.g. this effect re-attaches after the player was already prepared).
        rebuildTrackMaps(exoPlayer.currentTracks)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // Actually switches the playing audio track — previously the Audio
    // Tracks dialog's onSelect callback just closed the dialog and did
    // nothing else, so whatever track ExoPlayer auto-picked (which for
    // dual-audio MKVs can be the wrong/silent one) stayed selected no
    // matter what the user tapped. This wires the tap to a real
    // TrackSelectionOverride on the DefaultTrackSelector.
    //
    // FIX (audio cutting out / looping "self-healing" after language
    // switch): the previous version of this function called
    // dspEngine.initialize() + applyEqualizerPreset/setSurroundMode/
    // setBassLevel directly AND ALSO set audioSessionIdState = sid.
    // Setting that state re-triggers the separate
    // LaunchedEffect(audioSessionIdState) block below, which does the
    // EXACT SAME dspEngine.initialize()+reapply sequence again. Combined
    // with the audio-session listener also writing audioSessionIdState
    // (needed for the earlier "EQ never attaches" fix), a track switch
    // could fire the whole init sequence 2–3 times back to back, tearing
    // down and rebuilding the Equalizer/BassBoost/Virtualizer/
    // LoudnessEnhancer instances on top of each other — that's the
    // repeated cut-in/cut-out "loop" behavior. Now this function ONLY
    // updates the session id state; the single LaunchedEffect below is
    // the one and only place that actually runs DSP init, so it can
    // never double-fire for the same switch.
    // FIX (audio going completely silent on language switch): the previous
    // override only ever set ONE override entry via setOverrideForType(),
    // which replaces overrides per TRACK TYPE, not per TrackGroup. For
    // content with multiple separate audio TrackGroups (very common for
    // dual/multi-language MKV and HLS — each language is frequently its
    // OWN TrackGroup rather than multiple tracks inside one group), Media3
    // can end up with the renderer's default selection still holding a
    // reference to the OLD group at the same time our override targets a
    // DIFFERENT group. Two simultaneous "selected" audio groups is a
    // conflict the audio renderer can't resolve, and several OEM decoder
    // stacks respond to that by dropping audio output entirely rather
    // than picking either one. The fix is to explicitly clear ALL
    // existing audio-type overrides first, then set exactly one override
    // for exactly the target group — guaranteeing the renderer only ever
    // sees a single unambiguous audio selection.
    fun selectAudioTrack(trackId: String) {
        val (group, trackIndex) = audioGroupMap[trackId] ?: return
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .setOverrideForType(
                    TrackSelectionOverride(group.mediaTrackGroup, trackIndex)
                )
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                .build()
        )
        scope.launch {
            // Give ExoPlayer a beat to actually rebuild the renderer with
            // the new track before we poll its session id — reading it
            // immediately can still return the pre-switch value.
            delay(150)
            val sid = exoPlayer.audioSessionId
            if (sid != 0) {
                if (sid == audioSessionIdState) {
                    // Session id didn't change (the common case — Android
                    // keeps the same session across a track rebuild), so
                    // the LaunchedEffect(audioSessionIdState) below won't
                    // re-fire on its own. Bump the separate trigger so DSP
                    // settings get reapplied to match the new track once,
                    // through the same single init path.
                    audioTrackSwitchTrigger++
                } else {
                    audioSessionIdState = sid
                }
            }
            // Some OEM renderer implementations leave playback paused
            // after a mid-playback decoder rebuild for the new track —
            // make sure we're still actually playing.
            if (!exoPlayer.isPlaying && exoPlayer.playbackState != Player.STATE_ENDED) {
                exoPlayer.playWhenReady = true
            }
        }
    }

    // FIX: previously selecting a subtitle in the dialog only updated the
    // local `currentSubtitle` Compose state — nothing ever told ExoPlayer's
    // DefaultTrackSelector to actually enable that text track, and text
    // track type could still be globally disabled from a prior "Off"
    // selection. So subtitles could never show up regardless of what was
    // tapped in the picker. This mirrors selectAudioTrack()'s real
    // TrackSelectionOverride wiring, and setSubtitleOff() explicitly
    // disables the text track type for a genuine "Off".
    fun selectSubtitleTrack(trackId: String) {
        val (group, trackIndex) = subtitleGroupMap[trackId] ?: return
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                .setOverrideForType(
                    TrackSelectionOverride(group.mediaTrackGroup, trackIndex)
                )
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .build()
        )
    }

    fun setSubtitleOff() {
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
        )
    }

    // ── Player listener ──────────────────────────────
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isLoading = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0)
                    // Playback recovered/stabilized — clear the auto-recover
                    // counter so a future unrelated error gets its own full
                    // set of retry attempts instead of an exhausted one.
                    autoRecoverAttempts = 0
                }
            }
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            // FIX (root cause of "chalte chalte band ho ja raha" / audio
            // dying on language switch): previously this only stored the
            // error message and stopped — ExoPlayer enters STATE_IDLE on
            // any PlaybackException and does NOT resume on its own, so
            // playback just halted and stayed halted until the user
            // manually tapped Retry. Renderer/audio-track errors (decoder
            // reinit failures, AudioSink write errors — exactly what a
            // mid-playback language/track switch can trigger on many OEM
            // decoders) are usually transient and recoverable by re-
            // preparing at the same position. Now we do that automatically,
            // up to 3 times in a row, before ever showing the error screen.
            override fun onPlayerError(error: PlaybackException) {
                Log.e("CinemaProPlayerScreen", "Player error: ${error.errorCodeName} - ${error.message}")
                if (autoRecoverAttempts < 3) {
                    autoRecoverAttempts++
                    val resumePos = exoPlayer.currentPosition.coerceAtLeast(0L)
                    scope.launch {
                        // Small backoff so we don't spin instantly against a
                        // hardware/decoder that needs a moment to reset.
                        delay(300L * autoRecoverAttempts)
                        exoPlayer.setMediaItem(MediaItem.fromUri(videoUri), resumePos)
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = true
                    }
                } else {
                    // Genuinely stuck after 3 tries — fall back to the
                    // manual error screen so the user isn't left with a
                    // silently spinning/frozen player.
                    playerError = error.message ?: "Playback error"
                }
            }
            override fun onAudioSessionIdChanged(sessionId: Int) { audioSessionIdState = sessionId }
        }
        exoPlayer.addListener(listener)
        // Session id may already be assigned by the time we attach the listener
        audioSessionIdState = exoPlayer.audioSessionId
        onDispose { exoPlayer.removeListener(listener) }
    }

    // ── Lifecycle ────────────────────────────────────
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> if (!isPipMode) exoPlayer.pause()
                Lifecycle.Event.ON_RESUME -> if (!isPipMode) exoPlayer.play()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // ── PIP callback registration ────────────────────
    LaunchedEffect(Unit) {
        onPipChanged?.invoke { inPip -> isPipMode = inPip }
    }

    // ── BackHandler ──────────────────────────────────
    BackHandler {
        when {
            showEqualizer -> showEqualizer = false
            showVideoAdjust -> showVideoAdjust = false
            showAudioTracks -> showAudioTracks = false
            showSubtitleTracks -> showSubtitleTracks = false
            showQualitySelector -> showQualitySelector = false
            showSpeedSelector -> showSpeedSelector = false
            show3DSelector -> show3DSelector = false
            showUpscaleSelector -> showUpscaleSelector = false
            else -> {
                // Save position before exit
                if (videoId > 0) {
                    scope.launch(Dispatchers.IO) {
                        db.videoHistoryDao().insertOrUpdate(
                            VideoHistoryEntity(videoId, videoTitle, videoUri, duration, exoPlayer.currentPosition)
                        )
                    }
                }
                onBackPressed()
            }
        }
    }

    // ── Immersive mode: hide status bar / nav bar ─────
    // FIX (root cause of "toggle button, right upper corner se
    // notification gayab nahi ho raha"): there was previously NO code
    // anywhere in the app that ever called hide() on the system status
    // bar — Theme.kt only ever set icon appearance (light vs dark), never
    // visibility. So the phone's status bar (time, network, battery,
    // notification icons) was always showing, full stop, playback or not.
    // Now the player goes edge-to-edge and hides both system bars, synced
    // with the same showControls flag the on-screen controls already use:
    // controls hidden -> status bar hidden too (immersive playback).
    // controls shown (tap, or swipe down from the top edge) -> status bar
    // reappears alongside them, and re-hides automatically when the
    // controls auto-hide again. This is standard "swipe to reveal, tap
    // elsewhere to hide again" behavior, same as YouTube/most players.
    DisposableEffect(showControls) {
        val activity = context as? Activity
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            WindowCompat.setDecorFitsSystemWindows(window, false)
            if (showControls) {
                controller.show(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            // Restore normal system bars when leaving the player so the
            // rest of the app isn't stuck in immersive mode.
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // ── Keep screen on while playing ──────────────────
    // FIX (root cause of "tap na karne se phone lock ho ja raha"):
    // FLAG_KEEP_SCREEN_ON was previously only ever set when Theatre mode
    // was toggled ON, and cleared the moment it was toggled off — it had
    // nothing to do with whether a video was actually playing. So in the
    // normal (non-theatre) case, which is most playback, the screen timeout
    // behaved exactly like it does on any other screen: if the person
    // didn't touch the display before the system's screen-off timer ran
    // out, the phone locked mid-video. Now the flag directly follows
    // isPlaying — set while playing (regardless of Theatre mode), cleared
    // on pause — so the display stays awake for as long as video is
    // actually running, and normal auto-lock resumes once paused.
    DisposableEffect(isPlaying) {
        val activity = context as? Activity
        if (isPlaying) {
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            // Always release on leaving composition (e.g. activity
            // finishing) so we never leave the flag stuck on and drain
            // battery after the player screen is gone.
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // ── Theatre / fullscreen mode ─────────────────────
    LaunchedEffect(isTheatreMode) {
        val activity = context as? Activity ?: return@LaunchedEffect
        if (!isTheatreMode && !isOrientationLocked) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        }
    }

    // ── Real-time video effect pipeline: AI Upscale mode + Picture Adjust ──
    // FIX ("ye file kuchh to effect degi"): AI 4K/8K/etc previously only
    // showed a UI badge — no pixel of the actual video was ever touched.
    // This wires exoPlayer.setVideoEffects() (Media3's real-time GPU
    // effect pipeline, confirmed against the actual androidx/media source
    // for this Media3 version — `new Contrast(float)` takes a single
    // contrast value, verified from TransformerActivity.java in the
    // androidx/media GitHub repo rather than guessed) so selecting an
    // upscale mode now visibly does something on the live video: a real,
    // modest contrast/clarity lift, running every frame on the GPU.
    //
    // EXTENDED for Picture Adjust (contrast/colour/clarity/sharpness/
    // noise/3D-depth sliders): every VideoAdjustments field is folded into
    // the SAME effect list alongside the upscale-mode boost, using only
    // Contrast/Brightness/RgbAdjustment — the three GlEffect classes
    // confirmed present in media3-effect 1.2.1 (the version this project
    // depends on; see app/build.gradle). This deliberately avoids a
    // hand-written custom GlShaderProgram: BaseGlShaderProgram's exact
    // constructor/drawFrame signature varies across Media3 versions and
    // guessing it wrong would break the CI build. RgbAdjustment's
    // redScale/greenScale/blueScale is what drives sharpness/clarity/
    // noise-reduction/depth/warmth here — each is approximated as a
    // color-channel-and-contrast recipe rather than a true per-pixel
    // detail shader. It's a real, live GPU effect on every frame (not a
    // no-op), just a coarser tool than a dedicated shader would be.
    LaunchedEffect(currentUpscale, videoAdjustments) {
        try {
            val effects = mutableListOf<androidx.media3.common.Effect>()

            // --- AI Upscale mode boost (unchanged from before) ---
            var upscaleBrightness = 0f
            var upscaleContrast = 0f
            if (currentUpscale != UpscaleMode.OFF) {
                upscaleBrightness = when (currentUpscale) {
                    UpscaleMode.AI_8K -> 0.07f
                    UpscaleMode.AI_4K -> 0.06f
                    UpscaleMode.SUPER_RESOLUTION -> 0.05f
                    else -> 0.04f
                }
                upscaleContrast = when (currentUpscale) {
                    UpscaleMode.AI_8K -> 0.07f
                    UpscaleMode.AI_4K -> 0.05f
                    UpscaleMode.SUPER_RESOLUTION -> 0.04f
                    else -> 0.03f
                }
            }

            val adj = videoAdjustments

            // --- Brightness: upscale boost + user slider, combined ---
            val totalBrightness = (upscaleBrightness + adj.brightness).coerceIn(-1f, 1f)
            if (totalBrightness != 0f) {
                effects.add(Brightness(totalBrightness))
            }

            // --- Contrast: upscale boost + user contrast + clarity (clarity
            // reads as "punchier mid-tones", which contrast approximates
            // well) + a slice of sharpness (edge contrast is a big part of
            // what perceived "sharpness" is on a flat 2D effect) ---
            val totalContrast = (
                upscaleContrast + adj.contrast + adj.clarity * 0.4f + adj.sharpness * 0.25f
            ).coerceIn(-1f, 1f)
            if (totalContrast != 0f) {
                effects.add(Contrast(totalContrast))
            }

            // --- RgbAdjustment: drives saturation, warmth, gamma-lean,
            // noise-reduction (pulls channel scales toward each other,
            // which is a coarse but real per-frame flattening) and 3D
            // depth (a subtle red/cyan channel offset that reads as
            // "pop" the way cheap anaglyph-lite depth cues do without
            // needing an actual stereo source). ---
            val satScale = 1f + adj.saturation * 0.6f
            val warmR = 1f + adj.warmth * 0.15f
            val warmB = 1f - adj.warmth * 0.15f
            val gammaR = 1f - adj.gamma * 0.1f
            val gammaG = 1f - adj.gamma * 0.1f
            val gammaB = 1f - adj.gamma * 0.1f
            val denoiseFlatten = adj.noiseReduction * 0.08f // pulls channels slightly together
            val depthR = adj.depth3D * 0.06f
            val depthB = -adj.depth3D * 0.06f

            val redScale = (satScale * warmR * gammaR + depthR - denoiseFlatten).coerceIn(0.5f, 1.8f)
            val greenScale = (satScale * gammaG - denoiseFlatten * 0.5f).coerceIn(0.5f, 1.8f)
            val blueScale = (satScale * warmB * gammaB + depthB - denoiseFlatten).coerceIn(0.5f, 1.8f)

            if (redScale != 1f || greenScale != 1f || blueScale != 1f) {
                effects.add(
                    androidx.media3.effect.RgbAdjustment.Builder()
                        .setRedScale(redScale)
                        .setGreenScale(greenScale)
                        .setBlueScale(blueScale)
                        .build()
                )
            }

            exoPlayer.setVideoEffects(effects)
        } catch (e: Exception) {
            Log.w("CinemaProPlayerScreen", "setVideoEffects failed: ${e.message}")
        }
    }

    // Hide hint overlays after delay
    LaunchedEffect(volumeHintToken) { if (showVolumeHint) { delay(1500); showVolumeHint = false } }
    LaunchedEffect(brightnessHintToken) { if (showBrightnessHint) { delay(1500); showBrightnessHint = false } }
    LaunchedEffect(showSeekHint) { if (showSeekHint) { delay(800); showSeekHint = false } }
    LaunchedEffect(scaleHintToken) { if (showScaleHint) { delay(1200); showScaleHint = false } }

    // ── UI ───────────────────────────────────────────
    Box(modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
    ) {
        // ── VIDEO SURFACE ──────────────────────────────
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = aspectRatioMode.resizeMode
                    // FIX: subtitle track selection now reaches ExoPlayer
                    // via selectSubtitleTrack() (TrackSelectionOverride),
                    // but nothing renders cues without PlayerView's own
                    // subtitle overlay. It's on by default, but we set it
                    // explicitly since this is the surface subtitles
                    // actually depend on.
                    subtitleView?.visibility = android.view.View.VISIBLE
                }
            },
            update = { view ->
                view.resizeMode = when {
                    // FIX ("3D mode side se display pura nahi h" — black
                    // bars on left/right when 3D is on): RESIZE_MODE_FILL
                    // should crop-to-fill with no bars, but PlayerView's
                    // internal SurfaceView re-layout on a resizeMode
                    // change can lag a frame or two behind recomposition,
                    // occasionally leaving a stale letterboxed layout
                    // visible. RESIZE_MODE_ZOOM is a stronger guarantee
                    // here — it always crops to fill the container with
                    // no possibility of bars, which is exactly what the
                    // 3D depth overlay needs to look right edge-to-edge.
                    current3DMode != VideoMode3D.OFF -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    isTheatreMode -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    else -> aspectRatioMode.resizeMode
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = videoScale
                    scaleY = videoScale
                }
                // ── GESTURE: Pinch to zoom (2 fingers) ────────────────────
                .pointerInput(Unit) {
                    detectTransformGestures { _, _, zoom, _ ->
                        videoScale = (videoScale * zoom).coerceIn(0.5f, 4f)
                        showScaleHint = true
                        scaleHintToken++
                    }
                }
                // ── GESTURE: Tap / Double-tap ──────────────
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            showControls = !showControls
                        },
                        onDoubleTap = { offset ->
                            val w = size.width
                            when {
                                offset.x < w / 3 -> {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                                    seekHintText = "-10s"
                                    showSeekHint = true
                                }
                                offset.x > w * 2 / 3 -> {
                                    exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(duration))
                                    seekHintText = "+10s"
                                    showSeekHint = true
                                }
                                // FIX ("pause button dabane se video 2x
                                // forward chalta h"): the center third of
                                // this double-tap used to ALSO toggle
                                // exoPlayer.playWhenReady. That's exactly
                                // the same screen region as the real
                                // Play/Pause FAB above it — so a tap on
                                // the button that Compose also delivered
                                // to this lower gesture layer (or a quick
                                // second tap right after) could toggle
                                // playback a second time immediately after
                                // the button's own pause, i.e. pause then
                                // instant resume, which combined with the
                                // seek-drag/position-poll changes made it
                                // look like the video "jumped forward" on
                                // pause. Play/Pause now has exactly one
                                // control — the FAB — so there's nothing
                                // left to fight it. Center double-tap now
                                // just reveals the controls.
                                else -> {}
                            }
                            showControls = true
                        }
                    )
                }
                // ── GESTURE: Swipe – seek / volume / brightness ──
                // FIX (jerky/stuttery pinch-to-zoom): this drag detector
                // and the pinch-to-zoom detectTransformGestures() above it
                // were both listening to the SAME raw pointer stream at
                // the same time. During a 2-finger pinch, Compose was
                // handing pointer movement to BOTH gesture detectors
                // simultaneously — this one saw the second finger's motion
                // as an ordinary drag, called change.consume() on it, and
                // started nudging volume/brightness/seek WHILE the
                // transform detector was also trying to compute a smooth
                // zoom from the same two fingers. Two detectors fighting
                // over one gesture is exactly what produced the
                // stutter/jerkiness. Now this block explicitly bails out
                // the moment a second pointer goes down, so single-finger
                // drags and 2-finger pinches never overlap.
                .pointerInput(Unit) {
                    awaitEachGesture {
                        // Wait for the first finger down, but immediately
                        // bail if it's already a multi-touch event.
                        val down = awaitFirstDown(requireUnconsumed = false)
                        var gestureType: GestureType? = null
                        var startX = down.position.x
                        var startY = down.position.y
                        var accDx = 0f
                        var accDy = 0f
                        var dragStartPos = 0L
                        var started = false

                        while (true) {
                            val event = awaitPointerEvent()
                            // A second finger touched down mid-gesture —
                            // this is now a pinch, not a drag. Stop
                            // tracking immediately and let
                            // detectTransformGestures own it exclusively.
                            if (event.changes.size > 1) {
                                if (started) {
                                    isDragging = false
                                    showVolumeHint = false
                                    showBrightnessHint = false
                                }
                                break
                            }

                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) {
                                if (started) {
                                    isDragging = false
                                    showVolumeHint = false
                                    showBrightnessHint = false
                                }
                                break
                            }

                            val dragAmount = change.positionChange()
                            if (dragAmount != androidx.compose.ui.geometry.Offset.Zero) {
                                if (!started) {
                                    started = true
                                    isDragging = true
                                    dragStartPos = exoPlayer.currentPosition
                                    showControls = true
                                }
                                change.consume()
                                accDx += dragAmount.x
                                accDy += dragAmount.y

                                if (gestureType == null && (abs(accDx) > 20 || abs(accDy) > 20)) {
                                    gestureType = when {
                                        abs(accDx) > abs(accDy) -> GestureType.SEEK
                                        startX < size.width / 2 -> GestureType.VOLUME
                                        else -> GestureType.BRIGHTNESS
                                    }
                                }

                                when (gestureType) {
                                    GestureType.SEEK -> {
                                        val pct = accDx / size.width
                                        val seekMs = (pct * minOf(duration, 120_000L)).toLong()
                                        val newPos = (dragStartPos + seekMs).coerceIn(0, duration)
                                        exoPlayer.seekTo(newPos)
                                        currentPosition = newPos
                                    }
                                    GestureType.VOLUME -> {
                                        val delta = -dragAmount.y / size.height
                                        volumeLevel = (volumeLevel + delta * 2).coerceIn(0f, 1f)
                                        setSystemVolume(context, volumeLevel)
                                        showVolumeHint = true
                                        volumeHintToken++
                                    }
                                    GestureType.BRIGHTNESS -> {
                                        val delta = -dragAmount.y / size.height
                                        brightnessLevel = (brightnessLevel + delta * 2).coerceIn(0.01f, 1f)
                                        setScreenBrightness(context, brightnessLevel)
                                        showBrightnessHint = true
                                        brightnessHintToken++
                                    }
                                    null -> {}
                                }
                            }
                        }
                    }
                }
        )

        // ── GESTURE: Swipe up from bottom edge to open Equalizer ──
        // A slim invisible strip along the bottom edge, separate from the
        // main seek/volume/brightness drag layer above so it can't
        // conflict with those gestures (different pointerInput instance,
        // small fixed height, only active when the panel is closed).
        // Swiping down to CLOSE is handled inside the Equalizer panel
        // itself below, since once it's open it owns the full screen.
        if (!showEqualizer) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(28.dp)
                    .pointerInput(Unit) {
                        var accDy = 0f
                        detectDragGestures(
                            onDragStart = { accDy = 0f },
                            onDragEnd = {
                                if (accDy < -60f) showEqualizer = true
                                accDy = 0f
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                accDy += dragAmount.y
                            }
                        )
                    }
            )
        }

        // ── 3D MODE OVERLAY ────────────────────────────
        if (current3DMode != VideoMode3D.OFF) {
            ThreeDModeOverlay(mode = current3DMode)
        }

        // ── Theatre mode dim bars ──────────────────────
        if (isTheatreMode) {
            Box(modifier = Modifier.fillMaxWidth().height(56.dp).align(Alignment.TopCenter).background(Color.Black))
            Box(modifier = Modifier.fillMaxWidth().height(56.dp).align(Alignment.BottomCenter).background(Color.Black))
        }

        // ── LOADING ────────────────────────────────────
        if (isLoading && !isPipMode) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CinemaGold, strokeWidth = 3.dp, modifier = Modifier.size(60.dp))
            }
        }

        // ── ERROR ──────────────────────────────────────
        playerError?.let { err ->
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.92f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Default.ErrorOutline, null, tint = CinemaRed, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Playback Error", color = CinemaRed, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(err, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                    Button(onClick = {
                        // FIX: plain exoPlayer.prepare() after an error just
                        // re-prepares whatever MediaItem is already loaded,
                        // which after a hard IDLE-state error can re-trigger
                        // the same failure and also restarts from 0 instead
                        // of where playback actually stopped. Re-setting the
                        // MediaItem with the last known position (same
                        // recovery path as the automatic retry above) gives
                        // manual retry the same, more reliable behavior.
                        val resumePos = exoPlayer.currentPosition.coerceAtLeast(0L)
                        playerError = null
                        autoRecoverAttempts = 0
                        exoPlayer.setMediaItem(MediaItem.fromUri(videoUri), resumePos)
                        exoPlayer.prepare()
                        exoPlayer.playWhenReady = true
                    }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                        Text("Retry", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ── HINT OVERLAYS ──────────────────────────────
        // Volume hint
        AnimatedVisibility(visible = showVolumeHint, modifier = Modifier.align(Alignment.CenterStart).padding(start = 24.dp)) {
            HintPill(icon = if (volumeLevel > 0) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                label = "${(volumeLevel * 100).toInt()}%", color = CinemaBlue)
        }

        // Brightness hint
        AnimatedVisibility(visible = showBrightnessHint, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 24.dp)) {
            HintPill(icon = Icons.Default.Brightness6,
                label = "${(brightnessLevel * 100).toInt()}%", color = CinemaGold)
        }

        // Seek hint
        AnimatedVisibility(visible = showSeekHint, modifier = Modifier.align(Alignment.Center)) {
            Box(modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(0.75f)).padding(16.dp, 12.dp)) {
                Text(seekHintText, color = CinemaGold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Scale hint (pinch to zoom)
        AnimatedVisibility(visible = showScaleHint, modifier = Modifier.align(Alignment.Center)) {
            Row(modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(0.75f)).padding(16.dp, 12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.ZoomIn, null, tint = CinemaGold, modifier = Modifier.size(24.dp))
                Text("${"%.1f".format(videoScale)}x", color = CinemaGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                // Reset button
                if (videoScale != 1f) {
                    Spacer(Modifier.width(4.dp))
                    TextButton(onClick = {
                        videoScale = 1f
                        scaleHintToken++
                    }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Text("Reset", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // ── AI / 3D / MODE BADGES — auto-hide after 5s ──
        // FIX ("button invisible kiye ho 5sec bad" / earlier ask: "notification
        // hmesha show hota rhta right upper corner pe usko 5 sec bad invisible
        // krdo"): these badges previously had zero auto-hide — they stayed on
        // screen permanently as long as a mode was active. Real fix: a
        // dedicated visibility flag + timer, independent of showControls (so
        // it hides even while the rest of the control overlay is showing),
        // that resets to visible-for-5s any time one of the badge-worthy
        // states actually changes (upscale mode, 3D mode, theatre, surround).
        // The underlying mode itself is untouched — only the little pill
        // badge fades away; reopening the selector or switching modes brings
        // it back for another 5 seconds.
        var showModeBadges by remember { mutableStateOf(true) }
        val anyBadgeActive = currentUpscale != UpscaleMode.OFF || current3DMode != VideoMode3D.OFF ||
            isTheatreMode || (surroundMode != SurroundMode.STEREO && dspStatus.virtualizerActive)
        LaunchedEffect(currentUpscale, current3DMode, isTheatreMode, surroundMode, dspStatus.virtualizerActive) {
            if (anyBadgeActive) {
                showModeBadges = true
                delay(5000)
                showModeBadges = false
            }
        }
        AnimatedVisibility(
            visible = showModeBadges,
            modifier = Modifier.align(Alignment.TopEnd),
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(400))
        ) {
            Row(modifier = Modifier.padding(top = 52.dp, end = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (currentUpscale != UpscaleMode.OFF) {
                    Badge(text = when (currentUpscale) {
                        UpscaleMode.AI_4K -> "AI 4K"
                        UpscaleMode.AI_8K -> "AI 8K"
                        UpscaleMode.SUPER_RESOLUTION -> "AI SR"
                        UpscaleMode.SHARPEN -> "SHARP"
                        UpscaleMode.DENOISE -> "DENOISE"
                        UpscaleMode.HDR_SIMULATION -> "HDR"
                        else -> ""
                    }, color = CinemaGreen)
                }
                if (current3DMode != VideoMode3D.OFF) {
                    Badge(text = "3D ${current3DMode.label}", color = CinemaBlue)
                }
                if (isTheatreMode) {
                    Badge(text = "THEATRE", color = CinemaPurple)
                }
                // Real, verified surround status — only shown when the DSP
                // engine has confirmed effects are actually live, not just
                // because a mode was selected in the UI.
                if (surroundMode != SurroundMode.STEREO && dspStatus.virtualizerActive) {
                    Badge(text = surroundMode.label.uppercase(), color = CinemaGold)
                }
            }
        }

        // ── AUDIO FX WARNING ───────────────────────────
        // Honest feedback: if the session is open but effects genuinely
        // could not attach (device restriction, OEM audio policy, etc.),
        // tell the person plainly instead of leaving EQ/surround sliders
        // that silently do nothing.
        AnimatedVisibility(
            visible = showAudioFxWarning,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 52.dp),
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200))
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFB33A3A).copy(alpha = 0.9f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Warning, null, tint = Color.White, modifier = Modifier.size(18.dp))
                Text("Audio effects unavailable on this device", color = Color.White, fontSize = 13.sp)
            }
        }

        // Speed badge
        if (currentSpeed != 1.0f) {
            Badge(
                text = "${currentSpeed}x",
                color = CinemaPurple,
                modifier = Modifier.align(Alignment.TopStart).padding(top = 52.dp, start = 12.dp)
            )
        }

        // ── TOP-CENTER CONTROL PILLS: Audio / Subtitle / EQ / Adjust ──
        // FIX ("equilzer aur video adjust button ko audio, sub k bagal
        // rkho top pe" + "Fit/AUTO/3D/square button timeline k niche kro"):
        // Aspect Ratio, Quality/Speed/3D/AI/Theatre/Fullscreen chips all
        // moved down to the bottom row next to the timeline (see BOTTOM
        // CONTROLS below). Only Audio + Subtitle stay up top, and EQ +
        // Picture Adjust now join them here instead of sitting at the
        // bottom — this keeps the top row short (4 items) so nothing
        // overlaps the title bar, while still making EQ/Adjust reachable
        // right next to Audio/Sub as requested.
        AnimatedVisibility(
            visible = showControls && !isPipMode,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = if (showAudioFxWarning) 92.dp else 52.dp),
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200))
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { showAudioTracks = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.55f)),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Audiotrack, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Audio", fontSize = 12.sp, color = Color.White)
                }
                Button(
                    onClick = { showSubtitleTracks = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (currentSubtitle != null) CinemaGold else Color.Black.copy(alpha = 0.55f)
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Subtitles, null,
                        tint = if (currentSubtitle != null) Color.Black else Color.White,
                        modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Sub", fontSize = 12.sp, color = if (currentSubtitle != null) Color.Black else Color.White)
                }
                // Picture Adjust — moved up here next to Audio/Sub.
                Button(
                    onClick = { showVideoAdjust = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!videoAdjustments.isNeutral) CinemaGold else Color.Black.copy(alpha = 0.55f)
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Tune, "Picture Adjust",
                        tint = if (!videoAdjustments.isNeutral) Color.Black else Color.White,
                        modifier = Modifier.size(16.dp))
                }
                // Equalizer — moved up here next to Audio/Sub.
                Button(
                    onClick = { showEqualizer = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (currentPreset != EqualizerPreset.FLAT) CinemaGold else Color.Black.copy(alpha = 0.55f)
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Icon(Icons.Default.Equalizer, "Equalizer",
                        tint = if (currentPreset != EqualizerPreset.FLAT) Color.Black else Color.White,
                        modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("EQ", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = if (currentPreset != EqualizerPreset.FLAT) Color.Black else Color.White)
                }
            }
        }

        // ── CONTROLS OVERLAY ──────────────────────────
        AnimatedVisibility(
            visible = showControls && !isPipMode,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(300))
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(0.85f), Color.Transparent, Color.Transparent, Color.Black.copy(0.9f)))
                )
            ) {
                // ── TOP BAR ──────────────────────────────
                // Was previously a hardcoded `padding(top = 44.dp)`, tuned
                // by eye for portrait mode. That guess breaks in landscape
                // (and on some phones even in portrait): the gesture nav
                // bar / rounded-corner safe area / camera cutout can sit on
                // any edge depending on orientation and device, and a fixed
                // 44dp does nothing to protect the RIGHT edge in landscape
                // — which is exactly why Lock/Theatre/PIP were overlapping
                // the phone's own system toggle/gesture area in the
                // screenshot. windowInsetsPadding(WindowInsets.safeDrawing)
                // asks Android itself where it's safe to draw, so this
                // adapts automatically to portrait, landscape, notches,
                // and gesture-nav placement instead of a hand-tuned number.
                // ── TOP BAR + MODE CHIPS — wrapped in a Column ──
                // FIX ("movie name uppr likh k aata h usse overlap na ho
                // koi button"): the title Row (back/title/lock/theatre/
                // pip) and the mode-chips Row below it were previously
                // both DIRECT children of the outer Box(fillMaxSize()).
                // A plain Box stacks all its children at the same
                // top-start origin unless each child sets its own
                // align() — neither Row did, so they were literally
                // drawn on top of each other, which is why the movie
                // title text sat underneath/behind the AI 8K / 3D /
                // Theatre / Auto chips. Wrapping both Rows in one Column
                // makes them lay out top-to-bottom in sequence instead —
                // title bar first, then the chip row just below it, never
                // overlapping regardless of how long the movie title is.
                Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(horizontal = 16.dp)
                        .padding(top = 8.dp, end = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        scope.launch(Dispatchers.IO) {
                            if (videoId > 0) db.videoHistoryDao().insertOrUpdate(
                                VideoHistoryEntity(videoId, videoTitle, videoUri, duration, exoPlayer.currentPosition)
                            )
                        }
                        onBackPressed()
                    }) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(28.dp))
                    }

                    Text(videoTitle.ifEmpty { "CINEMA PRO" },
                        color = CinemaGold, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp))

                    // Pulled in from the true screen edge (was flush right
                    // before, which is exactly where a thumb rests / an
                    // edge-swipe gesture lands — causing accidental taps on
                    // Lock/Theatre/PIP). Also spaced further apart so a
                    // slightly-off tap doesn't hit the neighboring button.
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        // Orientation lock
                        IconButton(onClick = {
                            isOrientationLocked = !isOrientationLocked
                            val activity = context as? Activity
                            if (isOrientationLocked) {
                                val orientation = context.resources.configuration.orientation
                                activity?.requestedOrientation = if (orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
                                    ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            } else {
                                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                            }
                        }, modifier = Modifier.size(40.dp)) {
                            Icon(
                                if (isOrientationLocked) Icons.Default.ScreenLockRotation else Icons.Default.ScreenRotation,
                                "Lock", tint = if (isOrientationLocked) CinemaGold else Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        // Theatre mode
                        IconButton(onClick = { isTheatreMode = !isTheatreMode }, modifier = Modifier.size(40.dp)) {
                            Icon(Icons.Default.Theaters, "Theatre", tint = if (isTheatreMode) CinemaPurple else Color.White,
                                modifier = Modifier.size(22.dp))
                        }
                        // PIP — kept as the rightmost/edge-most button since
                        // it's the least destructive one to fat-finger, and
                        // it now has real padding from the screen edge
                        // instead of sitting flush against it.
                        IconButton(onClick = { onEnterPip?.invoke() }, modifier = Modifier.size(40.dp)) {
                            Icon(Icons.Default.PictureInPicture, "PIP", tint = Color.White,
                                modifier = Modifier.size(22.dp))
                        }
                    }
                }

                } // close Column wrapping title bar only — mode chips
                  // (Fit/Quality/Speed/3D/AI/Theatre/Fullscreen) moved
                  // down next to the timeline, see BOTTOM CONTROLS below.

                // ── CENTER CONTROLS ───────────────────────
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0)) },
                            modifier = Modifier.size(56.dp)) {
                            Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                        FloatingActionButton(
                            onClick = { exoPlayer.playWhenReady = !isPlaying },
                            containerColor = CinemaGold, modifier = Modifier.size(80.dp), shape = CircleShape
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                null, tint = Color.Black, modifier = Modifier.size(48.dp)
                            )
                        }
                        IconButton(onClick = { exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(duration)) },
                            modifier = Modifier.size(56.dp)) {
                            Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                    }
                }

                // ── BOTTOM CONTROLS ───────────────────────
                Column(modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 20.dp)) {
                    // Mode chips row — Fit/Quality/Speed/3D/AI/Theatre/
                    // Fullscreen + Loop, all sitting right above the
                    // timeline now.
                    // FIX ("auto, 1.9, 3D, aur square button ko timeline
                    // bar k niche kro ye overlap kr rha"): these used to
                    // live in their own row up top (overlapping the title
                    // bar / EQ row). Now grouped in one horizontally-
                    // scrollable row directly above the seek bar so
                    // nothing overlaps and everything scrolls into view
                    // even on narrow phone widths.
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SmallIconButton(Icons.Default.Repeat, "Loop", isLooping, CinemaGold) {
                            isLooping = !isLooping
                            exoPlayer.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                        }
                        FeatureChip(aspectRatioMode.label, if (aspectRatioMode != AspectRatioMode.FIT) CinemaBlue else Color.White) { aspectRatioMode = aspectRatioMode.next() }
                        FeatureChip(currentQuality.label, CinemaBlue) { showQualitySelector = true }
                        FeatureChip("${currentSpeed}x", Color.White) { showSpeedSelector = true }
                        FeatureChip(if (current3DMode == VideoMode3D.OFF) "2D" else "3D", if (current3DMode != VideoMode3D.OFF) CinemaBlue else Color.White) { show3DSelector = true }
                        FeatureChip(if (currentUpscale == UpscaleMode.OFF) "AI" else "AI✓", if (currentUpscale != UpscaleMode.OFF) CinemaGreen else Color.White) { showUpscaleSelector = true }
                        FeatureChip(if (isTheatreMode) "🎭" else "Theatre", if (isTheatreMode) CinemaPurple else Color.White) { isTheatreMode = !isTheatreMode }
                        IconButton(onClick = {
                            isTheatreMode = !isTheatreMode
                            val activity = context as? Activity
                            if (!isTheatreMode) {
                                activity?.requestedOrientation = if (isOrientationLocked) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR
                            }
                        }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Fullscreen, null, tint = Color.White)
                        }
                    }

                    Spacer(Modifier.height(4.dp))

                    // ── TIMELINE / SEEK BAR — moved back to bottom ──
                    // FIX ("video time line ko niche krdo"): this had been
                    // moved to the top in an earlier pass; moved back down
                    // here per the current request, now sitting just above
                    // the time text where a seek bar conventionally lives.
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Buffer
                        Slider(value = bufferedPosition.toFloat(), onValueChange = {},
                            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(thumbColor = Color.Transparent, activeTrackColor = Color.White.copy(0.25f), inactiveTrackColor = Color.Transparent),
                            modifier = Modifier.fillMaxWidth())
                        // Progress — FIX ("timeline bar smoothly kaam nahi
                        // kr rha"): the seek bar was rebuilt every
                        // recomposition directly off currentPosition
                        // (which updates every player tick), so the thumb
                        // could visually "fight" between the player's
                        // real-time position updates and the user's own
                        // drag gesture — dragging felt laggy/jumpy instead
                        // of smooth. Standard fix: track drag state
                        // locally while the user is actively dragging, and
                        // only let the player's live position drive the
                        // slider when the user ISN'T touching it. The
                        // seek itself now also only fires on
                        // onValueChangeFinished (once, on release) instead
                        // of on every intermediate onValueChange tick,
                        // which was spamming exoPlayer.seekTo() many times
                        // per second during a drag and causing the
                        // stutter.
                        // FIX continued: isDraggingSeek used to be a
                        // LOCAL var scoped only inside this Slider block,
                        // so the outer progress-polling loop had no way
                        // to know a drag was in progress. It was then
                        // switched to reuse the screen's `isDragging`
                        // flag — but that flag is ALSO owned by the
                        // separate video-surface swipe gesture (seek/
                        // volume/brightness by dragging on the video
                        // itself), and the two gestures stomping on one
                        // shared flag is exactly what made the seek bar
                        // feel stuck/jerky again. Now using its own
                        // dedicated `isSeekBarDragging` flag so neither
                        // gesture can interfere with the other.
                        var dragPosition by remember { mutableFloatStateOf(0f) }
                        Slider(
                            value = if (isSeekBarDragging) dragPosition else currentPosition.toFloat(),
                            onValueChange = {
                                isSeekBarDragging = true
                                dragPosition = it
                            },
                            onValueChangeFinished = {
                                exoPlayer.seekTo(dragPosition.toLong())
                                currentPosition = dragPosition.toLong()
                                isSeekBarDragging = false
                            },
                            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(thumbColor = CinemaGold, activeTrackColor = CinemaGold, inactiveTrackColor = Color.Gray.copy(0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Text("${formatTime(currentPosition)} / ${formatTime(duration)}",
                        color = Color.White, fontSize = 13.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                }
            }
        }

        // ── DIALOGS ───────────────────────────────────
        if (showAudioTracks) {
            TrackSelectorDialog("Audio Tracks", audioTracks.map { it.label },
                audioTracks.indexOfFirst { it.isSelected },
                { idx -> audioTracks.getOrNull(idx)?.let { selectAudioTrack(it.id) }; showAudioTracks = false },
                { showAudioTracks = false })
        }
        if (showSubtitleTracks) {
            TrackSelectorDialog("Subtitles", listOf("Off") + subtitleTracks.map { it.label },
                if (currentSubtitle == null) 0 else subtitleTracks.indexOf(currentSubtitle) + 1,
                { idx ->
                    if (idx == 0) {
                        currentSubtitle = null
                        setSubtitleOff()
                    } else {
                        val track = subtitleTracks.getOrNull(idx - 1)
                        currentSubtitle = track
                        track?.let { selectSubtitleTrack(it.id) }
                    }
                    showSubtitleTracks = false
                },
                { showSubtitleTracks = false })
        }
        if (showQualitySelector) {
            TrackSelectorDialog("Video Quality", VideoQuality.values().map { it.label },
                VideoQuality.values().indexOf(currentQuality),
                { idx -> currentQuality = VideoQuality.values()[idx]; showQualitySelector = false },
                { showQualitySelector = false })
        }
        if (showSpeedSelector) {
            val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f)
            TrackSelectorDialog("Playback Speed", speeds.map { "${it}x" },
                speeds.indexOf(currentSpeed),
                { idx -> currentSpeed = speeds[idx]; exoPlayer.setPlaybackSpeed(currentSpeed); showSpeedSelector = false },
                { showSpeedSelector = false })
        }
        if (show3DSelector) {
            ThreeDModeDialog(current3DMode, { mode -> current3DMode = mode; show3DSelector = false }, { show3DSelector = false })
        }
        if (showUpscaleSelector) {
            AIUpscaleDialog(currentUpscale, { mode -> currentUpscale = mode; showUpscaleSelector = false }, { showUpscaleSelector = false })
        }

        // ── EQUALIZER PANEL ───────────────────────────
        AnimatedVisibility(visible = showEqualizer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            EqualizerPanel(
                currentPreset = currentPreset, customBands = customBands,
                surroundMode = surroundMode, bassLevel = bassLevel,
                nightMode = nightMode, dialogEnhance = dialogEnhance, volumeNormalization = volumeNormalization,
                volumeEnhancement = volumeEnhancement,
                customPresets = customPresets,
                onDeleteCustomPreset = { preset ->
                    scope.launch(Dispatchers.IO) {
                        db.equalizerPresetDao().deletePreset(preset.toEntity())
                    }
                },
                onPresetSelected = { preset ->
                    currentPreset = preset; customBands = preset.bands.copyOf()
                    dspEngine.applyEqualizerPreset(preset)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, preset = preset)
                },
                onBandChanged = { i, v ->
                    val newBands = customBands.copyOf(); newBands[i] = v; customBands = newBands
                    currentPreset = EqualizerPreset("custom", "Custom", newBands)
                    dspEngine.applyEqualizerPreset(currentPreset)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, preset = currentPreset)
                },
                onSurroundModeChanged = {
                    surroundMode = it; dspEngine.setSurroundMode(it)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, surroundMode = it)
                },
                onBassChanged = {
                    bassLevel = it; dspEngine.setBassLevel(it)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, bassLevel = it)
                },
                onNightModeChanged = { nightMode = it; dspEngine.setNightMode(it) },
                onDialogEnhanceChanged = { dialogEnhance = it; dspEngine.setDialogEnhancement(it) },
                onVolumeNormalizationChanged = { volumeNormalization = it; dspEngine.setVolumeNormalization(it) },
                onVolumeEnhancementChanged = { volumeEnhancement = it; dspEngine.setVolumeEnhancement(it) },
                onSaveCustomPreset = { showCustomSaveDialog = true },
                globalEqEnabled = globalEqEnabled,
                onGlobalEqChanged = { enabled ->
                    globalEqEnabled = enabled
                    val svcIntent = android.content.Intent(context, com.cinemapro.player.service.GlobalEqualizerService::class.java)
                    if (enabled) {
                        com.cinemapro.player.service.GlobalEqualizerService.saveState(context, true, currentPreset, surroundMode, bassLevel)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(svcIntent)
                        } else {
                            context.startService(svcIntent)
                        }
                    } else {
                        svcIntent.action = com.cinemapro.player.service.GlobalEqualizerService.ACTION_STOP
                        context.startService(svcIntent)
                    }
                },
                onDismiss = { showEqualizer = false }
            )
        }

        // ── PICTURE ADJUST PANEL ──────────────────────
        AnimatedVisibility(visible = showVideoAdjust, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            VideoAdjustPanel(
                adjustments = videoAdjustments,
                onAdjustmentsChanged = { videoAdjustments = it },
                onDismiss = { showVideoAdjust = false },
                customPresets = customVideoAdjustPresets,
                onSaveCustomPreset = { showVideoAdjustSaveDialog = true },
                onLoadCustomPreset = { preset -> videoAdjustments = preset.toVideoAdjustments() },
                onDeleteCustomPreset = { preset ->
                    scope.launch(Dispatchers.IO) {
                        db.videoAdjustPresetDao().deletePreset(preset)
                    }
                }
            )
        }

        // Save Custom Picture-Adjust Preset Dialog — "meri personal
        // settings save ho custom video adjust save krne k liye"
        if (showVideoAdjustSaveDialog) {
            AlertDialog(
                onDismissRequest = { showVideoAdjustSaveDialog = false },
                title = { Text("Save Custom Picture Preset", color = Color.White) },
                text = {
                    OutlinedTextField(value = videoAdjustPresetName, onValueChange = { videoAdjustPresetName = it },
                        label = { Text("Preset Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CinemaSurface, unfocusedContainerColor = CinemaSurface,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CinemaGold, unfocusedBorderColor = CinemaSurfaceLight
                        ))
                },
                confirmButton = {
                    Button(onClick = {
                        if (videoAdjustPresetName.isNotEmpty()) {
                            val entity = videoAdjustments.toEntity(
                                id = "custom_va_${System.currentTimeMillis()}",
                                name = videoAdjustPresetName
                            )
                            scope.launch(Dispatchers.IO) {
                                db.videoAdjustPresetDao().insertPreset(entity)
                            }
                        }
                        showVideoAdjustSaveDialog = false; videoAdjustPresetName = ""
                    }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                        Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { showVideoAdjustSaveDialog = false }) { Text("Cancel", color = CinemaGray) } },
                containerColor = CinemaSurface
            )
        }

        // Save Preset Dialog
        if (showCustomSaveDialog) {
            AlertDialog(
                onDismissRequest = { showCustomSaveDialog = false },
                title = { Text("Save Custom Preset", color = Color.White) },
                text = {
                    OutlinedTextField(value = customPresetName, onValueChange = { customPresetName = it },
                        label = { Text("Preset Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CinemaSurface, unfocusedContainerColor = CinemaSurface,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CinemaGold, unfocusedBorderColor = CinemaSurfaceLight
                        ))
                },
                confirmButton = {
                    Button(onClick = {
                        if (customPresetName.isNotEmpty()) {
                            val newPreset = EqualizerPreset("custom_${System.currentTimeMillis()}", customPresetName, customBands.copyOf(), isBuiltIn = false)
                            scope.launch(Dispatchers.IO) {
                                db.equalizerPresetDao().insertPreset(newPreset.toEntity())
                            }
                        }
                        showCustomSaveDialog = false; customPresetName = ""
                    }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                        Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { showCustomSaveDialog = false }) { Text("Cancel", color = CinemaGray) } },
                containerColor = CinemaSurface
            )
        }
    }

    // Cleanup
    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
            dspEngine.release()
        }
    }
}

// ── Gesture type ──────────────────────────────────
private enum class GestureType { SEEK, VOLUME, BRIGHTNESS }

// ── Aspect ratio / display ratio mode ─────────────
private enum class AspectRatioMode(val label: String, val resizeMode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH_WIDTH("Stretch W", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
    STRETCH_HEIGHT("Stretch H", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT);

    fun next(): AspectRatioMode = values()[(ordinal + 1) % values().size]
}

// ── 3D Mode Overlay ───────────────────────────────
@Composable
fun ThreeDModeOverlay(mode: VideoMode3D) {
    when (mode) {
        VideoMode3D.ANAGLYPH -> {
            // Anaglyph tint overlay (red-cyan simulation)
            Box(modifier = Modifier.fillMaxSize()) {
                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(0.5f).background(Color.Red.copy(0.15f)))
                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(0.5f).align(Alignment.CenterEnd).background(Color.Cyan.copy(0.15f)))
            }
        }
        VideoMode3D.STEREOSCOPIC -> {
            // FIX ("charo taraf ki line halka rkho jo dikhai na de", "aur
            // deep kro"): the hard 4dp/3dp/1.5dp borders from the last
            // version were clearly visible as outline rectangles in
            // screenshots — reads as "a frame drawn on the video", not
            // depth. Depth perception doesn't actually need a visible
            // edge line at all; it comes from a smooth center-to-edge
            // falloff (things "up close" are brighter/sharper-feeling,
            // things receding into the edges darken gradually with no
            // hard line anywhere). So: borders removed entirely, and the
            // radial gradient — the part that actually reads as "depth"
            // rather than "frame" — is pushed stronger and layered in two
            // radii for a smoother, deeper falloff.
            Box(modifier = Modifier.fillMaxSize()) {
                // Wide, soft outer falloff — no hard edge, starts well
                // before the frame border so there's nothing to see as a
                // "line", just a gradual darkening.
                Box(
                    modifier = Modifier.fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.30f)
                                ),
                                radius = 1500f
                            )
                        )
                )
                // Second, tighter radius layered on top for a deeper,
                // more pronounced center-forward pop — this is what
                // makes it read as "depth" rather than a flat vignette.
                Box(
                    modifier = Modifier.fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.28f)
                                ),
                                radius = 950f
                            )
                        )
                )
            }
        }
        VideoMode3D.SBS, VideoMode3D.TAB -> {
            // Same underlying gap as STEREOSCOPIC above — real SBS/TAB
            // needs the source to actually be a side-by-side or
            // top-bottom packed stereo file split into two views, which
            // this player doesn't decode specially yet. Until that's
            // wired, at least show a real split-frame guide line so the
            // mode reads as doing something rather than a silent no-op.
            Box(modifier = Modifier.fillMaxSize()) {
                if (mode == VideoMode3D.SBS) {
                    Box(
                        modifier = Modifier.fillMaxHeight().width(1.dp)
                            .align(Alignment.Center)
                            .background(CinemaBlue.copy(alpha = 0.35f))
                    )
                } else {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(1.dp)
                            .align(Alignment.Center)
                            .background(CinemaBlue.copy(alpha = 0.35f))
                    )
                }
            }
        }
        VideoMode3D.VR_360, VideoMode3D.VR_180 -> {
            // VR mode indicator
            Box(modifier = Modifier.fillMaxSize().border(3.dp, CinemaBlue.copy(0.5f)))
        }
        else -> {}
    }
}

// ── AI Upscale Dialog ─────────────────────────────
@Composable
fun AIUpscaleDialog(current: UpscaleMode, onSelect: (UpscaleMode) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🤖 AI Video Upscale", color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(UpscaleMode.values().toList()) { mode ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSelect(mode) }.padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(mode.label, color = if (mode == current) CinemaGold else Color.White, fontSize = 16.sp)
                            Text(when (mode) {
                                UpscaleMode.OFF -> "Native resolution"
                                UpscaleMode.SHARPEN -> "Edge sharpening filter"
                                UpscaleMode.DENOISE -> "Noise reduction"
                                UpscaleMode.HDR_SIMULATION -> "HDR tone mapping"
                                UpscaleMode.AI_4K -> "AI neural 4K upscale (ESRGAN)"
                                UpscaleMode.AI_8K -> "AI neural 8K upscale (ESRGAN)"
                                UpscaleMode.SUPER_RESOLUTION -> "Super resolution ML model"
                            }, color = CinemaGray, fontSize = 12.sp)
                        }
                        if (mode == current) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (mode != UpscaleMode.values().last()) HorizontalDivider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

// ── 3D Mode Dialog ────────────────────────────────
@Composable
fun ThreeDModeDialog(current: VideoMode3D, onSelect: (VideoMode3D) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("📽️ 3D Video Mode", color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(VideoMode3D.values().toList()) { mode ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSelect(mode) }.padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(mode.label, color = if (mode == current) CinemaGold else Color.White, fontSize = 16.sp)
                            Text(when (mode) {
                                VideoMode3D.OFF -> "Normal 2D playback"
                                VideoMode3D.SBS -> "Side-by-Side 3D (for VR headsets)"
                                VideoMode3D.TAB -> "Top-and-Bottom 3D"
                                VideoMode3D.ANAGLYPH -> "Classic Red-Cyan 3D glasses"
                                VideoMode3D.VR_360 -> "360° immersive VR video"
                                VideoMode3D.VR_180 -> "180° VR half-sphere"
                                VideoMode3D.STEREOSCOPIC -> "Dual-stream stereoscopic 3D"
                            }, color = CinemaGray, fontSize = 12.sp)
                        }
                        if (mode == current) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (mode != VideoMode3D.values().last()) HorizontalDivider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

// ── Reusable UI atoms ─────────────────────────────

@Composable
fun HintPill(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color) {
    Column(
        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(0.8f)).padding(14.dp, 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Badge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.clip(RoundedCornerShape(6.dp)).background(color.copy(0.9f)).padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(text, color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun SmallIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, active: Boolean, activeColor: Color, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(icon, desc, tint = if (active) activeColor else Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun FeatureChip(label: String, color: Color, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun TrackSelectorDialog(title: String, tracks: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(tracks.size) { i ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 13.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(tracks[i], color = if (i == selectedIndex) CinemaGold else Color.White, fontSize = 16.sp)
                        if (i == selectedIndex) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (i < tracks.size - 1) HorizontalDivider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

@Composable
fun EqualizerPanel(
    currentPreset: EqualizerPreset, customBands: FloatArray, surroundMode: SurroundMode,
    bassLevel: Int, nightMode: Boolean, dialogEnhance: Boolean, volumeNormalization: Boolean,
    volumeEnhancement: Int,
    customPresets: List<EqualizerPreset> = emptyList(),
    onDeleteCustomPreset: (EqualizerPreset) -> Unit = {},
    onPresetSelected: (EqualizerPreset) -> Unit, onBandChanged: (Int, Float) -> Unit,
    onSurroundModeChanged: (SurroundMode) -> Unit, onBassChanged: (Int) -> Unit,
    onNightModeChanged: (Boolean) -> Unit, onDialogEnhanceChanged: (Boolean) -> Unit,
    onVolumeNormalizationChanged: (Boolean) -> Unit, onVolumeEnhancementChanged: (Int) -> Unit,
    onSaveCustomPreset: () -> Unit,
    globalEqEnabled: Boolean, onGlobalEqChanged: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(CinemaBlack.copy(0.98f))) {
        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 80.dp)) {
            item {
                // FIX (swipe down to close): dedicated drag handle zone at
                // the very top of the panel. Kept separate from the
                // LazyColumn's own scroll gesture — only this header Row
                // listens for the downward drag, so scrolling the EQ list
                // below still works normally.
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(CinemaGray.copy(alpha = 0.5f))
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .pointerInput(Unit) {
                                var accDy = 0f
                                detectDragGestures(
                                    onDragStart = { accDy = 0f },
                                    onDragEnd = {
                                        if (accDy > 50f) onDismiss()
                                        accDy = 0f
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        accDy += dragAmount.y
                                    }
                                )
                            },
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🎛️ CINEMA PRO DSP", color = CinemaGold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null, tint = Color.White) }
                    }
                }
            }
            item {
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    ToggleOption("🌐 Apply to other apps (when supported)", globalEqEnabled, onGlobalEqChanged)
                    Text(
                        "Works inside Cinema Pro always. For other apps, only those that share their audio session (most music players) will pick it up — YouTube and most video apps don't support this on Android.",
                        color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            item {
                Text("EQ PRESETS", color = CinemaGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .height(320.dp + if (customPresets.isNotEmpty()) 90.dp else 0.dp)
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(EqualizerPreset.ALL_PRESETS) { preset ->
                        EqualizerPresetButton(presetName = preset.name, isSelected = currentPreset.id == preset.id,
                            onClick = { onPresetSelected(preset) }, modifier = Modifier.fillMaxWidth(),
                            isStudioPreset = preset.isPremium)
                    }
                    // FIX: these are the presets that were being saved to
                    // the database correctly all along but never shown
                    // anywhere. Long-press to delete a custom one — held
                    // separate from the long-press-free built-in presets
                    // above since built-ins can't be deleted.
                    items(customPresets) { preset ->
                        // FIX (CI compile failure): combinedClickable()
                        // requires @OptIn(ExperimentalFoundationApi) and
                        // that annotation was tripping up Kotlin's
                        // resolution in this build (compiler rejected the
                        // @OptIn itself with "can only be used as an
                        // annotation" — points at a wildcard-import
                        // ambiguity for this Compose Foundation version).
                        // Rather than fight an experimental-API import
                        // issue, this does the same tap-vs-long-press
                        // detection by hand with a plain pointerInput +
                        // detectTapGestures, which needs no experimental
                        // opt-in at all and is already proven to compile
                        // elsewhere in this file.
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .pointerInput(preset.id) {
                                    detectTapGestures(
                                        onTap = { onPresetSelected(preset) },
                                        onLongPress = { onDeleteCustomPreset(preset) }
                                    )
                                }
                                .background(if (currentPreset.id == preset.id) CinemaGold else CinemaSurfaceLight)
                                .padding(vertical = 10.dp, horizontal = 6.dp)
                        ) {
                            Text(
                                "⭐ ${preset.name}",
                                color = if (currentPreset.id == preset.id) Color.Black else Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                if (customPresets.isNotEmpty()) {
                    Text(
                        "Long-press a ⭐ preset to delete it.",
                        color = CinemaGray, fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                Button(onClick = onSaveCustomPreset,
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGreen),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save Custom Preset", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
            item { CinemaEqualizer(bands = customBands.toList(), onBandChanged = onBandChanged, isPlaying = true) }
            item {
                Text("SURROUND SOUND", color = CinemaGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                SurroundMode.values().forEach { mode ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSurroundModeChanged(mode) }.padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(mode.label, color = if (surroundMode == mode) CinemaGold else Color.White, fontSize = 16.sp)
                            Text(mode.description, color = CinemaGray, fontSize = 12.sp)
                        }
                        if (surroundMode == mode) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                }
            }
            item { BassControlSlider(value = bassLevel, onValueChange = onBassChanged, modifier = Modifier.padding(vertical = 8.dp)) }
            item {
                // FIX: this slider previously didn't exist at all — see
                // onVolumeEnhancementChanged doc for why "Volume
                // Enhancement" had zero effect no matter what.
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("VOLUME ENHANCEMENT", color = CinemaGray, fontSize = 12.sp)
                        Text("$volumeEnhancement%", color = CinemaGold, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = volumeEnhancement.toFloat(),
                        onValueChange = { onVolumeEnhancementChanged(it.toInt()) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = CinemaGold,
                            activeTrackColor = CinemaGold,
                            inactiveTrackColor = CinemaSurfaceLight
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Boosts perceived loudness beyond 100% system volume — useful for quiet recordings.",
                        color = CinemaGray, fontSize = 11.sp
                    )
                }
            }
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    ToggleOption("🌙 Night Mode", nightMode, onNightModeChanged)
                    Spacer(Modifier.height(12.dp))
                    ToggleOption("🎙️ Dialog Enhancement", dialogEnhance, onDialogEnhanceChanged)
                    Spacer(Modifier.height(12.dp))
                    ToggleOption("📊 Volume Normalization", volumeNormalization, onVolumeNormalizationChanged)
                }
            }
        }
    }
}

@Composable
fun ToggleOption(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 16.sp)
        Switch(checked = checked, onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = CinemaGold, checkedTrackColor = CinemaGold.copy(0.4f)))
    }
}

// ── System helpers ────────────────────────────────

fun getSystemVolume(context: Context): Float {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
    return am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toFloat() /
            am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
}

fun setSystemVolume(context: Context, level: Float) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
    val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (level * max).toInt(), 0)
}

fun getScreenBrightness(context: Context): Float {
    return try {
        Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (e: Exception) { 0.5f }
}

fun setScreenBrightness(context: Context, level: Float) {
    val activity = context as? Activity ?: return
    val lp = activity.window.attributes
    lp.screenBrightness = level.coerceIn(0.01f, 1f)
    activity.window.attributes = lp
}

private fun formatTime(ms: Long): String {
    val s = (ms / 1000) % 60; val m = (ms / 60000) % 60; val h = ms / 3600000
    return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
