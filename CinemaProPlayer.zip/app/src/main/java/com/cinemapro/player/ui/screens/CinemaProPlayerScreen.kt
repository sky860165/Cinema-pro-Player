package com.cinemapro.player.ui.screens

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.pm.ActivityInfo
import android.os.Build
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.ErrorMessageProvider
import androidx.media3.common.PlaybackException
import com.cinemapro.player.R
import com.cinemapro.player.audio.CinemaDSPEngine
import com.cinemapro.player.ai.UpscaleGlEffect
import com.cinemapro.player.ai.Stereo3DGlEffect
import com.cinemapro.player.data.database.CinemaProDatabase
import com.cinemapro.player.data.database.VideoHistoryEntity
import com.cinemapro.player.data.model.*
import com.cinemapro.player.ui.components.*
import com.cinemapro.player.ui.theme.*
import kotlinx.coroutines.*
import kotlin.math.*

@OptIn(UnstableApi::class)
@Composable
fun CinemaProPlayerScreen(
    videoUri: String,
    videoTitle: String = "",
    videoId: Long = -1L,
    onBackPressed: () -> Unit,
    onEnterPip: (() -> Unit)? = null,
    onPipChanged: ((callback: (Boolean) -> Unit) -> Unit)? = null
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    // ── Player core states ──────────────────────────
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var bufferedPosition by remember { mutableLongStateOf(0L) }
    var isLoading by remember { mutableStateOf(true) }
    var playerError by remember { mutableStateOf<String?>(null) }
    var showControls by remember { mutableStateOf(true) }
    var isLooping by remember { mutableStateOf(false) }
    var isPipMode by remember { mutableStateOf(false) }
    var isOrientationLocked by remember { mutableStateOf(false) }
    var isTheatreMode by remember { mutableStateOf(false) }
    var aspectRatioMode by remember { mutableStateOf(AspectRatioMode.FIT) }
    var audioSessionIdState by remember { mutableIntStateOf(0) }

    // Pinch-to-zoom scale (2-finger gesture)
    var videoScale by remember { mutableFloatStateOf(1f) }
    var showScaleHint by remember { mutableStateOf(false) }

    // ── Quality / AI / 3D ──────────────────────────
    var currentQuality by remember { mutableStateOf(VideoQuality.AUTO) }
    var currentUpscale by remember { mutableStateOf(UpscaleMode.OFF) }
    var current3DMode by remember { mutableStateOf(VideoMode3D.OFF) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }

    // ── Gesture states ──────────────────────────────
    var volumeLevel by remember { mutableFloatStateOf(getSystemVolume(context)) }
    var brightnessLevel by remember { mutableFloatStateOf(getScreenBrightness(context)) }
    var showVolumeHint by remember { mutableStateOf(false) }
    var showBrightnessHint by remember { mutableStateOf(false) }
    var volumeHintToken by remember { mutableIntStateOf(0) }
    var brightnessHintToken by remember { mutableIntStateOf(0) }
    var showSeekHint by remember { mutableStateOf(false) }
    var seekHintText by remember { mutableStateOf("") }
    var isDragging by remember { mutableStateOf(false) }
    var dragStartPosition by remember { mutableLongStateOf(0L) }

    // ── Audio / DSP ─────────────────────────────────
    var currentPreset by remember { mutableStateOf(EqualizerPreset.FLAT) }
    var customBands by remember { mutableStateOf(FloatArray(15) { 0f }) }
    var surroundMode by remember { mutableStateOf(SurroundMode.AUTO) }
    var bassLevel by remember { mutableIntStateOf(50) }
    var nightMode by remember { mutableStateOf(false) }
    var dialogEnhance by remember { mutableStateOf(false) }
    var volumeNormalization by remember { mutableStateOf(true) }
    var showCustomSaveDialog by remember { mutableStateOf(false) }
    var customPresetName by remember { mutableStateOf("") }
    var globalEqEnabled by remember { mutableStateOf(com.cinemapro.player.service.GlobalEqualizerService.isEnabled(context)) }

    // ── Panel visibility ────────────────────────────
    var showEqualizer by remember { mutableStateOf(false) }
    var showAudioTracks by remember { mutableStateOf(false) }
    var showSubtitleTracks by remember { mutableStateOf(false) }
    var showQualitySelector by remember { mutableStateOf(false) }
    var showSpeedSelector by remember { mutableStateOf(false) }
    var show3DSelector by remember { mutableStateOf(false) }
    var showUpscaleSelector by remember { mutableStateOf(false) }
    var showTheatreSelector by remember { mutableStateOf(false) }

    // ── Tracks ──────────────────────────────────────
    var audioTracks by remember { mutableStateOf<List<AudioTrack>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<SubtitleTrack>>(emptyList()) }
    var currentSubtitle by remember { mutableStateOf<SubtitleTrack?>(null) }

    // ── DB for resume ───────────────────────────────
    val db = remember { CinemaProDatabase.getInstance(context) }

    // ── DSP Engine ──────────────────────────────────
    val dspEngine = remember { CinemaDSPEngine(context) }

    // ── ExoPlayer ───────────────────────────────────
    val trackSelector = remember {
        DefaultTrackSelector(context).apply {
            setParameters(buildUponParameters()
                .setMaxVideoSize(7680, 4320)
                .setMaxVideoBitrate(100_000_000))
        }
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context)
            .setTrackSelector(trackSelector)
            .build()
            .apply {
                setMediaItem(MediaItem.fromUri(videoUri))
                // Video effects (AI upscale / 3D shader) must be set BEFORE
                // prepare() / first frame render. Setting them later, after
                // the MediaCodec decoder has already started in normal
                // (non-effects) surface mode, is what causes the
                // "MediaCodecVideoRenderer error ... video/raw ...
                // NO_UNSUPPORTED_TYPE" crash — the decoder can't switch
                // output surface type mid-stream on most devices.
                setVideoEffects(emptyList())
                prepare()
                playWhenReady = true
            }
    }

    // Tracks whether effects have ever been turned on for this player
    // instance — once a real (non-empty) effect list has been applied we
    // know the decoder is already running in "effects" surface mode, so
    // later changes (switching AI_4K -> AI_8K, or 3D SBS -> TAB) are safe.
    // The unsafe transition is OFF -> any effect after the stream is
    // already playing in plain surface mode, which is why we force a
    // restart in that case below.
    var effectsEverEnabled by remember { mutableStateOf(false) }

    // ── Resume position ──────────────────────────────
    LaunchedEffect(Unit) {
        if (videoId > 0) {
            val history = withContext(Dispatchers.IO) { db.videoHistoryDao().getVideoHistory(videoId) }
            val lastPos = history?.lastPosition ?: 0L
            if (lastPos > 5000L) {
                exoPlayer.seekTo(lastPos)
            }
        }
    }

    // ── DSP init ─────────────────────────────────────
    LaunchedEffect(audioSessionIdState) {
        if (audioSessionIdState != 0) {
            dspEngine.initialize(audioSessionIdState)
            dspEngine.applyEqualizerPreset(currentPreset)
            dspEngine.setSurroundMode(surroundMode)
            dspEngine.setBassLevel(bassLevel)
        }
    }

    // ── Real-time video effects (AI upscale shader + 3D SBS/TAB) ──────
    // Rebuilds the GL effect chain on ExoPlayer whenever the upscale mode
    // or 3D mode changes. Effects run, in order, on every decoded frame on
    // the GPU before it's drawn to the surface. Upscale sharpening is
    // applied first, then the 3D stereo split (so the sharpening sees the
    // original frame, not an already-split one).
    //
    // IMPORTANT: switching the effect list while a MediaCodec decoder is
    // already running causes "MediaCodecVideoRenderer error ... video/raw
    // ... NO_UNSUPPORTED_TYPE" on many devices, because the decoder can't
    // change its output surface mode mid-stream. The fix is to reload the
    // media item (same URI, same position) so the renderer is re-created
    // from scratch with the new effect list already attached, instead of
    // trying to swap effects on a live renderer.
    LaunchedEffect(currentUpscale, current3DMode) {
        val effects = mutableListOf<androidx.media3.common.Effect>()
        if (currentUpscale != UpscaleMode.OFF) {
            effects.add(UpscaleGlEffect(currentUpscale))
        }
        if (current3DMode == VideoMode3D.SBS || current3DMode == VideoMode3D.TAB ||
            current3DMode == VideoMode3D.ANAGLYPH || current3DMode == VideoMode3D.STEREOSCOPIC) {
            effects.add(Stereo3DGlEffect(current3DMode))
        }

        val wantsEffects = effects.isNotEmpty()
        if (wantsEffects == effectsEverEnabled && !wantsEffects) {
            // Nothing to do: effects off and have always been off.
            return@LaunchedEffect
        }

        val resumePosition = exoPlayer.currentPosition
        val wasPlaying = exoPlayer.isPlaying
        // IMPORTANT: Player.stop() in media3 1.2.1 defaults to reset=false,
        // which keeps the existing MediaCodecVideoRenderer/decoder instance
        // alive and just reuses it — this is exactly what was causing
        // "MediaCodecVideoRenderer error ... video/raw ... NO_UNSUPPORTED_TYPE",
        // because the already-running decoder can't switch its output
        // surface mode (plain surface <-> VideoFrameProcessor/effects
        // surface) mid-stream on most devices.
        //
        // clearMediaItems() fully tears down the renderer chain. Effects
        // must be (re-)applied AFTER the new media item is set and BEFORE
        // prepare() — calling setVideoEffects() before clearMediaItems()
        // (the previous bug here) gets wiped out by the reset, so the
        // player ends up preparing with an empty effect list every time,
        // which is why every non-2D mode failed identically.
        exoPlayer.clearMediaItems()
        exoPlayer.setMediaItem(MediaItem.fromUri(videoUri), resumePosition)
        exoPlayer.setVideoEffects(effects)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = wasPlaying
        effectsEverEnabled = wantsEffects
    }

    // ── Progress loop ─────────────────────────────────
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPosition = exoPlayer.currentPosition
            bufferedPosition = exoPlayer.bufferedPosition
            duration = exoPlayer.duration.coerceAtLeast(0)
            isLoading = exoPlayer.isLoading && !exoPlayer.isPlaying

            // Save resume position every 5s
            if (videoId > 0 && currentPosition > 0) {
                withContext(Dispatchers.IO) {
                    db.videoHistoryDao().insertOrUpdate(
                        VideoHistoryEntity(
                            videoId = videoId,
                            title = videoTitle,
                            uri = videoUri,
                            duration = duration,
                            lastPosition = currentPosition
                        )
                    )
                }
            }
            delay(500)
        }
    }

    // ── Auto-hide controls ───────────────────────────
    LaunchedEffect(showControls, isPlaying, isDragging) {
        if (showControls && isPlaying && !isDragging) {
            delay(4000)
            showControls = false
        }
    }

    // ── Track extraction ─────────────────────────────
    LaunchedEffect(exoPlayer.currentTracks) {
        val tracks = exoPlayer.currentTracks
        val audioList = mutableListOf<AudioTrack>()
        val subList = mutableListOf<SubtitleTrack>()
        for (group in tracks.groups) {
            for (i in 0 until group.length) {
                val fmt = group.getTrackFormat(i)
                when {
                    fmt.sampleMimeType?.startsWith("audio") == true ->
                        audioList.add(AudioTrack("${group.mediaTrackGroup.id}_$i", fmt.language ?: "und",
                            fmt.label ?: "Track ${audioList.size + 1}", isSelected = group.isTrackSelected(i)))
                    fmt.sampleMimeType?.let { it.contains("text") || it.contains("subtitle") } == true ->
                        subList.add(SubtitleTrack("${group.mediaTrackGroup.id}_$i", fmt.language ?: "und",
                            fmt.label ?: "Sub ${subList.size + 1}"))
                }
            }
        }
        audioTracks = audioList
        subtitleTracks = subList
    }

    // ── Player listener ──────────────────────────────
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isLoading = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) duration = exoPlayer.duration.coerceAtLeast(0)
            }
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlayerError(error: PlaybackException) {
                // The top-level message alone (e.g. "video/raw ...
                // NO_UNSUPPORTED_TYPE") is just a generic wrapper that
                // media3 throws for several different underlying failures
                // in the effects/VideoFrameProcessor pipeline — the real
                // cause is nested inside error.cause (often several levels
                // deep: VideoSinkException -> VideoFrameProcessingException
                // -> actual root cause). Walk the full chain and show it on
                // screen so we don't need logcat/adb to diagnose this.
                val sb = StringBuilder()
                sb.append(error.javaClass.simpleName).append(": ").append(error.message).append('\n')
                var cause: Throwable? = error.cause
                var depth = 0
                while (cause != null && depth < 8) {
                    sb.append("Caused by: ")
                        .append(cause.javaClass.name)
                        .append(": ")
                        .append(cause.message ?: "(no message)")
                        .append('\n')
                    // Include the first couple of stack frames of the
                    // deepest cause — that's usually the actual file/line
                    // where things went wrong.
                    if (cause.cause == null) {
                        cause.stackTrace.take(4).forEach { frame ->
                            sb.append("    at ").append(frame.toString()).append('\n')
                        }
                    }
                    cause = cause.cause
                    depth++
                }
                playerError = sb.toString().trim()
            }
            override fun onAudioSessionIdChanged(sessionId: Int) { audioSessionIdState = sessionId }
        }
        exoPlayer.addListener(listener)
        // Session id may already be assigned by the time we attach the listener
        audioSessionIdState = exoPlayer.audioSessionId
        onDispose { exoPlayer.removeListener(listener) }
    }

    // ── PIP callback registration ────────────────────
    // Registered via LaunchedEffect(Unit) BEFORE the lifecycle observer below
    // is added, so isPipMode is already wired up by the time ON_PAUSE can fire.
    LaunchedEffect(Unit) {
        onPipChanged?.invoke { inPip -> isPipMode = inPip }
    }

    // ── Lifecycle ────────────────────────────────────
    // NOTE: Entering PiP delivers ON_PAUSE *before* onPictureInPictureModeChanged
    // tells us isPipMode = true (that callback can arrive a frame or two late).
    // Reading isPipMode at that instant is unreliable, so we ask the Activity
    // directly via isInPictureInPictureMode as the source of truth, falling
    // back to the isPipMode flag for the (rare) case the activity reference
    // isn't available.
    DisposableEffect(lifecycleOwner) {
        val activity = context as? android.app.Activity
        val obs = LifecycleEventObserver { _, event ->
            val inPip = (activity?.isInPictureInPictureMode == true) || isPipMode
            when (event) {
                Lifecycle.Event.ON_PAUSE -> if (!inPip) exoPlayer.pause()
                Lifecycle.Event.ON_RESUME -> if (!inPip) exoPlayer.play()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // ── BackHandler ──────────────────────────────────
    BackHandler {
        when {
            showEqualizer -> showEqualizer = false
            showAudioTracks -> showAudioTracks = false
            showSubtitleTracks -> showSubtitleTracks = false
            showQualitySelector -> showQualitySelector = false
            showSpeedSelector -> showSpeedSelector = false
            show3DSelector -> show3DSelector = false
            showUpscaleSelector -> showUpscaleSelector = false
            else -> {
                // Save position before exit
                if (videoId > 0) {
                    scope.launch(Dispatchers.IO) {
                        db.videoHistoryDao().insertOrUpdate(
                            VideoHistoryEntity(videoId, videoTitle, videoUri, duration, exoPlayer.currentPosition)
                        )
                    }
                }
                onBackPressed()
            }
        }
    }

    // ── Theatre / fullscreen mode ─────────────────────
    LaunchedEffect(isTheatreMode) {
        val activity = context as? Activity ?: return@LaunchedEffect
        if (isTheatreMode) {
            // Theatre = fill screen but keep current orientation (portrait or landscape)
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (!isOrientationLocked) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
            }
        }
    }

    // Hide hint overlays after delay
    LaunchedEffect(volumeHintToken) { if (showVolumeHint) { delay(1500); showVolumeHint = false } }
    LaunchedEffect(brightnessHintToken) { if (showBrightnessHint) { delay(1500); showBrightnessHint = false } }
    LaunchedEffect(showSeekHint) { if (showSeekHint) { delay(800); showSeekHint = false } }
    LaunchedEffect(showScaleHint) { if (showScaleHint) { delay(1200); showScaleHint = false } }

    // ── UI ───────────────────────────────────────────
    Box(modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
    ) {
        // ── VIDEO SURFACE ──────────────────────────────
        AndroidView(
            factory = { ctx ->
                // PlayerView's surface type cannot be changed at runtime via
                // a Kotlin setter (no setSurfaceType() method exists on
                // media3's PlayerView) — it must be set via the XML
                // surface_type attribute. We inflate it from a layout that
                // requests texture_view, which is required for the GL
                // video-effects pipeline (AI upscale / 3D shaders) to work;
                // see player_view_texture.xml for details.
                (android.view.LayoutInflater.from(ctx)
                    .inflate(R.layout.player_view_texture, null) as PlayerView)
                    .apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = aspectRatioMode.resizeMode
                        // CRITICAL: PlayerView has its own built-in error
                        // overlay (the exo_error_message TextView baked
                        // into its default layout) that renders
                        // independently of useController and independently
                        // of our Compose playerError state below. By
                        // default it just shows error.toString() — that
                        // plain single-line "MediaCodecVideoRenderer
                        // error, index=0, format=Format(...)" text is
                        // PlayerView's own overlay, NOT the custom Compose
                        // error screen with the full cause chain / Copy
                        // Error button. Returning an empty string here
                        // hides PlayerView's overlay so only our Compose
                        // error UI (which has the real diagnostic info)
                        // is visible.
                        setErrorMessageProvider(
                            ErrorMessageProvider<PlaybackException> { _ ->
                                android.util.Pair(0, "")
                            }
                        )
                    }
            },
            update = { view ->
                view.resizeMode = when {
                    current3DMode != VideoMode3D.OFF -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    isTheatreMode -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    else -> aspectRatioMode.resizeMode
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = videoScale
                    scaleY = videoScale
                }
                // ── GESTURE: Pinch to zoom (2 fingers) ────────────────────
                .pointerInput(Unit) {
                    detectTransformGestures { _, _, zoom, _ ->
                        videoScale = (videoScale * zoom).coerceIn(0.5f, 4f)
                        showScaleHint = true
                    }
                }
                // ── GESTURE: Tap / Double-tap ──────────────
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            showControls = !showControls
                        },
                        onDoubleTap = { offset ->
                            val w = size.width
                            when {
                                offset.x < w / 3 -> {
                                    exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                                    seekHintText = "-10s"
                                }
                                offset.x > w * 2 / 3 -> {
                                    exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(duration))
                                    seekHintText = "+10s"
                                }
                                else -> {
                                    exoPlayer.playWhenReady = !exoPlayer.isPlaying
                                }
                            }
                            showSeekHint = true
                            showControls = true
                        }
                    )
                }
                // ── GESTURE: Swipe – seek / volume / brightness ──
                .pointerInput(Unit) {
                    var gestureType: GestureType? = null
                    var startX = 0f
                    var startY = 0f
                    var accDx = 0f
                    var accDy = 0f

                    detectDragGestures(
                        onDragStart = { offset ->
                            startX = offset.x
                            startY = offset.y
                            accDx = 0f
                            accDy = 0f
                            gestureType = null
                            isDragging = true
                            dragStartPosition = exoPlayer.currentPosition
                            showControls = true
                        },
                        onDragEnd = {
                            isDragging = false
                            gestureType = null
                            showVolumeHint = false
                            showBrightnessHint = false
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            accDx += dragAmount.x
                            accDy += dragAmount.y

                            // Determine gesture type after threshold
                            if (gestureType == null && (abs(accDx) > 20 || abs(accDy) > 20)) {
                                gestureType = when {
                                    abs(accDx) > abs(accDy) -> GestureType.SEEK
                                    startX < size.width / 2 -> GestureType.VOLUME
                                    else -> GestureType.BRIGHTNESS
                                }
                            }

                            when (gestureType) {
                                GestureType.SEEK -> {
                                    val pct = accDx / size.width
                                    val seekMs = (pct * minOf(duration, 120_000L)).toLong()
                                    val newPos = (dragStartPosition + seekMs).coerceIn(0, duration)
                                    exoPlayer.seekTo(newPos)
                                    currentPosition = newPos
                                }
                                GestureType.VOLUME -> {
                                    val delta = -dragAmount.y / size.height
                                    volumeLevel = (volumeLevel + delta * 2).coerceIn(0f, 1f)
                                    setSystemVolume(context, volumeLevel)
                                    showVolumeHint = true
                                    volumeHintToken++
                                }
                                GestureType.BRIGHTNESS -> {
                                    val delta = -dragAmount.y / size.height
                                    brightnessLevel = (brightnessLevel + delta * 2).coerceIn(0.01f, 1f)
                                    setScreenBrightness(context, brightnessLevel)
                                    showBrightnessHint = true
                                    brightnessHintToken++
                                }
                                null -> {}
                            }
                        }
                    )
                }
        )

        // ── 3D MODE OVERLAY ────────────────────────────
        if (current3DMode != VideoMode3D.OFF) {
            ThreeDModeOverlay(mode = current3DMode)
        }

        // ── Theatre mode dim bars ──────────────────────
        if (isTheatreMode) {
            Box(modifier = Modifier.fillMaxWidth().height(56.dp).align(Alignment.TopCenter).background(Color.Black))
            Box(modifier = Modifier.fillMaxWidth().height(56.dp).align(Alignment.BottomCenter).background(Color.Black))
        }

        // ── LOADING ────────────────────────────────────
        if (isLoading && !isPipMode) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CinemaGold, strokeWidth = 3.dp, modifier = Modifier.size(60.dp))
            }
        }

        // ── ERROR ──────────────────────────────────────
        playerError?.let { err ->
            val clipboardManager = LocalClipboardManager.current
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.92f)), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .padding(32.dp)
                        .fillMaxHeight(0.85f)
                ) {
                    Icon(Icons.Default.ErrorOutline, null, tint = CinemaRed, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Playback Error", color = CinemaRed, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Box(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .padding(vertical = 12.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            err,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = { clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(err)) },
                            colors = ButtonDefaults.buttonColors(containerColor = CinemaBlue)
                        ) {
                            Text("Copy Error", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(onClick = { playerError = null; exoPlayer.prepare() }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                            Text("Retry", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // ── HINT OVERLAYS ──────────────────────────────
        // Volume hint
        AnimatedVisibility(visible = showVolumeHint, modifier = Modifier.align(Alignment.CenterStart).padding(start = 24.dp)) {
            HintPill(icon = if (volumeLevel > 0) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                label = "${(volumeLevel * 100).toInt()}%", color = CinemaBlue)
        }

        // Brightness hint
        AnimatedVisibility(visible = showBrightnessHint, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 24.dp)) {
            HintPill(icon = Icons.Default.Brightness6,
                label = "${(brightnessLevel * 100).toInt()}%", color = CinemaGold)
        }

        // Seek hint
        AnimatedVisibility(visible = showSeekHint, modifier = Modifier.align(Alignment.Center)) {
            Box(modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(0.75f)).padding(16.dp, 12.dp)) {
                Text(seekHintText, color = CinemaGold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Scale hint (pinch to zoom)
        AnimatedVisibility(visible = showScaleHint, modifier = Modifier.align(Alignment.Center)) {
            Row(modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(0.75f)).padding(16.dp, 12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.ZoomIn, null, tint = CinemaGold, modifier = Modifier.size(24.dp))
                Text("${"%.1f".format(videoScale)}x", color = CinemaGold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                // Reset button
                if (videoScale != 1f) {
                    Spacer(Modifier.width(4.dp))
                    TextButton(onClick = { videoScale = 1f }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                        Text("Reset", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // ── AI / 3D / MODE BADGES ─────────────────────
        Row(modifier = Modifier.align(Alignment.TopEnd).padding(top = 92.dp, end = 44.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (currentUpscale != UpscaleMode.OFF) {
                Badge(text = when (currentUpscale) {
                    UpscaleMode.AI_4K -> "AI 4K"
                    UpscaleMode.AI_8K -> "AI 8K"
                    UpscaleMode.SUPER_RESOLUTION -> "AI SR"
                    UpscaleMode.SHARPEN -> "SHARP"
                    UpscaleMode.DENOISE -> "DENOISE"
                    UpscaleMode.HDR_SIMULATION -> "HDR"
                    else -> ""
                }, color = CinemaGreen)
            }
            if (current3DMode != VideoMode3D.OFF) {
                Badge(text = "3D ${current3DMode.label}", color = CinemaBlue)
            }
            if (isTheatreMode) {
                Badge(text = "THEATRE", color = CinemaPurple)
            }
        }

        // Speed badge
        if (currentSpeed != 1.0f) {
            Badge(
                text = "${currentSpeed}x",
                color = CinemaPurple,
                modifier = Modifier.align(Alignment.TopStart).padding(top = 52.dp, start = 12.dp)
            )
        }

        // ── CONTROLS OVERLAY ──────────────────────────
        AnimatedVisibility(
            visible = showControls && !isPipMode,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(300))
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color.Black.copy(0.85f), Color.Transparent, Color.Transparent, Color.Black.copy(0.9f)))
                )
            ) {
                // ── TOP BAR ──────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).padding(top = 40.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        scope.launch(Dispatchers.IO) {
                            if (videoId > 0) db.videoHistoryDao().insertOrUpdate(
                                VideoHistoryEntity(videoId, videoTitle, videoUri, duration, exoPlayer.currentPosition)
                            )
                        }
                        onBackPressed()
                    }) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(28.dp))
                    }

                    Text(videoTitle.ifEmpty { "CINEMA PRO" },
                        color = CinemaGold, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp))

                    Row {
                        // Orientation lock
                        IconButton(onClick = {
                            isOrientationLocked = !isOrientationLocked
                            val activity = context as? Activity
                            if (isOrientationLocked) {
                                val orientation = context.resources.configuration.orientation
                                activity?.requestedOrientation = if (orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE)
                                    ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            } else {
                                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                            }
                        }) {
                            Icon(
                                if (isOrientationLocked) Icons.Default.ScreenLockRotation else Icons.Default.ScreenRotation,
                                "Lock", tint = if (isOrientationLocked) CinemaGold else Color.White
                            )
                        }
                        // Theatre mode
                        IconButton(onClick = { isTheatreMode = !isTheatreMode }) {
                            Icon(Icons.Default.Theaters, "Theatre", tint = if (isTheatreMode) CinemaPurple else Color.White)
                        }
                        // PIP
                        IconButton(onClick = { onEnterPip?.invoke() }) {
                            Icon(Icons.Default.PictureInPicture, "PIP", tint = Color.White)
                        }
                    }
                }

                // ── CENTER CONTROLS ───────────────────────
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0)) },
                            modifier = Modifier.size(56.dp)) {
                            Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                        FloatingActionButton(
                            onClick = { if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play() },
                            containerColor = CinemaGold, modifier = Modifier.size(80.dp), shape = CircleShape
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                null, tint = Color.Black, modifier = Modifier.size(48.dp)
                            )
                        }
                        IconButton(onClick = { exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(duration)) },
                            modifier = Modifier.size(56.dp)) {
                            Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(38.dp))
                        }
                    }
                }

                // ── BOTTOM CONTROLS ───────────────────────
                Column(modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 12.dp).padding(bottom = 20.dp)) {
                    // Seek bar
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Buffer
                        Slider(value = bufferedPosition.toFloat(), onValueChange = {},
                            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(thumbColor = Color.Transparent, activeTrackColor = Color.White.copy(0.25f), inactiveTrackColor = Color.Transparent),
                            modifier = Modifier.fillMaxWidth())
                        // Progress
                        Slider(value = currentPosition.toFloat(),
                            onValueChange = { exoPlayer.seekTo(it.toLong()); currentPosition = it.toLong() },
                            valueRange = 0f..duration.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(thumbColor = CinemaGold, activeTrackColor = CinemaGold, inactiveTrackColor = Color.Gray.copy(0.35f)),
                            modifier = Modifier.fillMaxWidth())
                    }

                    // Time + buttons
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("${formatTime(currentPosition)} / ${formatTime(duration)}",
                            color = Color.White, fontSize = 13.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SmallIconButton(Icons.Default.Repeat, "Loop", isLooping, CinemaGold) {
                                isLooping = !isLooping
                                exoPlayer.repeatMode = if (isLooping) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                            }
                            SmallIconButton(Icons.Default.Audiotrack, "Audio", false, Color.White) { showAudioTracks = true }
                            SmallIconButton(Icons.Default.Subtitles, "Sub", currentSubtitle != null, CinemaGold) { showSubtitleTracks = true }
                        }
                    }

                    Spacer(Modifier.height(4.dp))

                    // Feature row
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FeatureChip(currentQuality.label, CinemaBlue) { showQualitySelector = true }
                        FeatureChip("${currentSpeed}x", Color.White) { showSpeedSelector = true }
                        FeatureChip(if (current3DMode == VideoMode3D.OFF) "2D" else "3D", if (current3DMode != VideoMode3D.OFF) CinemaBlue else Color.White) { show3DSelector = true }
                        FeatureChip(if (currentUpscale == UpscaleMode.OFF) "AI" else "AI✓", if (currentUpscale != UpscaleMode.OFF) CinemaGreen else Color.White) { showUpscaleSelector = true }
                        FeatureChip(if (isTheatreMode) "🎭" else "Theatre", if (isTheatreMode) CinemaPurple else Color.White) { isTheatreMode = !isTheatreMode }
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = {
                            isTheatreMode = !isTheatreMode
                            val activity = context as? Activity
                            if (!isTheatreMode) {
                                activity?.requestedOrientation = if (isOrientationLocked) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR
                            }
                        }) {
                            Icon(Icons.Default.Fullscreen, null, tint = Color.White)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // EQ + Aspect Ratio row — bigger, easier-to-tap targets away from screen corners
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showEqualizer = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentPreset != EqualizerPreset.FLAT) CinemaGold else CinemaSurface
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Equalizer, null,
                                tint = if (currentPreset != EqualizerPreset.FLAT) Color.Black else Color.White,
                                modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Equalizer", fontSize = 13.sp,
                                color = if (currentPreset != EqualizerPreset.FLAT) Color.Black else Color.White)
                        }
                        Button(
                            onClick = { aspectRatioMode = aspectRatioMode.next() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (aspectRatioMode != AspectRatioMode.FIT) CinemaBlue else CinemaSurface
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.AspectRatio, null,
                                tint = if (aspectRatioMode != AspectRatioMode.FIT) Color.Black else Color.White,
                                modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(aspectRatioMode.label, fontSize = 13.sp,
                                color = if (aspectRatioMode != AspectRatioMode.FIT) Color.Black else Color.White)
                        }
                    }
                }
            }
        }

        // ── DIALOGS ───────────────────────────────────
        if (showAudioTracks) {
            TrackSelectorDialog("Audio Tracks", audioTracks.map { it.label },
                audioTracks.indexOfFirst { it.isSelected },
                { showAudioTracks = false }, { showAudioTracks = false })
        }
        if (showSubtitleTracks) {
            TrackSelectorDialog("Subtitles", listOf("Off") + subtitleTracks.map { it.label },
                if (currentSubtitle == null) 0 else subtitleTracks.indexOf(currentSubtitle) + 1,
                { idx -> currentSubtitle = if (idx == 0) null else subtitleTracks.getOrNull(idx - 1); showSubtitleTracks = false },
                { showSubtitleTracks = false })
        }
        if (showQualitySelector) {
            TrackSelectorDialog("Video Quality", VideoQuality.values().map { it.label },
                VideoQuality.values().indexOf(currentQuality),
                { idx -> currentQuality = VideoQuality.values()[idx]; showQualitySelector = false },
                { showQualitySelector = false })
        }
        if (showSpeedSelector) {
            val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f)
            TrackSelectorDialog("Playback Speed", speeds.map { "${it}x" },
                speeds.indexOf(currentSpeed),
                { idx -> currentSpeed = speeds[idx]; exoPlayer.setPlaybackSpeed(currentSpeed); showSpeedSelector = false },
                { showSpeedSelector = false })
        }
        if (show3DSelector) {
            ThreeDModeDialog(current3DMode, { mode -> current3DMode = mode; show3DSelector = false }, { show3DSelector = false })
        }
        if (showUpscaleSelector) {
            AIUpscaleDialog(currentUpscale, { mode -> currentUpscale = mode; showUpscaleSelector = false }, { showUpscaleSelector = false })
        }

        // ── EQUALIZER PANEL ───────────────────────────
        AnimatedVisibility(visible = showEqualizer, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            EqualizerPanel(
                currentPreset = currentPreset, customBands = customBands,
                surroundMode = surroundMode, bassLevel = bassLevel,
                nightMode = nightMode, dialogEnhance = dialogEnhance, volumeNormalization = volumeNormalization,
                onPresetSelected = { preset ->
                    currentPreset = preset; customBands = preset.bands.copyOf()
                    dspEngine.applyEqualizerPreset(preset)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, preset = preset)
                },
                onBandChanged = { i, v ->
                    val newBands = customBands.copyOf(); newBands[i] = v; customBands = newBands
                    currentPreset = EqualizerPreset("custom", "Custom", newBands)
                    dspEngine.applyEqualizerPreset(currentPreset)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, preset = currentPreset)
                },
                onSurroundModeChanged = {
                    surroundMode = it; dspEngine.setSurroundMode(it)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, surroundMode = it)
                },
                onBassChanged = {
                    bassLevel = it; dspEngine.setBassLevel(it)
                    com.cinemapro.player.service.GlobalEqualizerService.saveState(context, globalEqEnabled, bassLevel = it)
                },
                onNightModeChanged = { nightMode = it; dspEngine.setNightMode(it) },
                onDialogEnhanceChanged = { dialogEnhance = it; dspEngine.setDialogEnhancement(it) },
                onVolumeNormalizationChanged = { volumeNormalization = it; dspEngine.setVolumeNormalization(it) },
                onSaveCustomPreset = { showCustomSaveDialog = true },
                globalEqEnabled = globalEqEnabled,
                onGlobalEqChanged = { enabled ->
                    globalEqEnabled = enabled
                    val svcIntent = android.content.Intent(context, com.cinemapro.player.service.GlobalEqualizerService::class.java)
                    if (enabled) {
                        com.cinemapro.player.service.GlobalEqualizerService.saveState(context, true, currentPreset, surroundMode, bassLevel)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            context.startForegroundService(svcIntent)
                        } else {
                            context.startService(svcIntent)
                        }
                    } else {
                        svcIntent.action = com.cinemapro.player.service.GlobalEqualizerService.ACTION_STOP
                        context.startService(svcIntent)
                    }
                },
                onDismiss = { showEqualizer = false }
            )
        }

        // Save Preset Dialog
        if (showCustomSaveDialog) {
            AlertDialog(
                onDismissRequest = { showCustomSaveDialog = false },
                title = { Text("Save Custom Preset", color = Color.White) },
                text = {
                    OutlinedTextField(value = customPresetName, onValueChange = { customPresetName = it },
                        label = { Text("Preset Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CinemaSurface, unfocusedContainerColor = CinemaSurface,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = CinemaGold, unfocusedBorderColor = CinemaSurfaceLight
                        ))
                },
                confirmButton = {
                    Button(onClick = {
                        if (customPresetName.isNotEmpty()) {
                            val newPreset = EqualizerPreset("custom_${System.currentTimeMillis()}", customPresetName, customBands.copyOf(), isBuiltIn = false)
                            scope.launch(Dispatchers.IO) {
                                db.equalizerPresetDao().insertPreset(newPreset.toEntity())
                            }
                        }
                        showCustomSaveDialog = false; customPresetName = ""
                    }, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                        Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = { TextButton(onClick = { showCustomSaveDialog = false }) { Text("Cancel", color = CinemaGray) } },
                containerColor = CinemaSurface
            )
        }
    }

    // Cleanup
    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
            dspEngine.release()
        }
    }
}

// ── Gesture type ──────────────────────────────────
private enum class GestureType { SEEK, VOLUME, BRIGHTNESS }

// ── Aspect ratio / display ratio mode ─────────────
private enum class AspectRatioMode(val label: String, val resizeMode: Int) {
    FIT("Fit", AspectRatioFrameLayout.RESIZE_MODE_FIT),
    FILL("Fill", AspectRatioFrameLayout.RESIZE_MODE_FILL),
    ZOOM("Zoom", AspectRatioFrameLayout.RESIZE_MODE_ZOOM),
    STRETCH_WIDTH("Stretch W", AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH),
    STRETCH_HEIGHT("Stretch H", AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT);

    fun next(): AspectRatioMode = values()[(ordinal + 1) % values().size]
}

// ── 3D Mode Overlay ───────────────────────────────
@Composable
fun ThreeDModeOverlay(mode: VideoMode3D) {
    when (mode) {
        VideoMode3D.VR_360, VideoMode3D.VR_180 -> {
            // VR mode indicator — VR sphere rendering isn't implemented yet,
            // this border is just a visual placeholder for the "coming soon" state.
            Box(modifier = Modifier.fillMaxSize().border(3.dp, CinemaBlue.copy(0.5f)))
        }
        else -> {}
        // ANAGLYPH is now handled by a real GPU shader (AnaglyphGlShaderProgram)
        // that does actual red/cyan channel separation on the decoded frame —
        // no UI overlay needed or wanted here, it would just double the effect.
    }
}

// ── AI Upscale Dialog ─────────────────────────────
@Composable
fun AIUpscaleDialog(current: UpscaleMode, onSelect: (UpscaleMode) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🤖 AI Video Upscale", color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(UpscaleMode.values().toList()) { mode ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSelect(mode) }.padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(mode.label, color = if (mode == current) CinemaGold else Color.White, fontSize = 16.sp)
                            Text(when (mode) {
                                UpscaleMode.OFF -> "Native resolution"
                                UpscaleMode.SHARPEN -> "Real-time edge-aware sharpening (GPU)"
                                UpscaleMode.DENOISE -> "Real-time edge-preserving noise reduction (GPU)"
                                UpscaleMode.HDR_SIMULATION -> "Real-time HDR tone mapping (GPU)"
                                UpscaleMode.AI_4K -> "Real-time GPU upscale + sharpen, 4K tier"
                                UpscaleMode.AI_8K -> "Real-time GPU upscale + sharpen, 8K tier (stronger)"
                                UpscaleMode.SUPER_RESOLUTION -> "Real-time GPU detail enhancement"
                            }, color = CinemaGray, fontSize = 12.sp)
                        }
                        if (mode == current) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (mode != UpscaleMode.values().last()) HorizontalDivider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

// ── 3D Mode Dialog ────────────────────────────────
@Composable
fun ThreeDModeDialog(current: VideoMode3D, onSelect: (VideoMode3D) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("📽️ 3D Video Mode", color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(VideoMode3D.values().toList()) { mode ->
                    val isImplemented = mode != VideoMode3D.VR_360 && mode != VideoMode3D.VR_180
                    Row(modifier = Modifier.fillMaxWidth()
                        .clickable(enabled = isImplemented) { onSelect(mode) }
                        .padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(mode.label, color = when {
                                !isImplemented -> CinemaGray.copy(alpha = 0.5f)
                                mode == current -> CinemaGold
                                else -> Color.White
                            }, fontSize = 16.sp)
                            Text(when (mode) {
                                VideoMode3D.OFF -> "Normal 2D playback"
                                VideoMode3D.SBS -> "Side-by-Side 3D — real GPU stereo split"
                                VideoMode3D.TAB -> "Top-and-Bottom 3D — real GPU stereo split"
                                VideoMode3D.ANAGLYPH -> "Red-Cyan 3D glasses — real channel separation (GPU)"
                                VideoMode3D.VR_360 -> "Coming soon — needs sphere renderer"
                                VideoMode3D.VR_180 -> "Coming soon — needs sphere renderer"
                                VideoMode3D.STEREOSCOPIC -> "Dual-view 3D — real GPU stereo split"
                            }, color = if (isImplemented) CinemaGray else CinemaGray.copy(alpha = 0.4f), fontSize = 12.sp)
                        }
                        if (mode == current) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (mode != VideoMode3D.values().last()) HorizontalDivider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

// ── Reusable UI atoms ─────────────────────────────

@Composable
fun HintPill(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color) {
    Column(
        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Color.Black.copy(0.8f)).padding(14.dp, 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Badge(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.clip(RoundedCornerShape(6.dp)).background(color.copy(0.9f)).padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(text, color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun SmallIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, active: Boolean, activeColor: Color, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(icon, desc, tint = if (active) activeColor else Color.White, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun FeatureChip(label: String, color: Color, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun TrackSelectorDialog(title: String, tracks: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = CinemaGold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn {
                items(tracks.size) { i ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 13.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(tracks[i], color = if (i == selectedIndex) CinemaGold else Color.White, fontSize = 16.sp)
                        if (i == selectedIndex) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                    if (i < tracks.size - 1) HorizontalDivider(color = CinemaSurfaceLight, thickness = 0.5.dp)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close", color = CinemaGray) } },
        containerColor = CinemaSurface
    )
}

@Composable
fun EqualizerPanel(
    currentPreset: EqualizerPreset, customBands: FloatArray, surroundMode: SurroundMode,
    bassLevel: Int, nightMode: Boolean, dialogEnhance: Boolean, volumeNormalization: Boolean,
    onPresetSelected: (EqualizerPreset) -> Unit, onBandChanged: (Int, Float) -> Unit,
    onSurroundModeChanged: (SurroundMode) -> Unit, onBassChanged: (Int) -> Unit,
    onNightModeChanged: (Boolean) -> Unit, onDialogEnhanceChanged: (Boolean) -> Unit,
    onVolumeNormalizationChanged: (Boolean) -> Unit, onSaveCustomPreset: () -> Unit,
    globalEqEnabled: Boolean, onGlobalEqChanged: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(CinemaBlack.copy(0.98f))) {
        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 80.dp)) {
            item {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("🎛️ CINEMA PRO DSP", color = CinemaGold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null, tint = Color.White) }
                }
            }
            item {
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    ToggleOption("🌐 Apply to other apps (when supported)", globalEqEnabled, onGlobalEqChanged)
                    Text(
                        "Works inside Cinema Pro always. For other apps, only those that share their audio session (most music players) will pick it up — YouTube and most video apps don't support this on Android.",
                        color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
            item {
                Text("EQ PRESETS", color = CinemaGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.height(320.dp).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(EqualizerPreset.ALL_PRESETS) { preset ->
                        EqualizerPresetButton(presetName = preset.name, isSelected = currentPreset.id == preset.id,
                            onClick = { onPresetSelected(preset) }, modifier = Modifier.fillMaxWidth())
                    }
                }
                Button(onClick = onSaveCustomPreset,
                    colors = ButtonDefaults.buttonColors(containerColor = CinemaGreen),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Save Custom Preset", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
            item { CinemaEqualizer(bands = customBands.toList(), onBandChanged = onBandChanged, isPlaying = true) }
            item {
                Text("SURROUND SOUND", color = CinemaGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                SurroundMode.values().forEach { mode ->
                    Row(modifier = Modifier.fillMaxWidth().clickable { onSurroundModeChanged(mode) }.padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(mode.label, color = if (surroundMode == mode) CinemaGold else Color.White, fontSize = 16.sp)
                            Text(mode.description, color = CinemaGray, fontSize = 12.sp)
                        }
                        if (surroundMode == mode) Icon(Icons.Default.Check, null, tint = CinemaGold)
                    }
                }
            }
            item { BassControlSlider(value = bassLevel, onValueChange = onBassChanged, modifier = Modifier.padding(vertical = 8.dp)) }
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    ToggleOption("🌙 Night Mode", nightMode, onNightModeChanged)
                    Spacer(Modifier.height(12.dp))
                    ToggleOption("🎙️ Dialog Enhancement", dialogEnhance, onDialogEnhanceChanged)
                    Spacer(Modifier.height(12.dp))
                    ToggleOption("📊 Volume Normalization", volumeNormalization, onVolumeNormalizationChanged)
                }
            }
        }
    }
}

@Composable
fun ToggleOption(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 16.sp)
        Switch(checked = checked, onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = CinemaGold, checkedTrackColor = CinemaGold.copy(0.4f)))
    }
}

// ── System helpers ────────────────────────────────

fun getSystemVolume(context: Context): Float {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
    return am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toFloat() /
            am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
}

fun setSystemVolume(context: Context, level: Float) {
    val am = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
    val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (level * max).toInt(), 0)
}

fun getScreenBrightness(context: Context): Float {
    return try {
        Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (e: Exception) { 0.5f }
}

fun setScreenBrightness(context: Context, level: Float) {
    val activity = context as? Activity ?: return
    val lp = activity.window.attributes
    lp.screenBrightness = level.coerceIn(0.01f, 1f)
    activity.window.attributes = lp
}

private fun formatTime(ms: Long): String {
    val s = (ms / 1000) % 60; val m = (ms / 60000) % 60; val h = ms / 3600000
    return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}
