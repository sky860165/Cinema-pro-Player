package com.cinemapro.player.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log

/**
 * Resolves an incoming content:// URI (from "Open with", a file manager,
 * etc.) into a URI that's safe to reopen multiple times — which effects
 * mode (AI 4K upscale / 3D) requires when it reloads the media item.
 *
 * We deliberately do NOT rely on takePersistableUriPermission() to decide
 * whether the grant is durable. On several OEM file managers (observed on
 * MIUI in particular) that call returns successfully — no SecurityException
 * — but the permission is NOT actually honored on a later re-open; the
 * second open still throws FileNotFoundException deep inside the
 * VideoFrameProcessor pipeline. Trusting the "success" there was the bug:
 * it made the resolver skip the cache-copy fallback for exactly the
 * providers that needed it most.
 *
 * So instead: always copy the file into our own app storage once (subject
 * to a disk-space safety check), and always play from that local file://
 * path.
 *
 * IMPORTANT: this copy lives under Context.filesDir, NOT Context.cacheDir.
 * cacheDir is explicitly documented as something the OS may delete at any
 * time — including mid-session — whenever the device is low on storage,
 * with zero notice to the app. That's exactly what happened in production
 * here: the file was copied successfully and played for a while, then the
 * OS reclaimed cacheDir space out from under the still-open player, and
 * the effects-mode reload's re-open of that same path threw
 * FileNotFoundException/ENOENT. filesDir is never touched by automatic OS
 * cleanup — only explicit app code (our own cleanup below) removes files
 * there, so a file we just copied is guaranteed to still exist for the
 * rest of this playback session.
 */
object PlaybackUriResolver {

    private const val TAG = "PlaybackUriResolver"
    private const val CACHE_SUBDIR = "playback_cache"
    // Require this much free space beyond the file's own size before we
    // attempt a copy, so the copy itself can never be the thing that
    // pushes the device into SQLITE_FULL / disk-full territory.
    private const val SAFETY_MARGIN_BYTES = 200L * 1024 * 1024 // 200MB

    fun resolve(context: Context, uri: Uri?): Uri? {
        if (uri == null) return null
        if (uri.scheme != "content") return uri

        // Still attempt to persist the grant — harmless if it's a no-op,
        // and it means playback keeps working even in the brief window
        // before the copy exists, or if the copy itself fails.
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: SecurityException) {
            // Expected for many providers — not an error.
        }

        return copyToLocalStorageIfSafe(context, uri) ?: uri
    }

    private fun copyToLocalStorageIfSafe(context: Context, uri: Uri): Uri? {
        // filesDir, not cacheDir — see class doc above for why.
        val storageSubDir = java.io.File(context.filesDir, CACHE_SUBDIR).apply { mkdirs() }

        // Always clean up old copies from previous sessions first — they're
        // only ever needed for the single session that copied them, so
        // nothing from a previous run should still be sitting here taking
        // up permanent storage.
        cleanupOldCacheFiles(storageSubDir)

        val sourceSize = try {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length }
        } catch (e: Exception) {
            null
        } ?: -1L

        val usableSpaceBefore = storageSubDir.usableSpace

        // If we know the size and there's clearly not enough room, don't
        // even start — fall back to the original content:// uri.
        if (sourceSize > 0 && usableSpaceBefore < sourceSize + SAFETY_MARGIN_BYTES) {
            Log.w(TAG, "Skipping cache copy, not enough space: sourceSize=$sourceSize usableSpace=$usableSpaceBefore")
            return null
        }
        // If size couldn't be determined (some providers don't support
        // it), still require a reasonable minimum headroom before trying
        // — better than refusing to copy for providers where size lookup
        // simply isn't supported but the copy itself would work fine.
        if (sourceSize <= 0 && usableSpaceBefore < SAFETY_MARGIN_BYTES) {
            Log.w(TAG, "Skipping cache copy, low space and unknown source size: usableSpace=$usableSpaceBefore")
            return null
        }

        return try {
            val fileName = "playback_" + System.currentTimeMillis() + ".mp4"
            val outFile = java.io.File(storageSubDir, fileName)
            var bytesCopied = 0L
            var aborted = false
            context.contentResolver.openInputStream(uri)?.use { input ->
                outFile.outputStream().use { output ->
                    val buffer = ByteArray(1 shl 20)
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        bytesCopied += read
                        // Safety check every ~64MB written: if free space
                        // is running out mid-copy (e.g. size lookup wasn't
                        // available upfront), abort rather than filling
                        // the disk.
                        if (bytesCopied % (64L * 1024 * 1024) < (1 shl 20) &&
                            storageSubDir.usableSpace < SAFETY_MARGIN_BYTES / 2
                        ) {
                            aborted = true
                            break
                        }
                    }
                }
            }
            if (aborted) {
                outFile.delete()
                Log.w(TAG, "Aborted cache copy mid-way, running low on space")
                null
            } else if (outFile.exists() && outFile.length() > 0) {
                Uri.fromFile(outFile)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Cache copy failed", e)
            null
        }
    }

    private fun cleanupOldCacheFiles(storageSubDir: java.io.File) {
        try {
            storageSubDir.listFiles()?.forEach { it.delete() }
        } catch (e: Exception) {
            // Non-fatal — worst case a stale file lingers until the next
            // successful cleanup pass.
        }
    }
}
