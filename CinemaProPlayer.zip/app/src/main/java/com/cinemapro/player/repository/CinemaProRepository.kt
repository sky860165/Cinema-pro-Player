package com.cinemapro.player.repository

import android.content.Context
import android.provider.MediaStore
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.cinemapro.player.data.database.*
import com.cinemapro.player.data.model.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "cinema_pro_settings")

class CinemaProRepository(
    private val context: Context,
    private val database: CinemaProDatabase
) {
    private val gson = Gson()
    private val presetDao = database.equalizerPresetDao()
    private val settingsDao = database.appSettingsDao()
    private val historyDao = database.videoHistoryDao()
    private val playlistDao = database.playlistDao()

    // ===================== VIDEO LIBRARY =====================

    suspend fun getVideoLibrary(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.RESOLUTION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATA
        )

        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            projection,
            null,
            null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
            val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val resolutionColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.RESOLUTION)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                val uri = android.net.Uri.withAppendedPath(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    id.toString()
                )

                videos.add(
                    VideoItem(
                        id = id,
                        title = cursor.getString(titleColumn) ?: "Unknown",
                        uri = uri,
                        duration = cursor.getLong(durationColumn),
                        resolution = cursor.getString(resolutionColumn) ?: "Unknown",
                        fileSize = cursor.getLong(sizeColumn),
                        dateAdded = cursor.getLong(dateColumn),
                        folderPath = cursor.getString(dataColumn)?.substringBeforeLast("/") ?: ""
                    )
                )
            }
        }
        videos
    }

    suspend fun searchVideos(query: String): List<VideoItem> {
        return getVideoLibrary().filter {
            it.title.contains(query, ignoreCase = true)
        }
    }

    // ===================== EQUALIZER PRESETS =====================

    fun getAllPresets(): Flow<List<EqualizerPreset>> {
        return presetDao.getAllPresets().map { entities ->
            val builtIn = EqualizerPreset.ALL_PRESETS
            val custom = entities.filter { !it.isBuiltIn }.map { it.toPreset() }
            builtIn + custom
        }
    }

    fun getCustomPresets(): Flow<List<EqualizerPreset>> {
        return presetDao.getCustomPresets().map { entities ->
            entities.map { it.toPreset() }
        }
    }

    suspend fun saveCustomPreset(preset: EqualizerPreset) {
        presetDao.insertPreset(preset.toEntity())
    }

    suspend fun deleteCustomPreset(preset: EqualizerPreset) {
        presetDao.deletePreset(preset.toEntity())
    }

    // ===================== APP SETTINGS =====================

    fun getSettings(): Flow<AppSettings> {
        return settingsDao.getSettings().catch {
            emit(AppSettings())
        }
    }

    suspend fun updateSettings(settings: AppSettings) {
        settingsDao.insertSettings(settings)
    }

    // ===================== VIDEO HISTORY =====================

    fun getRecentVideos(): Flow<List<VideoHistoryEntity>> {
        return historyDao.getRecentVideos()
    }

    suspend fun saveVideoHistory(video: VideoItem, position: Long) {
        historyDao.insertOrUpdate(
            VideoHistoryEntity(
                videoId = video.id,
                title = video.title,
                uri = video.uri.toString(),
                duration = video.duration,
                lastPosition = position,
                thumbnailPath = video.thumbnailPath
            )
        )
    }

    suspend fun getLastPosition(videoId: Long): Long {
        return historyDao.getVideoHistory(videoId)?.lastPosition ?: 0
    }

    suspend fun clearHistory() {
        historyDao.clearAllHistory()
    }

    // ===================== PLAYLISTS =====================

    fun getAllPlaylists(): Flow<List<PlaylistEntity>> {
        return playlistDao.getAllPlaylists()
    }

    suspend fun createPlaylist(name: String, description: String = ""): Long {
        return playlistDao.insertPlaylist(
            PlaylistEntity(name = name, description = description)
        )
    }

    suspend fun addVideoToPlaylist(playlistId: Long, videoId: Long) {
        playlistDao.getPlaylistById(playlistId)?.let { playlist ->
            val videoIds = gson.fromJson<List<Long>>(playlist.videoIds, object : TypeToken<List<Long>>() {}.type) ?: emptyList()
            val updatedIds = videoIds + videoId
            playlistDao.updatePlaylist(
                playlist.copy(
                    videoIds = gson.toJson(updatedIds),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun deletePlaylist(playlist: PlaylistEntity) {
        playlistDao.deletePlaylist(playlist)
    }

    // ===================== DATASTORE =====================

    suspend fun saveLastUsedPreset(presetId: String) {
        context.dataStore.edit { preferences ->
            preferences[stringPreferencesKey("last_preset")] = presetId
        }
    }

    fun getLastUsedPreset(): Flow<String?> {
        return context.dataStore.data.map { preferences ->
            preferences[stringPreferencesKey("last_preset")]
        }
    }
}
