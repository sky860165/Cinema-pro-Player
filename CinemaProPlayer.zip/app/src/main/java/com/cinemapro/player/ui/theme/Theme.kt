package com.cinemapro.player.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Cinema Pro Color Palette
val CinemaGold = Color(0xFFFFD700)
val CinemaGoldDark = Color(0xFFB8860B)
val CinemaBlue = Color(0xFF00B0FF)
val CinemaGreen = Color(0xFF00E676)
val CinemaRed = Color(0xFFFF1744)
val CinemaPurple = Color(0xFFE040FB)
val CinemaOrange = Color(0xFFFF6D00)
val CinemaCyan = Color(0xFF00E5FF)
val CinemaPink = Color(0xFFFF4081)

val CinemaBlack = Color(0xFF000000)
val CinemaDark = Color(0xFF0A0A0A)
val CinemaSurface = Color(0xFF1A1A1A)
val CinemaSurfaceLight = Color(0xFF2A2A2A)
val CinemaSurfaceLighter = Color(0xFF3A3A3A)
val CinemaGray = Color(0xFF9E9E9E)
val CinemaGrayDark = Color(0xFF616161)
val CinemaWhite = Color(0xFFFFFFFF)

private val CinemaProColorScheme = darkColorScheme(
    primary = CinemaGold,
    onPrimary = CinemaBlack,
    primaryContainer = CinemaGoldDark,
    onPrimaryContainer = CinemaWhite,
    secondary = CinemaBlue,
    onSecondary = CinemaBlack,
    secondaryContainer = Color(0xFF01579B),
    onSecondaryContainer = CinemaWhite,
    tertiary = CinemaGreen,
    onTertiary = CinemaBlack,
    tertiaryContainer = Color(0xFF1B5E20),
    onTertiaryContainer = CinemaWhite,
    error = CinemaRed,
    onError = CinemaWhite,
    errorContainer = Color(0xFFB71C1C),
    onErrorContainer = CinemaWhite,
    background = CinemaBlack,
    onBackground = CinemaWhite,
    surface = CinemaSurface,
    onSurface = CinemaWhite,
    surfaceVariant = CinemaSurfaceLight,
    onSurfaceVariant = CinemaGray,
    outline = CinemaGrayDark,
    inverseOnSurface = CinemaBlack,
    inverseSurface = CinemaWhite,
    inversePrimary = CinemaGoldDark,
    surfaceTint = CinemaGold,
    outlineVariant = CinemaGrayDark,
    scrim = Color.Black.copy(alpha = 0.8f)
)

@Composable
fun CinemaProTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> CinemaProColorScheme
        else -> CinemaProColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = CinemaProTypography,
        content = content
    )
}
