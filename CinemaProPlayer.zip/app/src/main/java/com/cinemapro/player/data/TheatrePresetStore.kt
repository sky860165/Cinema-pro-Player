package com.cinemapro.player.data

import android.content.Context
import com.cinemapro.player.data.model.CinemaAudioConfig
import com.cinemapro.player.data.model.DynamicRangeMode
import com.cinemapro.player.data.model.SurroundMode
import com.cinemapro.player.data.model.TheatreRoomSize
import org.json.JSONObject

/**
 * Saves/loads full Theatre Mode configurations (room size, X-Curve, THX
 * Re-EQ, LFE, crossover, height/center/front/surround trims, dynamic
 * range mode, loudness target — every CinemaAudioConfig field) under a
 * user-given name, the same idea as the EQ preset picker but for the
 * whole theatre-experience config at once.
 *
 * Kept as simple SharedPreferences + JSON rather than a new Room table —
 * this is a small, infrequently-written list (a handful of named theatre
 * setups per person), so a full DB migration wasn't worth the added
 * surface area.
 */
object TheatrePresetStore {
    private const val PREFS_NAME = "cinema_theatre_presets"
    private const val KEY_NAMES = "preset_names"

    fun listNames(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_NAMES, null) ?: return emptyList()
        return try {
            val arr = org.json.JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(context: Context, name: String, config: CinemaAudioConfig) {
        if (name.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = JSONObject().apply {
            put("surroundMode", config.surroundMode.name)
            put("bassLevel", config.bassLevel)
            put("dialogEnhancement", config.dialogEnhancement)
            put("volumeNormalization", config.volumeNormalization)
            put("volumeEnhancement", config.volumeEnhancement)
            put("loudnessTarget", config.loudnessTarget)
            put("theatreRoomSize", config.theatreRoomSize.name)
            put("xCurveEnabled", config.xCurveEnabled)
            put("xCurveIntensity", config.xCurveIntensity)
            put("thxReEqEnabled", config.thxReEqEnabled)
            put("lfeLevel", config.lfeLevel)
            put("bassCrossoverHz", config.bassCrossoverHz)
            put("heightChannelLevel", config.heightChannelLevel)
            put("centerChannelLevel", config.centerChannelLevel)
            put("dynamicRangeMode", config.dynamicRangeMode.name)
            put("frontTrimDb", config.frontTrimDb)
            put("centerTrimDb", config.centerTrimDb)
            put("surroundTrimDb", config.surroundTrimDb)
            put("extremeBassMode", config.extremeBassMode)
            put("extremeLoudnessMode", config.extremeLoudnessMode)
            put("hapticBassSyncEnabled", config.hapticBassSyncEnabled)
            put("hapticBassSyncIntensity", config.hapticBassSyncIntensity)
        }
        val names = listNames(context).toMutableList()
        if (!names.contains(name)) names.add(name)
        prefs.edit()
            .putString(KEY_NAMES, org.json.JSONArray(names).toString())
            .putString("preset_$name", json.toString())
            .apply()
    }

    fun load(context: Context, name: String): CinemaAudioConfig? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString("preset_$name", null) ?: return null
        return try {
            val j = JSONObject(raw)
            CinemaAudioConfig(
                surroundMode = SurroundMode.valueOf(j.optString("surroundMode", SurroundMode.AUTO.name)),
                bassLevel = j.optInt("bassLevel", 50),
                dialogEnhancement = j.optBoolean("dialogEnhancement", false),
                volumeNormalization = j.optBoolean("volumeNormalization", true),
                volumeEnhancement = j.optInt("volumeEnhancement", 0),
                loudnessTarget = j.optInt("loudnessTarget", -14),
                theatreRoomSize = TheatreRoomSize.valueOf(j.optString("theatreRoomSize", TheatreRoomSize.STANDARD_MULTIPLEX.name)),
                xCurveEnabled = j.optBoolean("xCurveEnabled", false),
                xCurveIntensity = j.optInt("xCurveIntensity", 50),
                thxReEqEnabled = j.optBoolean("thxReEqEnabled", false),
                lfeLevel = j.optInt("lfeLevel", 0),
                bassCrossoverHz = j.optInt("bassCrossoverHz", 80),
                heightChannelLevel = j.optInt("heightChannelLevel", 50),
                centerChannelLevel = j.optInt("centerChannelLevel", 50),
                dynamicRangeMode = DynamicRangeMode.valueOf(j.optString("dynamicRangeMode", DynamicRangeMode.CINEMA_FULL.name)),
                frontTrimDb = j.optInt("frontTrimDb", 0),
                centerTrimDb = j.optInt("centerTrimDb", 0),
                surroundTrimDb = j.optInt("surroundTrimDb", 0),
                extremeBassMode = j.optBoolean("extremeBassMode", false),
                extremeLoudnessMode = j.optBoolean("extremeLoudnessMode", false),
                hapticBassSyncEnabled = j.optBoolean("hapticBassSyncEnabled", false),
                hapticBassSyncIntensity = j.optInt("hapticBassSyncIntensity", 60)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun delete(context: Context, name: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val names = listNames(context).toMutableList()
        names.remove(name)
        prefs.edit()
            .putString(KEY_NAMES, org.json.JSONArray(names).toString())
            .remove("preset_$name")
            .apply()
    }
}
