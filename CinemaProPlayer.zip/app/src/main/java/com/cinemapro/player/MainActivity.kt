package com.cinemapro.player

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.cinemapro.player.ui.screens.VideoGalleryScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Resume the global equalizer service if the user had it on before
        // (e.g. after the app process was killed by the system).
        if (com.cinemapro.player.service.GlobalEqualizerService.isEnabled(this)) {
            val svcIntent = android.content.Intent(this, com.cinemapro.player.service.GlobalEqualizerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
        }

        // If launched from file manager with a video URI, go directly to player
        //
        // IMPORTANT: external apps (Files, Gallery, browser, etc.) grant us a
        // one-shot read permission on the content:// URI via the launching
        // Intent. Plain ExoPlayer playback only opens that URI once, so the
        // one-shot grant is enough. But enabling AI 4K upscale or 3D mode
        // forces CinemaProPlayerScreen to clearMediaItems() + re-open the
        // SAME uri (required to recreate the decoder in "effects" surface
        // mode — see the LaunchedEffect(currentUpscale, current3DMode) doc
        // comment in CinemaProPlayerScreen.kt). That second open can land
        // after the one-shot grant has already been consumed/revoked,
        // producing a FileNotFoundException deep inside the
        // VideoFrameProcessor pipeline (surfaces as "Playback Error /
        // VideoSinkException: FileNotFoundException").
        //
        // takePersistableUriPermission() is tried first, but NOT all
        // providers support a persistable/prefix grant — many file-manager
        // apps only ever hand out a one-shot FLAG_GRANT_READ_URI_PERMISSION
        // that throws SecurityException here. For those, persisting is
        // simply not possible, so as a guaranteed fallback we stream-copy
        // the file into our own app cache once and play from that local
        // file:// path instead. A local file we own can be reopened as many
        // times as needed (effects on/off, mode switches, etc.) with no
        // permission model involved at all.
        var resolvedVideoUri = intent?.data
        resolvedVideoUri?.let { uri ->
            if (uri.scheme == "content") {
                var persisted = false
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                    persisted = true
                } catch (e: SecurityException) {
                    persisted = false
                }

                if (!persisted) {
                    try {
                        val fileName = "playback_" + System.currentTimeMillis() + ".mp4"
                        val outFile = java.io.File(cacheDir, fileName)
                        contentResolver.openInputStream(uri)?.use { input ->
                            outFile.outputStream().use { output ->
                                input.copyTo(output, bufferSize = 1 shl 20)
                            }
                        }
                        if (outFile.exists() && outFile.length() > 0) {
                            resolvedVideoUri = android.net.Uri.fromFile(outFile)
                        }
                        // else: copy failed silently, fall through and try
                        // the original content:// uri — plain 2D playback
                        // will still work off the intent's one-shot grant,
                        // only effects-mode reload risks failing for this
                        // specific file.
                    } catch (e: Exception) {
                        // Copy failed (e.g. very large file, low storage,
                        // I/O error) — fall back to the original uri so at
                        // least normal 2D playback still has a chance.
                    }
                }
            }
        }
        val videoUri = resolvedVideoUri?.toString()

        setContent {
            CinemaProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (videoUri != null) {
                        // Direct play from external intent
                        com.cinemapro.player.ui.screens.CinemaProPlayerScreen(
                            videoUri = videoUri,
                            videoTitle = videoUri.substringAfterLast("/"),
                            onBackPressed = { finish() }
                        )
                    } else {
                        // Show video gallery/browser
                        VideoGalleryScreen(
                            onVideoSelected = { video ->
                                // Navigate to player with selected video
                                val intent = android.content.Intent(this, PlayerActivity::class.java).apply {
                                    data = video.uri
                                    putExtra("VIDEO_TITLE", video.title)
                                    putExtra("VIDEO_ID", video.id)
                                }
                                startActivity(intent)
                            }
                        )
                    }
                }
            }
        }
    }
}
