package com.cinemapro.player

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.cinemapro.player.ui.screens.VideoGalleryScreen
import com.cinemapro.player.ui.theme.CinemaProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Resume the global equalizer service if the user had it on before
        // (e.g. after the app process was killed by the system).
        if (com.cinemapro.player.service.GlobalEqualizerService.isEnabled(this)) {
            val svcIntent = android.content.Intent(this, com.cinemapro.player.service.GlobalEqualizerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
        }

        // If launched from file manager with a video URI, go directly to player
        val initialVideoUri = intent?.data?.toString()

        setContent {
            CinemaProTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // FIX ("movie play hote rehta hai, back button dabane
                    // se app sidha exit ho jata h"): opening a video file
                    // directly from a file manager/another app (this
                    // Activity's VIEW intent-filter in the manifest)
                    // launches MainActivity itself straight into the
                    // player with no other screen behind it in the task's
                    // back stack. onBackPressed used to just call
                    // finish() unconditionally, so pressing back here
                    // closed the WHOLE app immediately instead of
                    // returning to something — there was nowhere else to
                    // "go back" to inside the app at all. This now tracks
                    // whether we're still showing that direct-open video
                    // as local state: the FIRST back press drops it and
                    // reveals the gallery (a real in-app screen to land
                    // on), and only a SECOND back press (with nothing
                    // left to show) exits — the normal, expected Android
                    // back behavior instead of an instant exit.
                    var directVideoUri by remember { mutableStateOf(initialVideoUri) }
                    if (directVideoUri != null) {
                        com.cinemapro.player.ui.screens.CinemaProPlayerScreen(
                            videoUri = directVideoUri!!,
                            videoTitle = directVideoUri!!.substringAfterLast("/"),
                            onBackPressed = { directVideoUri = null }
                        )
                    } else {
                        // Show video gallery/browser
                        VideoGalleryScreen(
                            onVideoSelected = { video ->
                                // Navigate to player with selected video
                                val intent = android.content.Intent(this, PlayerActivity::class.java).apply {
                                    data = video.uri
                                    putExtra("VIDEO_TITLE", video.title)
                                    putExtra("VIDEO_ID", video.id)
                                }
                                startActivity(intent)
                            }
                        )
                    }
                }
            }
        }
    }
}
