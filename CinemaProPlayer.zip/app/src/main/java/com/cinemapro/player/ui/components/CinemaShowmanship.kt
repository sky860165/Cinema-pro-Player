package com.cinemapro.player.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemapro.player.ui.theme.CinemaGold
import com.cinemapro.player.ui.theme.CinemaGray
import com.cinemapro.player.ui.theme.CinemaSurface
import kotlinx.coroutines.delay

// ===================== "FEATURE PRESENTATION" INTRO =====================
// A real cinema-hall opener: dim title card → classic film-leader
// countdown (3-2-1) → red curtains parting to reveal the movie, which is
// already playing underneath the whole time (same as a real theatre,
// where the projector is already rolling before the curtain finishes
// opening). Purely a Compose overlay — never touches playback state, so
// it can't desync or interfere with actual video playback/seeking.
@Composable
fun CinemaIntroOverlay(
    movieTitle: String,
    onFinished: () -> Unit
) {
    var phase by remember { mutableIntStateOf(0) } // 0=title, 1..3=countdown, 4=curtain-open
    LaunchedEffect(Unit) {
        phase = 0; delay(900)
        phase = 1; delay(500)
        phase = 2; delay(500)
        phase = 3; delay(500)
        phase = 4; delay(900)
        onFinished()
    }

    val curtainProgress by animateFloatAsState(
        targetValue = if (phase >= 4) 1f else 0f,
        animationSpec = tween(850, easing = FastOutSlowInEasing),
        label = "curtain_open"
    )

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = phase < 4,
            exit = fadeOut(tween(300)),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Crossfade(targetState = phase, label = "intro_phase") { p ->
                    when (p) {
                        0 -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "🎬 FEATURE PRESENTATION", color = CinemaGold,
                                fontSize = 22.sp, fontWeight = FontWeight.Bold
                            )
                            if (movieTitle.isNotBlank()) {
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    movieTitle, color = Color.White, fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        in 1..3 -> FilmCountdownNumber(number = 4 - p)
                        else -> {}
                    }
                }
            }
        }

        if (phase >= 4) {
            CinemaCurtains(openProgress = curtainProgress)
        }
    }
}

@Composable
private fun FilmCountdownNumber(number: Int) {
    val infinite = rememberInfiniteTransition(label = "countdown_ring")
    val sweep by infinite.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(500, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(140.dp)) {
        Canvas(modifier = Modifier.size(140.dp)) {
            drawArc(
                color = CinemaGold.copy(alpha = 0.25f),
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                style = Stroke(width = 6.dp.toPx())
            )
            drawArc(
                color = CinemaGold,
                startAngle = -90f, sweepAngle = -sweep, useCenter = false,
                style = Stroke(width = 6.dp.toPx())
            )
        }
        Text("$number", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CinemaCurtains(openProgress: Float) {
    val curtainColor = Brush.verticalGradient(
        listOf(Color(0xFF8B0000), Color(0xFF4A0000), Color(0xFF2A0000))
    )
    Box(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.5f * (1f - openProgress))
                .align(Alignment.CenterStart)
                .background(curtainColor)
        )
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.5f * (1f - openProgress))
                .align(Alignment.CenterEnd)
                .background(curtainColor)
        )
    }
}

// ===================== END-CREDITS CURTAIN CLOSE =====================
// Mirror of the intro — curtains close back in when the video reaches
// STATE_ENDED, with a simple "Thanks for watching" card and two actions.
@Composable
fun CinemaOutroOverlay(
    onPlayAgain: () -> Unit,
    onBackToGallery: () -> Unit
) {
    var closeProgress by remember { mutableFloatStateOf(0f) }
    val animatedClose by animateFloatAsState(
        targetValue = closeProgress, animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "curtain_close"
    )
    LaunchedEffect(Unit) { closeProgress = 1f }

    Box(modifier = Modifier.fillMaxSize()) {
        CinemaCurtains(openProgress = 1f - animatedClose)
        AnimatedVisibility(
            visible = animatedClose > 0.85f,
            enter = fadeIn(tween(400)),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🎬 THE END", color = CinemaGold, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Thanks for watching", color = Color.White, fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onPlayAgain, colors = ButtonDefaults.buttonColors(containerColor = CinemaGold)) {
                        Text("Play Again", color = Color.Black)
                    }
                    OutlinedButton(
                        onClick = onBackToGallery,
                        border = BorderStroke(1.dp, CinemaGray)
                    ) {
                        Text("Back to Gallery", color = Color.White)
                    }
                }
            }
        }
    }
}

// ===================== LIVE REACTIONS =====================
// A quick "audience reaction" burst — tap an emoji and a copy of it
// floats up from the bottom and fades out, like a shared watch-party
// reacting together in real time. Purely cosmetic/local (no networking),
// but a genuinely fun touch for a group watching together on one big
// screen and passing the phone/remote around to react.
@Stable
data class FloatingReactionState(val id: Long, val emoji: String, val xFraction: Float)

@Composable
fun ReactionOverlay(reactions: List<FloatingReactionState>, modifier: Modifier = Modifier) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()
        reactions.forEach { r ->
            key(r.id) { FloatingReactionBubble(r, widthPx, heightPx) }
        }
    }
}

@Composable
private fun FloatingReactionBubble(state: FloatingReactionState, containerWidthPx: Float, containerHeightPx: Float) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(state.id) {
        progress.animateTo(1f, animationSpec = tween(2200, easing = LinearOutSlowInEasing))
    }
    val riseFraction = 0.55f // how far up the screen it travels before fading out
    val alpha = (1f - ((progress.value - 0.7f) / 0.3f).coerceIn(0f, 1f))
    val x = (state.xFraction * containerWidthPx).toInt()
    val y = (containerHeightPx - (progress.value * riseFraction * containerHeightPx)).toInt()
    Text(
        state.emoji,
        fontSize = 32.sp,
        modifier = Modifier
            .offset { IntOffset(x, y) }
            .graphicsLayer { this.alpha = alpha }
    )
}

@Composable
fun ReactionPickerRow(onReact: (String) -> Unit, onDismiss: () -> Unit) {
    val emojis = listOf("👏", "🔥", "😂", "❤️", "😱", "🍿")
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(CinemaSurface)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        emojis.forEach { e ->
            Text(
                e, fontSize = 24.sp,
                modifier = Modifier.clickable { onReact(e) }
            )
        }
        Text(
            "✕", color = CinemaGray, fontSize = 18.sp,
            modifier = Modifier.padding(start = 4.dp).clickable { onDismiss() }
        )
    }
}

// ===================== INTERMISSION / POPCORN BREAK =====================
@Composable
fun IntermissionCard(onDismiss: () -> Unit, onSnooze: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CinemaSurface)
            .padding(16.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🍿", fontSize = 22.sp)
                Spacer(Modifier.width(8.dp))
                Text("Intermission — Popcorn Break?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Icon(
                    Icons.Default.Close, contentDescription = "Dismiss", tint = CinemaGray,
                    modifier = Modifier.size(18.dp).clickable(onClick = onDismiss)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "You're halfway through — good time to refill the popcorn bowl.",
                color = CinemaGray, fontSize = 12.sp
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(onClick = onSnooze) { Text("Remind in 10 min", color = CinemaGold) }
                TextButton(onClick = onDismiss) { Text("Dismiss", color = CinemaGray) }
            }
        }
    }
}
