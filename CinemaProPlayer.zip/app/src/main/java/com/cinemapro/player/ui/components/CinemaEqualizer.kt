package com.cinemapro.player.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemapro.player.ui.theme.CinemaGold
import com.cinemapro.player.ui.theme.CinemaSurface
import com.cinemapro.player.ui.theme.CinemaSurfaceLight
import com.cinemapro.player.ui.theme.CinemaGray
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun CinemaEqualizer(
    bands: List<Float>,
    onBandChanged: (Int, Float) -> Unit,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = false
) {
    val frequencies = listOf("32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    val bandColors = listOf(
        Color(0xFFFF1744), // 32Hz - Red
        Color(0xFFFF5722), // 64Hz - Orange Red
        Color(0xFFFF9800), // 125Hz - Orange
        Color(0xFFFFC107), // 250Hz - Amber
        Color(0xFFCDDC39), // 500Hz - Lime
        Color(0xFF8BC34A), // 1KHz - Light Green
        Color(0xFF4CAF50), // 2KHz - Green
        Color(0xFF009688), // 4KHz - Teal
        Color(0xFF00BCD4), // 8KHz - Cyan
        Color(0xFF2196F3), // 16KHz - Blue
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "15-BAND CINEMA EQ",
                style = MaterialTheme.typography.titleMedium,
                color = CinemaGold,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
            if (isPlaying) {
                // Animated equalizer indicator
                EqualizerIndicator()
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Frequency labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            frequencies.forEach { freq ->
                Text(
                    text = freq,
                    color = CinemaGray,
                    fontSize = 10.sp,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Equalizer bars with drag support
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            bands.take(10).forEachIndexed { index, value ->
                var currentValue by remember { mutableFloatStateOf(value) }
                val animatedValue by animateFloatAsState(
                    targetValue = currentValue,
                    animationSpec = spring(stiffness = 300f, dampingRatio = 0.8f),
                    label = "band_$index"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 3.dp)
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val newValue = (currentValue - dragAmount.y / 15).coerceIn(-12f, 12f)
                                currentValue = newValue
                                onBandChanged(index, newValue)
                            }
                        }
                ) {
                    // Background track
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CinemaSurface)
                    )

                    // Center line (0dB)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .align(Alignment.Center)
                            .background(Color.Gray.copy(alpha = 0.3f))
                    )

                    // Active bar
                    val barHeight = ((animatedValue + 12) / 24).coerceIn(0f, 1f)
                    val isPositive = animatedValue >= 0

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(barHeight)
                            .align(if (isPositive) Alignment.BottomCenter else Alignment.TopCenter)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = if (isPositive) {
                                        listOf(
                                            bandColors[index].copy(alpha = 0.2f),
                                            bandColors[index]
                                        )
                                    } else {
                                        listOf(
                                            bandColors[index],
                                            bandColors[index].copy(alpha = 0.2f)
                                        )
                                    }
                                )
                            )
                    )

                    // Value indicator
                    Text(
                        text = "${animatedValue.roundToInt()}dB",
                        color = if (abs(animatedValue) > 6) Color.White else CinemaGray,
                        fontSize = 9.sp,
                        modifier = Modifier.align(
                            if (isPositive) Alignment.TopCenter else Alignment.BottomCenter
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // dB scale
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("+12dB", color = CinemaGray, fontSize = 10.sp)
            Text("0dB", color = CinemaGray, fontSize = 10.sp)
            Text("-12dB", color = CinemaGray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun EqualizerIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "eq_indicator")
    val barHeights = List(5) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.2f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(300 + index * 100, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bar_$index"
        )
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(20.dp)
    ) {
        barHeights.forEach { height ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight(height.value)
                    .clip(RoundedCornerShape(1.dp))
                    .background(CinemaGold)
            )
        }
    }
}

@Composable
fun EqualizerPresetButton(
    presetName: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) CinemaGold else CinemaSurfaceLight,
            contentColor = if (isSelected) Color.Black else Color.White
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = presetName,
            fontSize = 12.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
    }
}

@Composable
fun BassControlSlider(
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("BASS BOOST", color = CinemaGray, fontSize = 12.sp)
            Text("$value%", color = CinemaGold, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = CinemaGold,
                activeTrackColor = CinemaGold,
                inactiveTrackColor = CinemaSurfaceLight
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
