package com.cinemapro.player.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cinemapro.player.ui.theme.CinemaGold
import com.cinemapro.player.ui.theme.CinemaSurface
import com.cinemapro.player.ui.theme.CinemaSurfaceLight
import com.cinemapro.player.ui.theme.CinemaGray
import com.cinemapro.player.data.model.TheatreRoomSize
import com.cinemapro.player.data.model.DynamicRangeMode
import com.cinemapro.player.data.model.BASS_CROSSOVER_OPTIONS
import com.cinemapro.player.data.model.LOUDNESS_TARGET_OPTIONS
import com.cinemapro.player.ui.screens.ToggleOption
import com.cinemapro.player.data.model.CinemaBarsMode
import com.cinemapro.player.ui.screens.ToggleOption
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun CinemaEqualizer(
    bands: List<Float>,
    onBandChanged: (Int, Float) -> Unit,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = false,
    masterBoostDb: Int = 0,
    onMasterBoostChanged: (Int) -> Unit = {},
    audioCleanModeEnabled: Boolean = false,
    onAudioCleanModeChanged: (Boolean) -> Unit = {}
) {
    val frequencies = listOf("32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
    val bandColors = listOf(
        Color(0xFFFF1744), // 32Hz - Red
        Color(0xFFFF5722), // 64Hz - Orange Red
        Color(0xFFFF9800), // 125Hz - Orange
        Color(0xFFFFC107), // 250Hz - Amber
        Color(0xFFCDDC39), // 500Hz - Lime
        Color(0xFF8BC34A), // 1KHz - Light Green
        Color(0xFF4CAF50), // 2KHz - Green
        Color(0xFF009688), // 4KHz - Teal
        Color(0xFF00BCD4), // 8KHz - Cyan
        Color(0xFF2196F3), // 16KHz - Blue
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "15-BAND CINEMA EQ",
                style = MaterialTheme.typography.titleMedium,
                color = CinemaGold,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
            if (isPlaying) {
                // Animated equalizer indicator
                EqualizerIndicator()
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ===== ONE-TAP AUDIO CLEAN BUTTON =====
        // Real DSP behind this, not a cosmetic toggle — see
        // CinemaDSPEngine.setAudioCleanMode(): force-enables the safety
        // limiter, tames the 3-6kHz harsh/sibilance zone, and lowers the
        // loudness gain ceiling, so audio comes out clean and crispy
        // instead of phate hue / crackly, whatever else is dialed up.
        Button(
            onClick = { onAudioCleanModeChanged(!audioCleanModeEnabled) },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (audioCleanModeEnabled) CinemaGold else CinemaSurfaceLight
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (audioCleanModeEnabled) "✨ AUDIO CLEAN: ON — Crisp & Crackle-Free" else "🧼 MAKE AUDIO CLEAN",
                color = if (audioCleanModeEnabled) Color.Black else Color.White,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                fontSize = 13.sp
            )
        }
        Text(
            "One tap: removes crackle/harshness, keeps sound crisp even with Master Boost or Volume Enhancement pushed up.",
            color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Frequency labels
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            frequencies.forEach { freq ->
                Text(
                    text = freq,
                    color = CinemaGray,
                    fontSize = 10.sp,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Equalizer bars with drag support
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            bands.take(10).forEachIndexed { index, value ->
                // FIX: previously `remember { mutableFloatStateOf(value) }`
                // captured `value` only on first composition. Selecting a
                // different preset (or any external band change) updated
                // the `bands` list passed in, but this slider's displayed
                // position never followed — so switching presets looked
                // like "nothing happened" even when the DSP engine had
                // correctly applied the new preset underneath. Keying on
                // (index, value) makes the local drag-state re-sync
                // whenever the source value actually changes externally,
                // while still allowing smooth local dragging in between.
                var currentValue by remember(index, value) { mutableFloatStateOf(value) }
                val animatedValue by animateFloatAsState(
                    targetValue = currentValue,
                    animationSpec = spring(stiffness = 300f, dampingRatio = 0.8f),
                    label = "band_$index"
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 3.dp)
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val newValue = (currentValue - dragAmount.y / 15).coerceIn(-12f, 12f)
                                currentValue = newValue
                                onBandChanged(index, newValue)
                            }
                        }
                ) {
                    // Background track
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CinemaSurface)
                    )

                    // Center line (0dB)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .align(Alignment.Center)
                            .background(Color.Gray.copy(alpha = 0.3f))
                    )

                    // Active bar
                    val barHeight = ((animatedValue + 12) / 24).coerceIn(0f, 1f)
                    val isPositive = animatedValue >= 0

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(barHeight)
                            .align(if (isPositive) Alignment.BottomCenter else Alignment.TopCenter)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = if (isPositive) {
                                        listOf(
                                            bandColors[index].copy(alpha = 0.2f),
                                            bandColors[index]
                                        )
                                    } else {
                                        listOf(
                                            bandColors[index],
                                            bandColors[index].copy(alpha = 0.2f)
                                        )
                                    }
                                )
                            )
                    )

                    // Value indicator
                    Text(
                        text = "${animatedValue.roundToInt()}dB",
                        color = if (abs(animatedValue) > 6) Color.White else CinemaGray,
                        fontSize = 9.sp,
                        modifier = Modifier.align(
                            if (isPositive) Alignment.TopCenter else Alignment.BottomCenter
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // dB scale
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("+12dB", color = CinemaGray, fontSize = 10.sp)
            Text("0dB", color = CinemaGray, fontSize = 10.sp)
            Text("-12dB", color = CinemaGray, fontSize = 10.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Master Boost — one bar that lifts every frequency together.
        // Real DSP behind this: CinemaDSPEngine.setMasterBoost() folds
        // it into every hardware EQ band with a soft clamp (no hard
        // clipping crackle), and the loudness chain automatically backs
        // off to make headroom for it — see eqHeadroomUsedMb().
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "⚡ MASTER BOOST (ALL FREQUENCIES)",
                color = CinemaGold, fontSize = 12.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
            val display = if (masterBoostDb > 0) "+${masterBoostDb}dB" else "${masterBoostDb}dB"
            Text(display, color = CinemaGold, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        Slider(
            value = masterBoostDb.toFloat(),
            onValueChange = { onMasterBoostChanged(it.roundToInt()) },
            valueRange = -10f..20f,
            colors = SliderDefaults.colors(
                thumbColor = CinemaGold,
                activeTrackColor = CinemaGold,
                inactiveTrackColor = CinemaSurfaceLight
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Boosts every band together — clean and crackle-free thanks to the soft clamp + safety limiter.",
            color = CinemaGray, fontSize = 11.sp
        )
    }
}

@Composable
private fun EqualizerIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "eq_indicator")
    val barHeights = List(5) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.2f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(300 + index * 100, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "bar_$index"
        )
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(20.dp)
    ) {
        barHeights.forEach { height ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight(height.value)
                    .clip(RoundedCornerShape(1.dp))
                    .background(CinemaGold)
            )
        }
    }
}

@Composable
fun EqualizerPresetButton(
    presetName: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isStudioPreset: Boolean = false
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) CinemaGold else CinemaSurfaceLight,
            contentColor = if (isSelected) Color.Black else Color.White
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        if (isStudioPreset) {
            Icon(
                Icons.Default.Star,
                contentDescription = "Studio preset",
                tint = if (isSelected) Color.Black else CinemaGold,
                modifier = Modifier.size(13.dp)
            )
            androidx.compose.foundation.layout.Spacer(Modifier.width(4.dp))
        }
        Text(
            text = presetName,
            fontSize = 12.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
    }
}

// ===================== THEATRE / IMAX EXPERIENCE =====================

@Composable
fun TheatreExperienceSection(
    theatreModeEnabled: Boolean,
    onTheatreModeChanged: (Boolean) -> Unit,
    theatreRoomSize: TheatreRoomSize,
    onTheatreRoomSizeChanged: (TheatreRoomSize) -> Unit,
    xCurveEnabled: Boolean,
    onXCurveEnabledChanged: (Boolean) -> Unit,
    xCurveIntensity: Int,
    onXCurveIntensityChanged: (Int) -> Unit,
    thxReEqEnabled: Boolean,
    onThxReEqChanged: (Boolean) -> Unit,
    lfeLevel: Int,
    onLfeLevelChanged: (Int) -> Unit,
    bassCrossoverHz: Int,
    onBassCrossoverChanged: (Int) -> Unit,
    heightChannelLevel: Int,
    onHeightChannelChanged: (Int) -> Unit,
    dialogEnhance: Boolean,
    centerChannelLevel: Int,
    onCenterChannelChanged: (Int) -> Unit,
    frontTrimDb: Int, onFrontTrimChanged: (Int) -> Unit,
    centerTrimDb: Int, onCenterTrimChanged: (Int) -> Unit,
    surroundTrimDb: Int, onSurroundTrimChanged: (Int) -> Unit,
    loudnessTarget: Int, onLoudnessTargetChanged: (Int) -> Unit,
    dynamicRangeMode: DynamicRangeMode,
    onDynamicRangeModeChanged: (DynamicRangeMode) -> Unit,
    autoDynamicRange: Boolean, onAutoDynamicRangeChanged: (Boolean) -> Unit,
    abCompareBypassed: Boolean, onAbCompareChanged: (Boolean) -> Unit,
    cinemaBarsMode: CinemaBarsMode, onCinemaBarsModeChanged: (CinemaBarsMode) -> Unit,
    screenCurvatureEnabled: Boolean, onScreenCurvatureChanged: (Boolean) -> Unit,
    ambientLightingEnabled: Boolean, onAmbientLightingChanged: (Boolean) -> Unit,
    cinemaIntroEnabled: Boolean, onCinemaIntroChanged: (Boolean) -> Unit,
    intermissionEnabled: Boolean, onIntermissionChanged: (Boolean) -> Unit,
    savedPresetNames: List<String>,
    onSaveTheatrePreset: () -> Unit,
    onLoadTheatrePreset: (String) -> Unit,
    onDeleteTheatrePreset: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            "🎬 THEATRE / IMAX EXPERIENCE",
            color = CinemaGold, fontSize = 15.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            ToggleOption("🍿 FULL THEATRE MODE", theatreModeEnabled, onTheatreModeChanged)
            Text(
                "One-tap full cinema setup: IMAX Dome room, X-Curve, THX Re-EQ, Atmos 3D, Full DR. Turning it off restores a standard multiplex setup — every slider below still works either way.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
            ToggleOption("🅰️🅱️ A/B Compare (bypass all DSP)", abCompareBypassed, onAbCompareChanged)
            Text(
                "Instantly hear the raw source vs the full theatre chain — nothing is lost, just temporarily bypassed.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
        }

        Text(
            "ROOM SIZE", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        TheatreRoomSize.values().forEach { size ->
            TheatreOptionRow(
                title = size.label, description = size.description,
                selected = theatreRoomSize == size,
                onClick = { onTheatreRoomSizeChanged(size) }
            )
        }

        Spacer(Modifier.height(8.dp))
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            ToggleOption("📽️ X-Curve Cinema Calibration", xCurveEnabled, onXCurveEnabledChanged)
            Text(
                "SMPTE/ISO cinema reference curve — rolls off treble for big-room playback, like a real theatre projector booth mix.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
        }
        TheatreValueSlider(
            label = "X-CURVE INTENSITY", value = xCurveIntensity, onValueChange = onXCurveIntensityChanged,
            valueRange = 0f..100f, unit = "%"
        )

        Spacer(Modifier.height(4.dp))
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            ToggleOption("🎚️ THX Re-EQ", thxReEqEnabled, onThxReEqChanged)
            Text(
                "Tames the extra brightness cinema-mastered tracks have on flat/home playback systems.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
        }

        TheatreValueSlider(
            label = "LFE / SUBWOOFER LEVEL", value = lfeLevel, onValueChange = onLfeLevelChanged,
            valueRange = -10f..10f, unit = "dB"
        )

        Text(
            "BASS CROSSOVER", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BASS_CROSSOVER_OPTIONS.forEach { hz ->
                ChipButton(
                    label = "${hz}Hz", selected = bassCrossoverHz == hz,
                    onClick = { onBassCrossoverChanged(hz) }, modifier = Modifier.weight(1f)
                )
            }
        }
        Text(
            "THX-style bass management — sends only frequencies below this point to the LFE trim above.",
            color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp).padding(top = 4.dp)
        )

        Spacer(Modifier.height(8.dp))
        TheatreValueSlider(
            label = "HEIGHT CHANNEL (ATMOS/5.1.2)", value = heightChannelLevel, onValueChange = onHeightChannelChanged,
            valueRange = 0f..100f, unit = "%"
        )
        Text(
            "Only audible in Atmos 3D or 5.1.2 surround mode.",
            color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(8.dp))
        TheatreValueSlider(
            label = "CENTER CHANNEL / DIALOGUE CLARITY", value = centerChannelLevel, onValueChange = onCenterChannelChanged,
            valueRange = 0f..100f, unit = "%", enabled = dialogEnhance
        )
        Text(
            if (dialogEnhance) "Fine-tunes how strong Dialog Enhancement is." else "Turn on Dialog Enhancement below to use this.",
            color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(12.dp))
        Text(
            "🎛️ MANUAL CHANNEL MIXER", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        Text(
            "A phone/TV only outputs stereo, so these trim the closest honest equivalent of each real cinema channel instead of a literal speaker.",
            color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 4.dp)
        )
        TheatreValueSlider(label = "FRONT L/R TRIM", value = frontTrimDb, onValueChange = onFrontTrimChanged, valueRange = -10f..10f, unit = "dB")
        TheatreValueSlider(label = "CENTER TRIM", value = centerTrimDb, onValueChange = onCenterTrimChanged, valueRange = -10f..10f, unit = "dB")
        TheatreValueSlider(label = "SURROUND TRIM", value = surroundTrimDb, onValueChange = onSurroundTrimChanged, valueRange = -10f..10f, unit = "dB")

        Spacer(Modifier.height(12.dp))
        Text(
            "LOUDNESS TARGET (LKFS)", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LOUDNESS_TARGET_OPTIONS.forEach { lkfs ->
                ChipButton(
                    label = "${lkfs} LKFS", selected = loudnessTarget == lkfs,
                    onClick = { onLoudnessTargetChanged(lkfs) }, modifier = Modifier.weight(1f)
                )
            }
        }
        Text(
            "-14 LKFS is the standard theatrical/streaming reference; quieter targets get automatic makeup gain.",
            color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp).padding(top = 4.dp)
        )

        Spacer(Modifier.height(12.dp))
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            ToggleOption("🪄 Auto Dynamic Range (by content)", autoDynamicRange, onAutoDynamicRangeChanged)
            Text(
                "Guesses trailer/concert/podcast/movie from the filename and picks a mode automatically. Turn off to choose manually below.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
        }
        Text(
            "DYNAMIC RANGE MODE", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        DynamicRangeMode.values().forEach { mode ->
            TheatreOptionRow(
                title = mode.label, description = mode.description,
                selected = dynamicRangeMode == mode,
                onClick = { if (!autoDynamicRange) onDynamicRangeModeChanged(mode) }
            )
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "🖼️ SCREEN EXTRAS", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            ToggleOption("🌑 IMAX Screen Curvature (vignette)", screenCurvatureEnabled, onScreenCurvatureChanged)
            Spacer(Modifier.height(4.dp))
            ToggleOption("💡 Ambient / Bias Lighting", ambientLightingEnabled, onAmbientLightingChanged)
            Text(
                "There's no external Ambilight hardware on a phone, so this tints the letterbox area around the video with a dimmed sample of its own current color instead.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
            Spacer(Modifier.height(4.dp))
            ToggleOption("🎬 Feature Presentation Intro/Outro", cinemaIntroEnabled, onCinemaIntroChanged)
            Text(
                "Curtain + countdown when a video starts, curtain-close \"The End\" card when it finishes.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
            Spacer(Modifier.height(4.dp))
            ToggleOption("🍿 Intermission Reminder", intermissionEnabled, onIntermissionChanged)
            Text(
                "Popcorn-break popup at the midpoint of anything 90+ minutes long. Turn off if you don't want the interruption.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CinemaBarsMode.values().forEach { mode ->
                ChipButton(
                    label = mode.label, selected = cinemaBarsMode == mode,
                    onClick = { onCinemaBarsModeChanged(mode) }, modifier = Modifier.weight(1f)
                )
            }
        }
        Text(
            "Forces true theatrical letterbox bars over the video, like a real projector mask.",
            color = CinemaGray, fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 16.dp).padding(top = 4.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text(
            "💾 SAVED THEATRE PRESETS", color = CinemaGray, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        savedPresetNames.forEach { name ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "⭐ $name", color = Color.White, fontSize = 15.sp,
                    modifier = Modifier.weight(1f).clickable { onLoadTheatrePreset(name) }
                )
                IconButton(onClick = { onDeleteTheatrePreset(name) }) {
                    Icon(androidx.compose.material.icons.Icons.Default.Close, contentDescription = "Delete", tint = CinemaGray)
                }
            }
        }
        Button(
            onClick = onSaveTheatrePreset,
            colors = ButtonDefaults.buttonColors(containerColor = CinemaGold),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Text("Save Current Theatre Setup", color = Color.Black, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
    }
}

// ===================== EXTREME / THRILL MODE =====================
// Three real, live-wired "goosebumps" features layered on top of
// everything above — see CinemaDSPEngine.setExtremeBassMode /
// setExtremeLoudnessMode / setHapticBassSync for what each one actually
// does under the hood (real EQ shelf / real LoudnessEnhancer gain / real
// Visualizer-driven vibration, not just UI badges).
@Composable
fun ExtremeThrillSection(
    extremeBassMode: Boolean,
    onExtremeBassModeChanged: (Boolean) -> Unit,
    extremeLoudnessMode: Boolean,
    onExtremeLoudnessModeChanged: (Boolean) -> Unit,
    hapticBassSyncEnabled: Boolean,
    onHapticBassSyncChanged: (Boolean) -> Unit,
    hapticBassSyncIntensity: Int,
    onHapticBassSyncIntensityChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            "🔥 EXTREME / THRILL MODE", color = CinemaGold, fontSize = 15.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            ToggleOption("💥 Extreme Bass Punch", extremeBassMode, onExtremeBassModeChanged)
            Text(
                "Pushes the sub-bass shelf harder for explosions/impacts — layers on top of your normal bass level instead of replacing it.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            ToggleOption("📢 Extreme Loudness (Thrill Boost)", extremeLoudnessMode, onExtremeLoudnessModeChanged)
            Text(
                "Extra gain for loud action scenes, safely capped alongside Volume Enhancement/Loudness Target so it can't clip past safe headroom.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            ToggleOption("📳 Haptic Bass Sync", hapticBassSyncEnabled, onHapticBassSyncChanged)
            Text(
                "Real-time vibration pulse on hard bass hits — analyses live audio energy (not a fixed pattern), so it reacts to the actual soundtrack.",
                color = CinemaGray, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )
        }
        TheatreValueSlider(
            label = "HAPTIC SENSITIVITY / STRENGTH", value = hapticBassSyncIntensity,
            onValueChange = onHapticBassSyncIntensityChanged,
            valueRange = 0f..100f, unit = "%", enabled = hapticBassSyncEnabled
        )
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun TheatreOptionRow(title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = if (selected) CinemaGold else Color.White, fontSize = 15.sp)
            Text(description, color = CinemaGray, fontSize = 11.sp)
        }
        if (selected) {
            Icon(androidx.compose.material.icons.Icons.Default.Check, null, tint = CinemaGold)
        }
    }
}

@Composable
private fun ChipButton(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) CinemaGold else CinemaSurfaceLight)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 12.sp,
            color = if (selected) Color.Black else Color.White,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Medium
        )
    }
}

@Composable
private fun TheatreValueSlider(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    unit: String,
    enabled: Boolean = true
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = CinemaGray, fontSize = 12.sp)
            val display = if (value > 0 && valueRange.start < 0f) "+$value$unit" else "$value$unit"
            Text(display, color = if (enabled) CinemaGold else CinemaGray, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.roundToInt()) },
            valueRange = valueRange,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = CinemaGold,
                activeTrackColor = CinemaGold,
                inactiveTrackColor = CinemaSurfaceLight
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun BassControlSlider(
    value: Int,
    onValueChange: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("BASS BOOST", color = CinemaGray, fontSize = 12.sp)
            Text("$value%", color = CinemaGold, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = CinemaGold,
                activeTrackColor = CinemaGold,
                inactiveTrackColor = CinemaSurfaceLight
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}
