package com.cinemapro.player.data.database

import androidx.room.*
import com.cinemapro.player.data.model.*
import kotlinx.coroutines.flow.Flow

// ===================== DATABASE =====================
@Database(
    entities = [
        EqualizerPresetEntity::class,
        AppSettings::class,
        VideoHistoryEntity::class,
        PlaylistEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CinemaProDatabase : RoomDatabase() {

    companion object {
        @Volatile private var INSTANCE: CinemaProDatabase? = null

        fun getInstance(context: android.content.Context): CinemaProDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: androidx.room.Room.databaseBuilder(
                    context.applicationContext, CinemaProDatabase::class.java, "cinema_pro_db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
    abstract fun equalizerPresetDao(): EqualizerPresetDao
    abstract fun appSettingsDao(): AppSettingsDao
    abstract fun videoHistoryDao(): VideoHistoryDao
    abstract fun playlistDao(): PlaylistDao
}

// ===================== EQUALIZER PRESET DAO =====================
@Dao
interface EqualizerPresetDao {
    @Query("SELECT * FROM equalizer_presets ORDER BY createdAt DESC")
    fun getAllPresets(): Flow<List<EqualizerPresetEntity>>

    @Query("SELECT * FROM equalizer_presets WHERE isBuiltIn = 0 ORDER BY createdAt DESC")
    fun getCustomPresets(): Flow<List<EqualizerPresetEntity>>

    @Query("SELECT * FROM equalizer_presets WHERE id = :id")
    suspend fun getPresetById(id: String): EqualizerPresetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreset(preset: EqualizerPresetEntity)

    @Delete
    suspend fun deletePreset(preset: EqualizerPresetEntity)

    @Query("DELETE FROM equalizer_presets WHERE isBuiltIn = 0")
    suspend fun deleteAllCustomPresets()
}

// ===================== APP SETTINGS DAO =====================
@Dao
interface AppSettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun getSettings(): Flow<AppSettings>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun getSettingsSync(): AppSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSettings(settings: AppSettings)

    @Update
    suspend fun updateSettings(settings: AppSettings)
}

// ===================== VIDEO HISTORY DAO =====================
@Dao
interface VideoHistoryDao {
    @Query("SELECT * FROM video_history ORDER BY lastPlayed DESC LIMIT 50")
    fun getRecentVideos(): Flow<List<VideoHistoryEntity>>

    @Query("SELECT * FROM video_history WHERE videoId = :videoId")
    suspend fun getVideoHistory(videoId: Long): VideoHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(history: VideoHistoryEntity)

    @Query("DELETE FROM video_history WHERE lastPlayed < :timestamp")
    suspend fun deleteOldHistory(timestamp: Long)

    @Query("DELETE FROM video_history")
    suspend fun clearAllHistory()
}

// ===================== PLAYLIST DAO =====================
@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    suspend fun getPlaylistById(playlistId: Long): PlaylistEntity?

    @Insert
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Delete
    suspend fun deletePlaylist(playlist: PlaylistEntity)

    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)
}

// ===================== VIDEO HISTORY ENTITY =====================
@Entity(tableName = "video_history")
data class VideoHistoryEntity(
    @PrimaryKey val videoId: Long,
    val title: String,
    val uri: String,
    val duration: Long,
    val lastPosition: Long,
    val lastPlayed: Long = System.currentTimeMillis(),
    val playCount: Int = 1,
    val thumbnailPath: String? = null
)

// ===================== PLAYLIST ENTITY =====================
@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val videoIds: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

// Singleton companion
// (Add this as extension outside the abstract class)
